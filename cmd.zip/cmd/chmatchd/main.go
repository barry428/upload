package main

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/common/mac"
	"chainup.com/chainup/chmatch/conf"
	"chainup.com/chainup/chmatch/engine"
	"flag"
	"fmt"
	"github.com/lni/dragonboat/v3/logger"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"syscall"
)

var (
	BuildInfo = map[string]string{
		"commit":     "",
		"version":    "v1.2.2",
		"build_time": "",
	}
	help       bool
	version    bool
	configFile string
)

func init() {
	mac.CheckSysMac()
	flag.StringVar(&configFile, "config", "cluster1-node1.yml", "set configuration `file`, eg: hmatchd -config cluster1-node1.yml")

	flag.BoolVar(&help, "h", false, "this help")
	flag.BoolVar(&version, "version", false, "print program build version")
}
func main() {

	flag.Parse()
	if help {
		flag.Usage()
		os.Exit(1)
	}
	if version {
		println(BuildInfo["version"])
		os.Exit(1)
	}
	if configFile == "" {
		fmt.Fprintf(os.Stderr, "invalid configFile %s", configFile)
		os.Exit(1)
	}

	cfg := conf.InitConfig(configFile)
	log.Init(log.Config{Level: cfg.LogLevel})
	log.Infof("InitConfig file:%s", configFile)
	log.Infof("config: %v", cfg)

	if runtime.GOOS == "darwin" {
		signal.Ignore(syscall.Signal(0xd))
	}
	nodeID := cfg.NodeId
	initialMembers := make(map[uint64]string)
	for _, v := range cfg.Members {
		// key is the NodeID, NodeID is not allowed to be 0
		// value is the raft address
		initialMembers[uint64(v.NodeId)] = v.Url
	}
	nodeAddr := initialMembers[nodeID]
	log.Infof("node address: %s", nodeAddr)

	// change the log verbosity
	logger.GetLogger("raft").SetLevel(logger.ERROR)
	logger.GetLogger("rsm").SetLevel(logger.WARNING)
	logger.GetLogger("transport").SetLevel(logger.WARNING)
	logger.GetLogger("grpc").SetLevel(logger.WARNING)
	logger.GetLogger("logdb").SetLevel(logger.WARNING)
	logger.GetLogger("rocksdb").SetLevel(logger.WARNING)
	logger.GetLogger("dragonboat").SetLevel(logger.WARNING)

	datadir := filepath.Join(
		cfg.DataDir,
		"multigroup-data",
		fmt.Sprintf("node%d", nodeID))
	e := engine.NewEngine(cfg, datadir, initialMembers)
	e.Start()

	// Block until signalled.
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, os.Interrupt)
	signal.Notify(sigs, syscall.SIGTERM)
	<-sigs
	if err := e.Close(); err != nil {
		log.Errorf("failed to close engine: %s", err.Error())
	}
}
