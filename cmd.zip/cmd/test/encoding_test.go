package main

import (
	"bytes"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/state"
	"encoding/gob"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/shopspring/decimal"
	"github.com/vmihailenco/msgpack/v5"
	"testing"
	"time"
)

// order 序列化需要注意事项
// 1、decimal 类型可否无损失转换
// 2、float64 类型可否无损失转换
// 3、time.Time 类型时区转换问题（经分析，代码中并不使用Ctime，可以移除）

// 4、消除decimal.string类型转换（改用protobuf与gob结合方式）

// 基准测试
// go test -bench=. -benchtime=500ms  -benchmem -run=none
//goos: darwin
//goarch: arm64
//pkg: test
//BenchmarkDecimalGob-8           11909070                50.35 ns/op           32 B/op          3 allocs/op
//BenchmarkDecimalString-8         3347007               179.1 ns/op            64 B/op          5 allocs/op
//PASS
//ok      test    2.066s
func BenchmarkDecimal2Gob(b *testing.B) {
	price := decimal.NewFromFloat(27725.62447067).Truncate(10)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := price.GobEncode()
		if err != nil {
			fmt.Printf(err.Error())
			b.Error(err)
		}
	}
}
func BenchmarkGob2Decimal(b *testing.B) {
	price := decimal.NewFromFloat(27725.62447067).Truncate(10)
	data, _ := price.GobEncode()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		d := decimal.Decimal{}
		err := d.GobDecode(data)
		if err != nil {
			fmt.Printf(err.Error())
			b.Error(err)
		}
	}
}
func BenchmarkDecimal2String(b *testing.B) {
	price := decimal.NewFromFloat(27725.62447067).Truncate(10)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = price.String()
	}
}
func BenchmarkString2Decimal(b *testing.B) {
	price := decimal.NewFromFloat(27725.62447067).Truncate(10)
	str := price.String()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := decimal.NewFromString(str)
		if err != nil {
			fmt.Printf(err.Error())
			b.Error(err)
		}
	}
}

// ------

// 数据转换测试
func TestDecimal(t *testing.T) {

	price := decimal.NewFromFloat(27725.62447067).Truncate(10)
	fmt.Printf("decimal: %s\n", price.String())
	data, _ := price.GobEncode()
	d := decimal.Decimal{}
	fmt.Printf("decimal: %s\n", d.String())
	err := d.GobDecode(data)
	if err != nil {
		fmt.Printf(err.Error())
	}
	fmt.Printf("decimal: %s\n", d.String())

	s := time.Now().String()
	fmt.Println(s)
	duration, _ := time.ParseDuration(s)
	fmt.Println(duration)
	de(decimal.NewFromFloat(0.019808670344444444).Truncate(1))

	de(decimal.NewFromFloat(27725.62447067).Truncate(8))
	de(decimal.NewFromFloat(0.0).Truncate(10))
	de(decimal.NewFromFloat(1).Truncate(10))
	fromString, _ := decimal.NewFromString("2222.4444")
	de(fromString)

}

func de(deci decimal.Decimal) {
	truncate := deci
	s := truncate.String()
	fmt.Println(s)
	fromString, _ := decimal.NewFromString(s)
	fmt.Println(fromString)
	equal := truncate.Equal(fromString)
	fmt.Println(equal)
	fmt.Println("------")
}

func TestApplyRequest(t *testing.T) {
	reqs := []*state.ApplyRequest{{Type: string(state.ApplyTypeClearOrderBook)}}
	requests, err := state.EncodeApplyRequests(reqs)
	if err != nil {
		fmt.Println(err)
	}
	applyRequests, err := state.DecodeApplyRequests(requests)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println(applyRequests)
}

func TestOrderSize(t *testing.T) {
	oldData = []*ApplyRequest{}
	datas = &state.ApplyRequestWrapper{ApplyRequests: nil}
	for i := 0; i < 30; i++ {
		applyRequestOld := &ApplyRequest{
			Type:  state.ApplyTypePlace,
			Order: order,
		}
		oldData = append(oldData, applyRequestOld)
		applyRequest := &state.ApplyRequest{
			Type:  string(state.ApplyTypePlace),
			Order: order.Order2Pd(),
		}
		datas.ApplyRequests = append(datas.ApplyRequests, applyRequest)
		data, _ := state.EncodeApplyRequests(datas.ApplyRequests)
		fmt.Println("size", len(datas.ApplyRequests), len(data))
	}

}

// 基准测试 ApplyRequest数据序列化测试
var order = &models.Order{
	Id:           123456789,
	UserId:       uint64(2245),
	Side:         models.BUY,
	Price:        decimal.NewFromFloat(0.0198086703).Truncate(10),
	Volume:       decimal.NewFromFloat(27725.62447067).Truncate(8),
	FeeRateMaker: 0,
	FeeRateTaker: 0,
	FeeCoinRate:  0,
	Status:       models.STATUS_INIT,
	Type:         models.ORDER_LIMIT,
	Ctime:        time.Now(),
	Source:       2,
	OrderType:    1,
	CompanyId:    987654321,
	DealVolume:   decimal.NewFromFloat(27725.62447067),
	DealMoney:    decimal.NewFromFloat(27725.62447067),
	AvgPrice:     decimal.NewFromFloat(27725.62447067),
	Symbol:       "eth1347usdt1347",
	IsRebuild:    false,
	Offset:       -2,
}
var oldData []*ApplyRequest
var datas = &state.ApplyRequestWrapper{ApplyRequests: nil}

func _init() {
	oldData = []*ApplyRequest{}
	datas = &state.ApplyRequestWrapper{ApplyRequests: nil}
	// fmt.Printf("%+v\n", order)
	// unixB := time.Now().UnixNano()

	// 当前默认最大ApplyRequest数组大小为10，*2用于双倍压力测试
	for i := 0; i < 10; i++ {
		applyRequestOld := &ApplyRequest{
			Type:  state.ApplyTypePlace,
			Order: order,
		}
		oldData = append(oldData, applyRequestOld)
		applyRequest := &state.ApplyRequest{
			Type:  string(state.ApplyTypePlace),
			Order: order.Order2Pd(),
		}
		datas.ApplyRequests = append(datas.ApplyRequests, applyRequest)
	}
	// _requests, _ := state.EncodeApplyRequests(datas.ApplyRequests)
	// fmt.Println("datas: ", len(_requests))
	// fmt.Printf("pd time cost :%+v ns.\n", time.Now().UnixNano()-unixB)
	// fmt.Printf("datas: %+v, oldData: %+v\n", len(datas.ApplyRequests), len(oldData))
}

func BenchmarkArGobEncode(b *testing.B) {
	_init()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		buf2 := new(bytes.Buffer)
		if err := gob.NewEncoder(buf2).Encode(oldData); err != nil {
			fmt.Println(err)
			b.Error(err)
		}
		_ = buf2.Bytes()
	}
}
func BenchmarkArGobDecode(b *testing.B) {
	_init()
	buf2 := new(bytes.Buffer)
	if err := gob.NewEncoder(buf2).Encode(oldData); err != nil {
		fmt.Println(err)
		b.Error(err)
	}
	_bytes := buf2.Bytes()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		var requests []*ApplyRequest
		dec := gob.NewDecoder(bytes.NewBuffer(_bytes))
		if err := dec.Decode(&requests); err != nil {
			fmt.Println(err)
			b.Error(err)
		}
	}
}

func BenchmarkArMsgpackEncode(b *testing.B) {
	_init()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := msgpack.Marshal(datas)
		if err != nil {
			fmt.Println(err)
			b.Error(err)
		}
	}
}
func BenchmarkArMsgpackDecode(b *testing.B) {
	_init()
	_requests, err := msgpack.Marshal(datas)
	if err != nil {
		fmt.Println(err)
		b.Error(err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		var requests state.ApplyRequestWrapper
		err = msgpack.Unmarshal(_requests, &requests)
		if err != nil {
			fmt.Println(err)
			b.Error(err)
		}
	}
}

func BenchmarkArProtobufEncode(b *testing.B) {
	_init()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := proto.Marshal(datas)
		if err != nil {
			fmt.Println(err)
			b.Error(err)
		}
	}
}
func BenchmarkArProtobufDecode(b *testing.B) {
	_init()
	_requests, err := proto.Marshal(datas)
	if err != nil {
		fmt.Println(err)
		b.Error(err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		var requests state.ApplyRequestWrapper
		err = proto.Unmarshal(_requests, &requests)
		if err != nil {
			fmt.Println(err)
			b.Error(err)
		}
		for _, request := range requests.ApplyRequests {
			_, _ = request.Order.Pd2Order()
		}
	}
}

func BenchmarkArEncode(b *testing.B) {
	_init()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := state.EncodeApplyRequests(datas.ApplyRequests)
		if err != nil {
			fmt.Println(err)
			b.Error(err)
		}
	}
}
func BenchmarkArDecode(b *testing.B) {
	_init()
	_requests, err := state.EncodeApplyRequests(datas.ApplyRequests)
	if err != nil {
		fmt.Println(err)
		b.Error(err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		applyRequests, err := state.DecodeApplyRequests(_requests)
		if err != nil {
			fmt.Println(err)
			b.Error(err)
		}
		for _, request := range applyRequests {
			_, _ = request.Order.Pd2Order()
		}
	}
}

// _______

//
func TestEncodeApplyRequests(t *testing.T) {
	count := 10000
	// 编码解码各一千次
	requests := gobEncodeApplyRequests(oldData, count)
	if requests != nil {
		applyRequests := gobDecodeApplyRequests(requests, count)
		fmt.Printf("%+v\n", applyRequests[0].Order)
	}

	fmt.Println("--------")
	requests2 := msgpackMarshal(datas, count)
	if requests != nil {
		applyRequests2 := msgpackUnmarshal(requests2, count)
		fmt.Println(applyRequests2)
	}
	fmt.Println("--------")

	marshal := protoMarshal(datas, count)
	if marshal != nil {
		unmarshal := protoUnmarshal(marshal, count)
		fmt.Println(unmarshal)
		pd2Order, err := unmarshal.ApplyRequests[0].Order.Pd2Order()
		if err != nil {
			fmt.Printf("%+v\n", err)
		}
		fmt.Printf("%+v\n", pd2Order)

	}

	fmt.Println("--------")
	applyRequests := encodeApplyRequests(datas.ApplyRequests, count)
	if applyRequests != nil {
		temp := decodeUnmarshal(applyRequests, count)
		fmt.Println(temp)
		pd2Order, err := temp[0].Order.Pd2Order()
		if err != nil {
			fmt.Printf("%+v\n", err)
		}
		fmt.Printf("%+v\n", pd2Order)
	}
}

func gobEncodeApplyRequests(data []*ApplyRequest, count int) []byte {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("gob encode time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()

	buf := new(bytes.Buffer)
	if err := gob.NewEncoder(buf).Encode(data); err != nil {
		fmt.Println(err)
		return nil
	}
	requests := buf.Bytes()
	fmt.Printf("gob encode size:%+v \n", len(requests))

	for i := 0; i < count; i++ {
		buf2 := new(bytes.Buffer)
		if err := gob.NewEncoder(buf2).Encode(data); err != nil {
			fmt.Println(err)
			return nil
		}
		buf2.Bytes()
	}
	return requests
}
func gobDecodeApplyRequests(data []byte, count int) []*ApplyRequest {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("gob decode time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()
	var requests []*ApplyRequest
	dec := gob.NewDecoder(bytes.NewBuffer(data))
	if err := dec.Decode(&requests); err != nil {
		fmt.Println(err)
		return nil
	}

	fmt.Printf("gob encode size:%+v \n", len(requests))
	for i := 0; i < count; i++ {
		var requests2 []*ApplyRequest
		_ = gob.NewDecoder(bytes.NewBuffer(data)).Decode(&requests2)
	}
	return requests
}

func msgpackMarshal(data *state.ApplyRequestWrapper, count int) []byte {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("msgpackMarshal time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()
	//var buf bytes.Buffer
	//msgp.(&buf, data)
	requests, err := msgpack.Marshal(data)
	if err != nil {
		fmt.Println(err)
		return nil
	}
	fmt.Printf("msgpackMarshal size:%+v \n", len(requests))
	for i := 0; i < count; i++ {
		_, _ = msgpack.Marshal(data)
	}
	return requests
}
func msgpackUnmarshal(data []byte, count int) *state.ApplyRequestWrapper {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("msgpackUnmarshal time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()

	var requests state.ApplyRequestWrapper
	err := msgpack.Unmarshal(data, &requests)
	if err != nil {
		fmt.Println(err)
		return nil
	}
	fmt.Printf("msgpackUnmarshal size:%+v \n", len(requests.ApplyRequests))
	for i := 0; i < count; i++ {
		_ = msgpack.Unmarshal(data, &requests)
	}
	return &requests
}

func protoMarshal(data *state.ApplyRequestWrapper, count int) []byte {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("protoMarshal time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()
	//var buf bytes.Buffer
	//msgp.(&buf, data)
	requests, err := proto.Marshal(data)
	if err != nil {
		fmt.Println(err)
		return nil
	}
	fmt.Printf("protoMarshal size:%+v \n", len(requests))
	for i := 0; i < count; i++ {
		_, _ = proto.Marshal(data)
	}
	return requests
}
func protoUnmarshal(data []byte, count int) *state.ApplyRequestWrapper {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("protoUnmarshal time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()
	var requests state.ApplyRequestWrapper
	err := proto.Unmarshal(data, &requests)
	if err != nil {
		fmt.Println(err)
		return nil
	}
	fmt.Printf("protoUnmarshal size:%+v \n", len(requests.ApplyRequests))
	for i := 0; i < count; i++ {
		_ = proto.Unmarshal(data, &requests)
	}
	return &requests
}

func encodeApplyRequests(data []*state.ApplyRequest, count int) []byte {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("gob encode time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()
	requests, err := state.EncodeApplyRequests(data)
	if err != nil {
		fmt.Println(err)
		return nil
	}
	fmt.Printf("protoMarshal size:%+v \n", len(requests))
	for i := 0; i < count; i++ {
		_, _ = state.EncodeApplyRequests(data)
	}
	return requests
}
func decodeUnmarshal(data []byte, count int) []*state.ApplyRequest {
	unixB := time.Now().UnixMilli()
	defer func() {
		fmt.Printf("protoUnmarshal time cost :%+v ms.\n", time.Now().UnixMilli()-unixB)
	}()
	requests, err := state.DecodeApplyRequests(data)
	if err != nil {
		fmt.Println(err)
		return nil
	}
	fmt.Printf("protoUnmarshal size:%+v \n", len(requests))
	for i := 0; i < count; i++ {
		applyRequests, _ := state.DecodeApplyRequests(data)
		for _, request := range applyRequests {
			_, _ = request.Order.Pd2Order()
		}
	}
	return requests
}

type ApplyRequest struct {
	Type   state.ApplyType
	Order  *models.Order
	Reset  *ApplyRequestReset
	UserId uint64
}

type ApplyRequestReset struct {
	Offset          int64
	MqConsumeStatus int64
	EmptyOrderBook  bool
	Symbol          string
	WorkId          int64
}
