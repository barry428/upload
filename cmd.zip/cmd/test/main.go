package main

import (
	"chainup.com/chainup/chmatch/models"
	"context"
	"fmt"
	"github.com/apache/rocketmq-client-go/v2"
	"github.com/apache/rocketmq-client-go/v2/consumer"
	"github.com/apache/rocketmq-client-go/v2/primitive"
	"github.com/jinzhu/gorm"
	"os"
	"strings"
	"time"
)

var symbols = []string{"BTCUSDT"}

func main() {
	var nameServer = "192.168.194.175:9876"
	exchangeDB, err := gorm.Open("mysql", "root:password@tcp(mysql:3306)/exchange?timeout=30s&&loc=Local&parseTime=true&allowOldPasswords=1")
	if err != nil {
		println("create mysql conn failed, error:", err)
		os.Exit(1)
	}
	exchangeDB.SingularTable(true)
	exchangeDB.DB().SetMaxIdleConns(1)
	exchangeDB.DB().SetMaxOpenConns(1)

	var configSymbols []*models.ConfigSymbolMatching
	db := exchangeDB.Where("server=? and is_open=1 and run_status IN (?)", "cluster1", []int{0, 1}).Order("id ASC")
	err = db.Find(&configSymbols).Error
	if err != nil {
		println("query configSymbols failed, error:", err)
		os.Exit(1)
	}

	for _, configSymbol := range configSymbols {
		symbol := fmt.Sprintf("%s%s", configSymbol.Base, configSymbol.Quote)
		symbol = strings.ToUpper(symbol)
		pConfig := []consumer.Option{
			consumer.WithNsResolver(primitive.NewPassthroughResolver([]string{nameServer})),
			consumer.WithGroupName("Liquidation-" + symbol),
			consumer.WithConsumerModel(consumer.Clustering),
			consumer.WithConsumeFromWhere(consumer.ConsumeFromLastOffset),
			consumer.WithConsumeMessageBatchMaxSize(1024),
			consumer.WithInstance(symbol),
			// 默认是 concurrent consumer model
			// 拉取周期10毫秒，当前版本bug 暂不支持 mqconsumer.WithPullInterval(10 * time.Millisecond),
			consumer.WithPullBatchSize(1024),
		}
		go ConsumeWithPush(pConfig, symbol)
	}
	select {}
}

// ConsumeWithPush 创建消费者
func ConsumeWithPush(pConfig []consumer.Option, symbol string) {
	pushConsumer, err := rocketmq.NewPushConsumer(pConfig...)
	if err != nil {
		println("create consumer failed, error:", err)
		return
	}
	topic := "EXCHANGE_MATCHING_RESULTS_" + strings.ToUpper(symbol)
	err = pushConsumer.Subscribe(topic, consumer.MessageSelector{}, func(ctx context.Context,
		msgs ...*primitive.MessageExt) (consumer.ConsumeResult, error) {
		for i := range msgs {
			diff := time.Now().Unix() - msgs[i].BornTimestamp/1000
			if diff < 60 {
				// fmt.Println(msgs[i].Body)
			}
		}
		return consumer.ConsumeSuccess, nil
	})
	if err != nil {
		println("consumer.Subscribe failed, error:", err)
		return
	}

	err = pushConsumer.Start()
	if err != nil {
		println("consumer start failed,", err)
		return
	}
}
