package main

import (
	"chainup.com/chainup/chmatch/common/mock"
	"chainup.com/chainup/chmatch/models"
	"context"
	"fmt"
	"github.com/apache/rocketmq-client-go/v2"
	"github.com/apache/rocketmq-client-go/v2/primitive"
	"github.com/apache/rocketmq-client-go/v2/producer"
	"github.com/golang/protobuf/proto"
	"github.com/jinzhu/gorm"
	"os"
	"strings"
	"test/engine"
	"time"
)

func main() {
	var nameServer = "192.168.194.175:9876"
	exchangeDB, err := gorm.Open("mysql", "root:password@tcp(mysql:3306)/exchange?timeout=30s&&loc=Local&parseTime=true&allowOldPasswords=1")
	if err != nil {
		println("create mysql conn failed, error:", err)
		os.Exit(1)
	}
	exchangeDB.SingularTable(true)
	exchangeDB.DB().SetMaxIdleConns(1)
	exchangeDB.DB().SetMaxOpenConns(1)

	var configSymbols []*models.ConfigSymbolMatching
	db := exchangeDB.Where("server=? and is_open=1 and run_status IN (?)", "cluster1", []int{0, 1}).Order("id ASC")
	err = db.Find(&configSymbols).Error
	if err != nil {
		println("query configSymbols failed, error:", err)
		os.Exit(1)
	}

	for _, configSymbol := range configSymbols {
		symbol := fmt.Sprintf("%s-%s", configSymbol.Base, configSymbol.Quote)
		symbol = strings.ToUpper(symbol)
		go NewRocketMQProvider(nameServer, "group-test1", symbol)
	}
	select {}
}

// 每秒发送2000条消息
func NewRocketMQProvider(nameServer string, groupID string, symbol string) {
	_producer, err := rocketmq.NewProducer(
		producer.WithGroupName(groupID),
		producer.WithNsResolver(primitive.NewPassthroughResolver([]string{nameServer})),
		producer.WithRetry(2),
	)

	if err != nil {
		fmt.Println("create common producer failed, error:", err)
		os.Exit(1)
	}

	err = _producer.Start()
	if err != nil {
		fmt.Println("start common producer error", err)
		os.Exit(1)
	}

	defer func() {
		err = _producer.Shutdown()
		if err != nil {
			fmt.Printf("Shutdown producer error: %s", err.Error())
			return
		}
	}()

	topic := engine.TopicNameOrderProvider(symbol)
	fmt.Println(topic)
	for true {
		for i := 1; i <= 1000; i++ {
			go func() {
				order := mock.MockOneOrder(symbol)
				for j := range order {
					placeMsg := engine.OrderToPb(order[j])
					data, _ := proto.Marshal(placeMsg)
					// fmt.Printf("Send placeMsg: %v \n", placeMsg)

					msg := &primitive.Message{Topic: topic, Body: data}
					_, err := _producer.SendSync(context.Background(), msg)
					if err != nil {
						fmt.Printf("SendMessageSync err %v\n", err)
					}
				}
				// fmt.Printf("res %v\n", res)
			}()
		}
		time.Sleep(time.Millisecond * 200)
	}
}
