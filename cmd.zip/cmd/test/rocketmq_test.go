package main

import (
	"chainup.com/chainup/chmatch/common/mock"
	"chainup.com/chainup/chmatch/models"
	"context"
	"encoding/json"
	"fmt"
	"github.com/apache/rocketmq-client-go/v2"
	"github.com/apache/rocketmq-client-go/v2/primitive"
	"github.com/apache/rocketmq-client-go/v2/producer"
	"github.com/golang/protobuf/proto"
	"os"
	"test/engine"
	"testing"
	"time"
)

var nameServer = "192.168.194.175:9876"

var _producer rocketmq.Producer

func TestEngine_AddSymbol(t *testing.T) {
	symbol := "ETH-USDT"
	order := mock.MockOneOrder(symbol)

	obyte, _ := json.Marshal(order)
	fmt.Printf("%v\n", string(obyte))
	fmt.Printf("%+v\n", order)

	str := "{\"Id\":1321,\"UserId\":22,\"Side\":\"BUY\"}"

	var o models.Order
	json.Unmarshal([]byte(str), &o)
	fmt.Printf("%+v\n", o)

}

func TestNewRocketMQProvider(t *testing.T) {
	setup(nameServer, "group-test1")
	defer tearDown()

	symbol := "BTC-USDT"
	topic := engine.TopicNameOrderProvider(symbol)
	fmt.Println(topic)

	for i := 1; i <= 1000; i++ {
		order := mock.MockOneOrder(symbol)
		// order := MockFixedOrder(symbol)
		placeMsg := engine.OrderToPb(order[0])
		data, _ := proto.Marshal(placeMsg)
		fmt.Printf("Send placeMsg: %v \n", placeMsg)

		msg := &primitive.Message{Topic: topic, Body: data}
		res, err := _producer.SendSync(context.Background(), msg)
		if err != nil {
			fmt.Printf("SendMessageSync err %v\n", err)
		}

		fmt.Printf("res %v\n", res)
		time.Sleep(time.Second * 2)
	}

}

func TestRocketMQLogSender_Send(t *testing.T) {
	// todo 底层依然使用旧方法
	// sender := engine.NewRocketMQLogSender(nameServer, 10)
	setup(nameServer, "group-test1")
	defer tearDown()
	msg := &primitive.Message{Topic: "test-topic", Body: []byte("Hello RocketMQ Go Client! ")}
	_, err := _producer.SendSync(context.Background(), msg)
	fmt.Println(err)
}

func setup(nameServer string, groupID string) {
	var err error
	_producer, err = rocketmq.NewProducer(
		producer.WithGroupName(groupID),
		producer.WithNsResolver(primitive.NewPassthroughResolver([]string{nameServer})),
		producer.WithRetry(2),
	)

	if err != nil {
		fmt.Println("create common producer failed, error:", err)
		os.Exit(1)
	}

	err = _producer.Start()
	if err != nil {
		fmt.Println("start common producer error", err)
		os.Exit(1)
	}
}

func tearDown() {
	err := _producer.Shutdown()
	if err != nil {
		fmt.Printf("Shutdown producer error: %s", err.Error())
		return
	}
}
