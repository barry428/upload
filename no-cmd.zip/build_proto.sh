#!/bin/bash

# build_proto.sh - 生成所有 protobuf 代码的脚本
# 使用方法: ./build_proto.sh

set -e  # 遇到错误时退出

echo "开始生成 protobuf 代码..."

# 检查必要的工具
if ! command -v protoc &> /dev/null; then
    echo "错误: 未找到 protoc，请先安装 Protocol Buffers"
    exit 1
fi

if ! command -v protoc-gen-go &> /dev/null; then
    echo "错误: 未找到 protoc-gen-go，请先安装: go install github.com/golang/protobuf/protoc-gen-go@latest"
    exit 1
fi

echo "检查工具完成"

# 1. 生成 models 包的代码
echo "生成 models 包代码..."
protoc --go_out=. --go_opt=Mmodels/models.proto=chainup.com/chainup/chmatch/models models/models.proto

# 2. 生成 protocol 包的代码
echo "生成 protocol 包代码..."
protoc --go_out=. --go_opt=Mprotocol/place_order.proto=chainup.com/chainup/chmatch/protocol protocol/place_order.proto
protoc --go_out=. --go_opt=Mprotocol/matchlogs.proto=chainup.com/chainup/chmatch/protocol protocol/matchlogs.proto

# 3. 复制生成的文件到正确位置
echo "复制生成的文件..."
if [ -f "chainup.com/chainup/chmatch/models/models.pb.go" ]; then
    cp chainup.com/chainup/chmatch/models/models.pb.go models/
    echo "✓ 复制 models.pb.go 到 models/ 目录"
else
    echo "警告: 未找到 models.pb.go 文件"
fi

if [ -f "chainup.com/chainup/chmatch/protocol/place_order.pb.go" ]; then
    cp chainup.com/chainup/chmatch/protocol/place_order.pb.go protocol/
    echo "✓ 复制 place_order.pb.go 到 protocol/ 目录"
else
    echo "警告: 未找到 place_order.pb.go 文件"
fi

if [ -f "chainup.com/chainup/chmatch/protocol/matchlogs.pb.go" ]; then
    cp chainup.com/chainup/chmatch/protocol/matchlogs.pb.go protocol/
    echo "✓ 复制 matchlogs.pb.go 到 protocol/ 目录"
else
    echo "警告: 未找到 matchlogs.pb.go 文件"
fi

# 4. 清理临时目录
echo "清理临时文件..."
if [ -d "chainup.com" ]; then
    rm -rf chainup.com
    echo "✓ 清理临时目录 chainup.com"
fi

# 5. 验证生成的文件
echo "验证生成的文件..."
if grep -q "ClientOrderId" models/models.pb.go; then
    echo "✓ models.pb.go 包含 ClientOrderId 字段"
else
    echo "警告: models.pb.go 中未找到 ClientOrderId 字段"
fi

if grep -q "ClientOrderId" protocol/place_order.pb.go; then
    echo "✓ place_order.pb.go 包含 ClientOrderId 字段"
else
    echo "警告: place_order.pb.go 中未找到 ClientOrderId 字段"
fi

if grep -q "ClientOrderId" protocol/matchlogs.pb.go; then
    echo "✓ matchlogs.pb.go 包含 ClientOrderId 字段"
else
    echo "警告: matchlogs.pb.go 中未找到 ClientOrderId 字段"
fi

# 6. 尝试编译验证
echo "编译验证..."
if make all > /dev/null 2>&1; then
    echo "✓ 编译成功"
else
    echo "警告: 编译失败，请检查错误信息"
    echo "运行 'make all' 查看详细错误"
fi

echo ""
echo "protobuf 代码生成完成！"
echo ""
echo "生成的文件:"
echo "- models/models.pb.go"
echo "- protocol/place_order.pb.go"
echo "- protocol/matchlogs.pb.go"
echo ""
echo "如果编译失败，请运行: make all" 