package conf

import (
	"fmt"
	"testing"
)

func TestLoadConfig(t *testing.T) {
	//file := "/Users/nob/workspace/gomod/chmatch/config/match.yml"
	config := GetConfig()
	fmt.Printf("%+v \n", *config)
	fmt.Printf("%+v \n", config.DB)
}
