package conf

import (
	"fmt"
	"github.com/jinzhu/configor"
	"sync"
	"time"
)

var config Config
var configOnce sync.Once

// OrderBookSyncConfig 订单簿同步配置
type OrderBookSyncConfig struct {
	Enabled       bool          `yaml:"enabled"`        // 是否启用同步
	SyncInterval  time.Duration `yaml:"sync_interval"`  // 同步间隔
	MaxDepth      int           `yaml:"max_depth"`      // 订单簿深度档位数
	CompressLevel int           `yaml:"compress_level"` // 压缩级别 (0-9)
}

// RedisConfig Redis 配置
type RedisConfig struct {
	Nodes            []string `yaml:"nodes"`            // Redis 节点列表
	Password         string   `yaml:"password"`         // Redis 密码
	PoolSize         int      `yaml:"pool_size"`        // 连接池大小
	MinIdleConns     int      `yaml:"min_idle_conns"`   // 最小空闲连接数
	ReadTimeout      string   `yaml:"read_timeout"`     // 读取超时
	WriteTimeout     string   `yaml:"write_timeout"`    // 写入超时
	DialTimeout      string   `yaml:"dial_timeout"`     // 连接超时
}

type Config struct {
	// 掉坑指南，yaml文件中的字段必须要要全小写，要不然解析不粗来
	ClusterName string `default:"match1"`
	NodeId      uint64 `required:"true"`
	HttpAddr    string `default:":7001"`
	DataDir     string `default:"data"`
	Members     []struct {
		NodeId uint64
		Url    string
	} `required:"true"`

	DB struct {
		// 数据库账号信息不做序列化
		ExchangeDsn     string `required:"true" json:"-"`
		ExchangeCoreDsn string `required:"true" json:"-"`
		MaxConn         int    `default:"50"`
		MaxIdle         int    `default:"10"`
	} `required:"true"`

	RabbitMQ struct {
		Url        string `required:"true"`
		ConsoleUrl string `default:""`
		// 单位毫秒
		NoMsgSleep int64 `default:"500"`
	}

	LogLevel     string `default:"info"`
	SendAttempts int    `default:"10"`
	Raft         struct {
		// RTTMillisecond 代码设置为200 则推荐ElectionRTT最少为10*HeartbeatRTT,
		ElectionRTT        uint64 `default:"10"`
		HeartbeatRTT       uint64 `default:"1"`
		SnapshotEntries    uint64 `default:"5000"`
		CompactionOverhead uint64 `default:"50"`
		ProposeTimeout     uint64 `default:"10"`
		EnableMetrics      bool   `default:"false"`
	}
	ClearMemoryCron string `default:"0 24 3 ? * 3"`
	Redis          RedisConfig        `yaml:"redis"`           // Redis 连接配置
	OrderBookSync  OrderBookSyncConfig `yaml:"orderbook_sync"` // 订单簿同步配置
}

func GetConfig() *Config {
	configOnce.Do(func() {
		//InitConfig("chmatch/conf/cluster1-node1.yml")
		fmt.Printf("configOnce...config:%v \n", &config)
	})
	return &config
}

func InitConfig(file string) *Config {
	configor.Load(&config, file)
	return &config
}

func (c *Config) String() string {
	// DB 不输出DB信息涉及账号密码，直接打印在日志中不安全
	return fmt.Sprintf("ClusterName: %v NodeId: %v HttpAddr: %v DataDir: %v Members: %v MQ: %v LogLevel: %v "+
		"SendAttempts: %v ClearMemoryCron: %v Raft: %v Redis: %v OrderBookSync: %v", 
		c.ClusterName, c.NodeId, c.HttpAddr, c.DataDir, c.Members,
		c.RabbitMQ, c.LogLevel, c.SendAttempts, c.ClearMemoryCron, c.Raft, c.Redis, c.OrderBookSync)
}
