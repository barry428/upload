package state

import "errors"

type ApplyType string

const (
	ApplyTypePlace  = ApplyType("place")
	ApplyTypeCancel = ApplyType("cancel")

	ApplyTypeReset = ApplyType("reset")

	//取消某个用户的所有订单
	ApplyTypeCancelUserOrders = ApplyType("cancelUserOrders")
	//查询订单消费位置
	ApplyTypeQueryOffset = ApplyType("queryOffset")
	//根据订单id查询
	ApplyTypeQueryOrder = ApplyType("queryOrder")
	//查询某个用户的当前挂单
	ApplyTypeQueryUserOrders = ApplyType("queryUserOrders")
	//查询某个用户的当前挂单ID
	ApplyTypeQueryUserOrderIds = ApplyType("queryUserOrderIds")
	//查询深度
	ApplyTypeQueryDepth = ApplyType("queryDepth")
	//ApplyTypeQueryUsers 查询盘口挂单用户信息
	ApplyTypeQueryUsers = ApplyType("queryUsers")
	//触发给行情推送深度
	ApplyTypePushDepth = ApplyType("pushDepth")
	// ApplyTypeClearOrderBook 该字段后续将废弃！！！！！
	ApplyTypeClearOrderBook = ApplyType("clearOrderBook")
)

var (
	ErrEmptyLogs = errors.New("match logs is empty")
)
