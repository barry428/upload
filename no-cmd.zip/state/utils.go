package state

import (
	"github.com/golang/protobuf/proto"
)

// EncodeApplyRequests 将ApplyRequests编码为字节流
func EncodeApplyRequests(data []*ApplyRequest) ([]byte, error) {
	// 使用protobuf进行序列化
	marshal, err := proto.Marshal(&ApplyRequestWrapper{ApplyRequests: data})
	if err != nil {
		return nil, err
	}
	return marshal, nil
}

// DecodeApplyRequests 将字节流解码为 []*ApplyRequest 对象
func DecodeApplyRequests(data []byte) ([]*ApplyRequest, error) {
	var pd ApplyRequestWrapper
	err := proto.Unmarshal(data, &pd)
	if err != nil {
		return nil, err
	}

	return pd.ApplyRequests, nil
}
