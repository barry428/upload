package state

import (
	"chainup.com/chainup/chmatch/protocol"
	"fmt"
	"testing"
)

func TestStateMachine_GetHash(t *testing.T) {
	var resultLogs []*protocol.Log
	for i := uint64(1); i <= 19; i++ {
		log := &protocol.Log{Sequence: i}
		resultLogs = append(resultLogs, log)
	}

	groupMsgSize := 10
	// 超过1000分组发送
	msgLen := len(resultLogs)
	groupCnt := msgLen / groupMsgSize
	if groupCnt*groupMsgSize < msgLen {
		// 意味着有余数
		groupCnt++
	}
	fmt.Println(msgLen, groupCnt)
	for i := 0; i < groupCnt; i++ {
		begin := i * groupMsgSize
		end := (i + 1) * groupMsgSize
		if i == groupCnt-1 {
			end = msgLen
		}
		if len(resultLogs[begin:end]) <= 0 {
			fmt.Printf("from StateMachine.Update() updateCall fail begin:%d, end:%d, msgLen:%d\n", begin, end, msgLen)
		} else {
			fmt.Printf("begin: %d, end: %d,  r: %+v\n", begin, end, resultLogs[begin:end])
		}
	}
}
