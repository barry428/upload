package state

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/match"
	"chainup.com/chainup/chmatch/protocol"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/golang/protobuf/proto"
	"io"
	"io/ioutil"
	"runtime/debug"

	sm "github.com/lni/dragonboat/v3/statemachine"
)

type QueryRequest struct {
	Type    ApplyType
	Symbol  string
	OrderId uint64
	UserId  uint64
}

type StateMachine struct {
	ClusterID      uint64
	NodeID         uint64
	OrderBook      *match.OrderBook
	ApplyAfterFunc func(matchLogs []byte) error
}

func (s *StateMachine) Lookup(query interface{}) (interface{}, error) {
	req := query.(*QueryRequest)

	var data []byte
	var err error
	matchLogs := &protocol.MatchLogs{}
	value := uint64(0)
	switch req.Type {
	case ApplyTypeQueryDepth:
		logs := s.OrderBook.OrderBookStatus()
		matchLogs.Logs = logs
		data, err = proto.Marshal(matchLogs)
		if err != nil {
			log.Errorf("failed to Marshal cluster output OrderBookSnapshot: %s", err.Error())
		}
	case ApplyTypeQueryUsers:
		logs := s.OrderBook.QueryOrdersByUser(10)
		data, err = json.Marshal(logs)
		if err != nil {
			log.Errorf("failed to Marshal cluster output OrderBookSnapshot: %s", err.Error())
		}
	case ApplyTypePushDepth:
		logs := s.OrderBook.OrderBookSnapshot()
		matchLogs.Logs = logs
		data, err = proto.Marshal(matchLogs)
		if err != nil {
			log.Errorf("failed to Marshal cluster output OrderBookSnapshot: %s", err.Error())
		}
	case ApplyTypeQueryUserOrders:
		pbOrders := s.OrderBook.UserOrders(req.UserId)
		userOrders := &protocol.UserOrders{Orders: pbOrders}
		data, err = proto.Marshal(userOrders)
		if err != nil {
			log.Errorf("failed to Marshal cluster output UserOrders: %s", err.Error())
		}
	case ApplyTypeQueryUserOrderIds:
		userOrderIds := s.OrderBook.UserOrderIds(req.UserId)
		data, err = proto.Marshal(userOrderIds)
		if err != nil {
			log.Errorf("failed to Marshal cluster output UserOrders: %s", err.Error())
		}
	case ApplyTypeQueryOrder:
		pbOrders := s.OrderBook.OrderDetail(req.OrderId)
		userOrders := &protocol.UserOrders{Orders: pbOrders}
		data, err = proto.Marshal(userOrders)
		if err != nil {
			log.Errorf("failed to Marshal cluster output UserOrders: %s", err.Error())
		}
	case ApplyTypeQueryOffset:
		offset, mqConsumeStatus := s.OrderBook.GetConsumeState()
		consumeStatus := fmt.Sprintf("%d,%d", offset, mqConsumeStatus)
		data = []byte(consumeStatus)
	}

	if err != nil {
		return sm.Result{Value: value, Data: data}, err
	}

	// 如果是快照请求，通过leader推送快照消息给下游
	if req.Type == ApplyTypePushDepth {
		log.Debugf("from StateMachine.Lookup() ApplyTypePushDepth, req: %v, matchLogs: %v \n", &req, matchLogs)
		if err := s.ApplyAfterFunc(data); err != nil {
			log.Errorf("failed to ApplyAfterFunc output: %s", err.Error())
		}
	}

	return sm.Result{Value: value, Data: data}, nil
}

// Update updates the object using the specified committed raft entry.
func (s *StateMachine) Update(data []byte) (sm.Result, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Errorf("from StateMachine.Update() recover %v", err)
			debug.PrintStack()
		}
	}()

	// 解码数据
	reqs, _err := DecodeApplyRequests(data)
	if _err != nil {
		log.Errorf("from StateMachine.Update() decode error %v", _err)
		debug.PrintStack()
		// 此处不可返回 err，这会导致状态机重新加载数据（如程序重启）时产生panic。
		return sm.Result{}, nil
	}

	if len(reqs) <= 0 {
		return sm.Result{}, nil
	}

	var resultLogs []*protocol.Log
	for _, req := range reqs {
		log.Debugf("from StateMachine.Update() before req, type: %v, order: %v", req.Type, req.Order)

		switch ApplyType(req.Type) {
		case ApplyTypePlace:
			if req.Order == nil {
				continue
			}
			order, err2 := req.Order.Pd2Order()
			if err2 != nil {
				log.Errorf("from StateMachine.Update() place error:%v", err2)
				continue
			}
			logs := s.OrderBook.ExecuteOrder(order)
			resultLogs = append(resultLogs, logs...)
			// 设置成debug级别，logs序列化存在性能问题
			log.Debugf("from StateMachine.Update() place logs: %v", logs)
		case ApplyTypeCancel:
			if req.Order == nil {
				continue
			}
			order, err2 := req.Order.Pd2Order()
			if err2 != nil {
				log.Errorf("from StateMachine.Update() cancel error:%v", err2)
				continue
			}
			logs := s.OrderBook.CancelOrder(order)
			resultLogs = append(resultLogs, logs...)
			// 设置成debug级别，logs序列化存在性能问题
			log.Debugf("from StateMachine.Update() cancel logs: %v", logs)
		case ApplyTypeCancelUserOrders:
			userId := req.UserId
			var logs []*protocol.Log
			if userId > 0 {
				logs = s.OrderBook.CancelUserOrders(userId)
			}
			resultLogs = append(resultLogs, logs...)

			log.Infof("from StateMachine.Update() cancelUserOrders userId:%v, logs: %v", userId, logs)
		case ApplyTypeReset:
			reqReset := req.ApplyRequestReset
			matchlog, err := s.OrderBook.ResetOrderBook(reqReset.Symbol, reqReset.EmptyOrderBook, reqReset.Offset, reqReset.MqConsumeStatus, reqReset.WorkId)
			if err == nil {
				logs := []*protocol.Log{matchlog}
				resultLogs = append(resultLogs, logs...)
			} else {
				log.Errorf("from StateMachine.Update() reset error:%s", err.Error())
			}
			log.Infof("from StateMachine.Update() reset reset:%v, matchlog: %v", reqReset, matchlog)
		case ApplyTypeClearOrderBook:
			// todo 此处logs无需传递下去 后续在处理
			logs := s.OrderBook.OrderBookClear()
			resultLogs = append(resultLogs, logs...)
			log.Debugf("from StateMachine.Update() cancel req:%v, logs: %v", req.Type, logs)
		default:
			log.Errorf("ApplyRequest type error req:%v", req)
		}

	}

	var err error
	var lastSeq uint64
	var resultData []byte

	// 超过50分组发送
	groupMsgSize := 50
	msgLen := len(resultLogs)
	if msgLen > 0 {
		groupCnt := msgLen / groupMsgSize
		if groupCnt*groupMsgSize < msgLen {
			// 意味着有余数
			groupCnt++
		}
		for i := 0; i < groupCnt; i++ {
			begin := i * groupMsgSize
			end := (i + 1) * groupMsgSize
			if i == groupCnt-1 {
				end = msgLen
			}
			resultData, lastSeq, err = s.updateCall(resultLogs[begin:end])
			if err != nil {
				log.Errorf("from StateMachine.Update() updateCall fail reqs:%v, err:%v, begin:%d, end:%d, msgLen:%d", reqs, err, begin, end, msgLen)
			}
		}
	} else {
		log.Warnf("from StateMachine.Update() resultLogs empty reqs:%v", reqs)
	}

	return sm.Result{Value: lastSeq, Data: resultData}, nil
}

// SaveSnapshot saves the current IStateMachine state into a snapshot using the
// specified io.Writer object.
func (s *StateMachine) SaveSnapshot(w io.Writer,
	fc sm.ISnapshotFileCollection, done <-chan struct{}) error {

	var data []byte
	var err error
	if data, err = s.OrderBook.Snapshot(); err != nil {
		log.Errorf("SaveSnapshot snapshot %v", err)
		return err
	}
	_, err = w.Write(data)
	if err != nil {
		log.Errorf("SaveSnapshot write %v", err)
	}
	return err
}

// RecoverFromSnapshot recovers the state using the provided snapshot.
func (s *StateMachine) RecoverFromSnapshot(r io.Reader,
	files []sm.SnapshotFile, done <-chan struct{}) error {

	data, err := ioutil.ReadAll(r)
	if err != nil {
		log.Errorf("RecoverFromSnapshot read %v", err)
		return err
	}
	if err := s.OrderBook.Restore(data); err != nil {
		log.Errorf("RecoverFromSnapshot restore %v", err)
		return err
	}
	return nil
}

// Close closes the IStateMachine instance. There is nothing for us to cleanup
// or release as this is a pure in memory data store. Note that the Close
// method is not guaranteed to be called as node can crash at any time.
func (s *StateMachine) Close() error { return nil }

// GetHash returns a uint64 representing the current object state.
func (s *StateMachine) GetHash() (uint64, error) {
	// represents the state of this IStateMachine
	return s.OrderBook.GetSeq(), nil
}

// 状态机update返回的结果处理
func (s *StateMachine) updateCall(logs []*protocol.Log) ([]byte, uint64, error) {
	log.Debugf("from StateMachine.Update(), updateCall matchLogs: %v", logs)
	if len(logs) <= 0 {
		return nil, 0, ErrEmptyLogs
	}
	matchLogs := &protocol.MatchLogs{
		Logs: logs,
	}
	logsData, err := proto.Marshal(matchLogs)
	if err != nil {
		return nil, 0, errors.New(fmt.Sprintf("failed to Marshal cluster output: %s", err.Error()))
	}
	// leader推送撮合结果给下游
	if err := s.ApplyAfterFunc(logsData); err != nil {
		return nil, 0, errors.New(fmt.Sprintf("failed to ApplyAfterFunc output: %s", err.Error()))
	}
	lastSeq := logs[len(logs)-1].Sequence
	return logsData, lastSeq, nil
}
