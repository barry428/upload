package sys

import "strings"

var (
	macAddress string // 静态mac地址
	// 暂定先不使用
	interfaceName string // 网卡名称
)

func GetMacAddress() string {
	return strings.TrimSpace(macAddress)
}
func GetInterfaceName() string {
	return strings.TrimSpace(interfaceName)
}
