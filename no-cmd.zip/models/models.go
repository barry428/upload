package models

import (
	"fmt"
	"github.com/shopspring/decimal"
	"time"
)

var MIN_TRADE_VOL = decimal.NewFromFloat(0.00000001)
var MIN_TRADE_MONEY = decimal.NewFromFloat(0.00000001)

type Side string
type Status int32
type Type int32

const (
	MIN_TRADE_VOL_PRECISION = 8

	BUY  = Side("BUY")
	SELL = Side("SELL")

	STATUS_INIT           = Status(0)
	STATUS_NEW            = Status(1)
	STATUS_FILLED         = Status(2)
	STATUS_PART_FILLED    = Status(3)
	STATUS_CANCELED       = Status(4)
	STATUS_PENDING_CANCEL = Status(5)
	STATUS_EXPIRED        = Status(6)

	ORDER_LIMIT  = Type(1)
	ORDER_MARKET = Type(2)
	// 止盈止损
	ORDER_STOPLIMIT = Type(3)
	// 全部成交或立即取消
	ORDER_FOK = Type(4)
	// 只做maker
	ORDER_POST_ONLY = Type(5)
	// 立即成交并取消剩余
	ORDER_IOC = Type(6)

	// 从数据库恢复阶段
	FSM_STATUS_REBUILD = int64(0)
	// 从mq正常消费中
	FSM_STATUS_MQ = int64(1)
)

type Order struct {
	Id           uint64
	UserId       uint64
	Side         Side
	Price        decimal.Decimal `sql:"type:decimal(32,16);"`
	Volume       decimal.Decimal `sql:"type:decimal(32,16);"`
	FeeRateMaker float64
	FeeRateTaker float64
	FeeCoinRate  float64
	DealVolume   decimal.Decimal `sql:"type:decimal(32,16);"`
	DealMoney    decimal.Decimal `sql:"type:decimal(32,16);"`
	AvgPrice     decimal.Decimal `sql:"type:decimal(32,16);"`
	Status       Status
	Type         Type
	Source       int32
	OrderType    int32
	Ctime        time.Time
	CompanyId    uint64
	ClientOrderId string

	Symbol string `gorm:"-"`
	// 是否从数据库加载的订单，这种订单删除时orderbook不存在
	IsRebuild bool `gorm:"-"`

	// 拉取消订单消息offset， 取消订单时offset和创建订单的offset是不同的值
	Offset int64
}

// String 重写string 只输出部分信息，以加快日志输出
func (o *Order) String() string {
	return fmt.Sprintf("{id: %d, uid: %d, side: %s, status: %d, type: %d, source: %d, orderType: %d, companyId: %d, symbol: %s, isRebuild: %v, offset: %d}",
		o.Id, o.UserId, o.Side, o.Status, o.Type, o.Source, o.OrderType, o.CompanyId, o.Symbol, o.IsRebuild, o.Offset)
}

// Order2Pd 转换为撮合机pd对象
func (o *Order) Order2Pd() *PdOrder {
	// todo 暂定忽略错误
	price, _ := o.Price.GobEncode()
	volume, _ := o.Volume.GobEncode()
	dealVolume, _ := o.DealVolume.GobEncode()
	dealMoney, _ := o.DealMoney.GobEncode()
	avgPrice, _ := o.AvgPrice.GobEncode()

	pd := &PdOrder{
		Id:           o.Id,
		UserId:       o.UserId,
		Side:         string(o.Side),
		Price:        price,
		Volume:       volume,
		FeeRateMaker: o.FeeRateMaker,
		FeeRateTaker: o.FeeRateTaker,
		FeeCoinRate:  o.FeeCoinRate,
		DealVolume:   dealVolume,
		DealMoney:    dealMoney,
		AvgPrice:     avgPrice,
		Status:       int32(o.Status),
		Type:         int32(o.Type),
		Source:       o.Source,
		CompanyId:    o.CompanyId,
		OrderType:    o.OrderType,
		Ctime:        o.Ctime.UnixMilli(),
		Offset:       o.Offset,
		Symbol:       o.Symbol,
		ClientOrderId: o.ClientOrderId,
		IsRebuild:    o.IsRebuild,
	}
	return pd
}

// Pd2Order 撮合机pd对象转换为原对象
func (o *PdOrder) Pd2Order() (*Order, error) {
	var price decimal.Decimal
	var volume decimal.Decimal
	var dealVolume decimal.Decimal
	var dealMoney decimal.Decimal
	var avgPrice decimal.Decimal
	// todo 暂定忽略错误
	_ = price.GobDecode(o.Price)
	_ = volume.GobDecode(o.Volume)
	_ = dealVolume.GobDecode(o.DealVolume)
	_ = dealMoney.GobDecode(o.DealMoney)
	_ = avgPrice.GobDecode(o.AvgPrice)

	order := &Order{
		Id:           o.Id,
		UserId:       o.UserId,
		Side:         Side(o.Side),
		Price:        price,
		Volume:       volume,
		FeeRateMaker: o.FeeRateMaker,
		FeeRateTaker: o.FeeRateTaker,
		FeeCoinRate:  o.FeeCoinRate,
		DealVolume:   dealVolume,
		DealMoney:    dealMoney,
		AvgPrice:     avgPrice,
		Status:       Status(o.Status),
		Type:         Type(o.Type),
		Source:       o.Source,
		CompanyId:    o.CompanyId,
		OrderType:    o.OrderType,
		Ctime:        time.UnixMilli(o.Ctime),
		Offset:       o.Offset,
		Symbol:       o.Symbol,
		ClientOrderId: o.ClientOrderId,
		IsRebuild:    o.IsRebuild,
	}

	return order, nil
}

func (o Order) RemainVol() decimal.Decimal {
	if o.Type == ORDER_LIMIT || (o.Type == ORDER_MARKET && o.Side == SELL) ||
		o.Type == ORDER_STOPLIMIT || o.Type == ORDER_IOC || o.Type == ORDER_FOK || o.Type == ORDER_POST_ONLY {
		return o.Volume.Sub(o.DealVolume)
	}
	return decimal.Zero
}

func (o Order) RemainMoney() decimal.Decimal {
	if o.Type == ORDER_MARKET && o.Side == BUY {
		return o.Volume.Sub(o.DealMoney)
	}
	return decimal.Zero
}

func (o Order) IsFilled() bool {
	if o.Type == ORDER_MARKET && o.Side == BUY {
		remainMoney := o.Volume.Sub(o.DealMoney)
		return remainMoney.LessThan(MIN_TRADE_MONEY)
	} else {
		return o.RemainVol().LessThan(MIN_TRADE_VOL)
	}
}

type ConfigSymbolMatching struct {
	Id                uint64
	Base              string
	Quote             string
	IsOpen            int
	Server            string
	LiquidationServer string
	Ctime             time.Time
	Mtime             time.Time
	Workid            int64
	OperateLock       int64
	RunStatus         int64
	LastUptime        time.Time
}

// UserOrderCount 存储用户订单数量
type UserOrderCount map[string]map[uint64]int
