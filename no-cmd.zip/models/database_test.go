package models

import (
	"fmt"
	"testing"
)

func TestPersist_GetConfigSymbolMatching(t *testing.T) {
	p := GetPersist()
	res, err := p.GetConfigSymbolMatching("clusterx", "ETH-USDT")
	if err != nil {
		fmt.Println(err)
	}
	fmt.Printf("res %+v \n", res)
}

func TestPersist_GetConfigSymbolMatchings(t *testing.T) {
	in := []int{1}

	p := GetPersist()
	res, err := p.GetConfigSymbolMatchings("clusterx", in)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Printf("res %+v \n", res)
	for _, v := range res {
		fmt.Printf("res %+v \n", v)


	}
}
