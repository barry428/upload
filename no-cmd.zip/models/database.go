package models

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/conf"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jinzhu/gorm"
	"strings"
	"sync"
)

var persist *Persist
var exchangeDB *gorm.DB
var coreDB *gorm.DB
var dbOnce sync.Once

type Persist struct {
	exDB   *gorm.DB
	coreDB *gorm.DB
}

func GetPersist() *Persist {
	dbOnce.Do(func() {
		fmt.Printf("dbInitOnce...\n")
		err := initDb()
		if err != nil {
			panic(err)
		}
		persist = &Persist{exDB: exchangeDB, coreDB: coreDB}
	})

	return persist
}

func initDb() error {
	cfg := conf.GetConfig()
	var err error
	exchangeDB, err = gorm.Open("mysql", cfg.DB.ExchangeDsn)
	if err != nil {
		return err
	}
	exchangeDB.SingularTable(true)
	// exchange库使用很少，仅用来定时查询币对信息（1次/10s），可以设置较小的连接数和连接池中空闲连接数
	exchangeDB.DB().SetMaxIdleConns(2)
	exchangeDB.DB().SetMaxOpenConns(5)
	err = exchangeDB.DB().Ping()
	if err != nil {
		return err
	}

	coreDB, err = gorm.Open("mysql", cfg.DB.ExchangeCoreDsn)
	if err != nil {
		return err
	}
	coreDB.SingularTable(true)
	coreDB.DB().SetMaxIdleConns(cfg.DB.MaxIdle)
	coreDB.DB().SetMaxOpenConns(cfg.DB.MaxConn)
	err = coreDB.DB().Ping()
	if err != nil {
		return err
	}

	if log.IsDebug() {
		exchangeDB.LogMode(true)
		coreDB.LogMode(true)
	}
	return nil
}

// 获取开启且结算已经启动的币对：liquidationRunning 0 结算未运行 1 结算已运行
func (p *Persist) GetConfigSymbolMatchings(server string, runStatusIn []int) ([]*ConfigSymbolMatching, error) {
	var configSymbols []*ConfigSymbolMatching
	db := p.exDB.Where("server=? and is_open=1 and run_status IN (?)", server, runStatusIn).Order("id ASC")
	err := db.Find(&configSymbols).Error
	return configSymbols, err
}

func (p *Persist) GetConfigSymbolMatching(server string, symbol string) (*ConfigSymbolMatching, error) {
	base, quote := SplitSymbol(strings.ToUpper(symbol))
	var configSymbol ConfigSymbolMatching
	err := p.exDB.Raw("SELECT * FROM config_symbol_matching WHERE base=? and quote=? and server=? and is_open=1", base, quote, server).Scan(&configSymbol).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	return &configSymbol, err
}

func (p *Persist) GetConfigSymbolMatchingBySymbol(symbol string) (*ConfigSymbolMatching, error) {
	base, quote := SplitSymbol(strings.ToUpper(symbol))
	var configSymbol ConfigSymbolMatching
	err := p.exDB.Raw("SELECT * FROM config_symbol_matching WHERE base=? and quote=?", base, quote).Scan(&configSymbol).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	return &configSymbol, err
}

func (p *Persist) GetMaxOrderId(symbol string) (uint64, error) {
	cSymbol := CompactSymbol(strings.ToLower(symbol))
	var order Order
	err := p.coreDB.Raw(fmt.Sprintf("SELECT * FROM ex_order_%s order by id desc limit 1", cSymbol)).Scan(&order).Error
	if err == gorm.ErrRecordNotFound {
		return 0, nil
	}
	return order.Id, err
}

func (p *Persist) GetRebuildOrders(symbol string, beginId, maxOrderId, limit uint64) ([]*Order, error) {
	cSymbol := CompactSymbol(strings.ToLower(symbol))
	var orders []*Order
	db := p.coreDB.Table(fmt.Sprintf("ex_order_%s", cSymbol)).Where("status in(0, 1, 3, 5) and id<=? and id>?", maxOrderId, beginId).Order("id ASC").Limit(limit)
	err := db.Find(&orders).Error
	return orders, err
}
