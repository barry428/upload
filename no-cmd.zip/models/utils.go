package models

import (
	"fmt"
	"strings"
)

//转为紧凑的币对格式：ETH-USDT -> ETHUSDT
func CompactSymbol(symbol string) string {
	tmpStr := strings.Split(symbol, "-")
	return fmt.Sprintf("%s%s", tmpStr[0], tmpStr[1])
}

func SplitSymbol(symbol string) (string, string) {
	tmpStr := strings.Split(symbol, "-")
	return tmpStr[0], tmpStr[1]
}
