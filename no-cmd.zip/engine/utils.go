package engine

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/protocol"
	"chainup.com/chainup/chmatch/state"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/apache/rocketmq-client-go/core"
	"github.com/golang/protobuf/proto"
	"github.com/shopspring/decimal"
	"io/ioutil"
	"net/http"
	"runtime/debug"
	"strconv"
	"strings"
	"time"
)

func TopicNameMatchResult(symbol string) string {
	symbolTmp := strings.Split(strings.ToUpper(symbol), "-")
	return fmt.Sprintf("EXCHANGE_MATCHING_RESULTS_%s%s", symbolTmp[0], symbolTmp[1])
}

func TopicNameOrderProvider(symbol string) string {
	symbolTmp := strings.Split(strings.ToUpper(symbol), "-")
	return fmt.Sprintf("EXCHANGE_ORDER_TOPIC_%s%s", symbolTmp[0], symbolTmp[1])
}

// isPretty returns whether the HTTP response body should be pretty-printed.
func isPretty(req *http.Request) (bool, error) {
	return queryParam(req, "pretty")
}

// queryParam returns whether the given query param is set to true.
func queryParam(req *http.Request, param string) (bool, error) {
	err := req.ParseForm()
	if err != nil {
		return false, err
	}
	if _, ok := req.Form[param]; ok {
		return true, nil
	}
	return false, nil
}

// pb协议转为models.Order
func PbToOrder(msg *rocketmq.MessageExt) (order *models.Order, err error) {
	defer func() {
		if errR := recover(); errR != nil {
			log.Warnf("PbToOrder fail msg: |%+v|", msg)
			err = errors.New(fmt.Sprintf("PbToOrder recover err: %v", errR))
		}
	}()

	placeMsg := &protocol.PlaceOrderMessage{}
	if err = proto.Unmarshal([]byte(msg.Body), placeMsg); err != nil {
		return nil, err
	}
	log.Infof("PbToOrder QueueOffset: %d, placeMsg: %+v", msg.QueueOffset, placeMsg)

	orderMsg := placeMsg.Body
	order = &models.Order{
		IsRebuild: false,
		Offset:    msg.QueueOffset,
	}

	if order.Id, err = strconv.ParseUint(orderMsg.Id, 10, 64); err != nil {
		return nil, err
	}
	var statusInt int
	if statusInt, err = strconv.Atoi(orderMsg.Status); err != nil {
		return nil, err
	}
	order.Status = models.Status(statusInt)

	// 取消单只有状态和id
	if order.Status == models.STATUS_PENDING_CANCEL {
		return order, nil
	}

	if order.UserId, err = strconv.ParseUint(orderMsg.UserId, 10, 64); err != nil {
		return nil, err
	}
	order.Side = models.Side(strings.ToUpper(orderMsg.Side))
	if order.Price, err = decimal.NewFromString(orderMsg.Price); err != nil {
		return nil, err
	}
	if order.Volume, err = decimal.NewFromString(orderMsg.Volume); err != nil {
		return nil, err
	}
	if order.FeeRateMaker, err = strconv.ParseFloat(orderMsg.FeeRateMaker, 64); err != nil {
		return nil, err
	}
	if order.FeeRateTaker, err = strconv.ParseFloat(orderMsg.FeeRateTaker, 64); err != nil {
		return nil, err
	}
	if order.FeeCoinRate, err = strconv.ParseFloat(orderMsg.FeeCoinRate, 64); err != nil {
		return nil, err
	}

	var typeInt int
	if typeInt, err = strconv.Atoi(orderMsg.Type); err != nil {
		return nil, err
	}
	order.Type = models.Type(typeInt)
	var ctime int64
	if ctime, err = strconv.ParseInt(orderMsg.Ctime, 10, 64); err != nil {
		return nil, err
	}
	order.Ctime = time.Unix(ctime/1e3, 0)
	var atoi int
	atoi, err = strconv.Atoi(orderMsg.Source)
	if err != nil {
		return nil, err
	}
	order.Source = int32(atoi)

	atoi, err = strconv.Atoi(orderMsg.OrderType)
	if err != nil {
		return nil, err
	}
	order.OrderType = int32(atoi)

	// 白标改造，上游可能不传这个参数
	// if order.CompanyId, err = strconv.ParseUint(orderMsg.CompanyId, 10, 64); err != nil {
	// 	return nil, err
	// }
	if order.DealVolume, err = decimal.NewFromString(orderMsg.DealVolume); err != nil {
		return nil, err
	}
	if order.DealMoney, err = decimal.NewFromString(orderMsg.DealMoney); err != nil {
		return nil, err
	}
	if order.AvgPrice, err = decimal.NewFromString(orderMsg.AvgPrice); err != nil {
		return nil, err
	}
	order.Symbol = orderMsg.Symbol
	order.ClientOrderId = orderMsg.ClientOrderId

	return order, nil
}

// pbOrder协议转为models.Order
func PbOrderToOrder(pbOrder *protocol.Order, symbol string) (order *models.Order, err error) {
	defer func() {
		if errR := recover(); errR != nil {
			log.Warnf("PbOrderToOrder fail msg: |%+v|", pbOrder)
			err = errors.New(fmt.Sprintf("PbOrderToOrder recover err: %v", errR))
		}
	}()

	orderMsg := pbOrder
	offset := int64(-2)
	if offset, err = strconv.ParseInt(orderMsg.Offset, 10, 64); err != nil {
		return nil, err
	}
	order = &models.Order{
		IsRebuild: false,
		Offset:    offset,
	}

	if order.Id, err = strconv.ParseUint(orderMsg.Id, 10, 64); err != nil {
		return nil, err
	}
	var statusInt int
	if statusInt, err = strconv.Atoi(orderMsg.Status); err != nil {
		return nil, err
	}
	order.Status = models.Status(statusInt)

	// 取消单只有状态和id
	if order.Status == models.STATUS_PENDING_CANCEL {
		return order, nil
	}

	if order.UserId, err = strconv.ParseUint(orderMsg.UserId, 10, 64); err != nil {
		return nil, err
	}
	order.Side = models.Side(strings.ToUpper(orderMsg.Side))
	if order.Price, err = decimal.NewFromString(orderMsg.Price); err != nil {
		return nil, err
	}
	if order.Volume, err = decimal.NewFromString(orderMsg.Volume); err != nil {
		return nil, err
	}
	if order.FeeRateMaker, err = strconv.ParseFloat(orderMsg.FeeRateMaker, 64); err != nil {
		return nil, err
	}
	if order.FeeRateTaker, err = strconv.ParseFloat(orderMsg.FeeRateTaker, 64); err != nil {
		return nil, err
	}
	if order.FeeCoinRate, err = strconv.ParseFloat(orderMsg.FeeCoinRate, 64); err != nil {
		return nil, err
	}

	var typeInt int
	if typeInt, err = strconv.Atoi(orderMsg.Type); err != nil {
		return nil, err
	}
	order.Type = models.Type(typeInt)
	var ctime int64
	if ctime, err = strconv.ParseInt(orderMsg.Ctime, 10, 64); err != nil {
		return nil, err
	}
	order.Ctime = time.Unix(ctime/1e3, 0)

	var atoi int
	atoi, err = strconv.Atoi(orderMsg.Source)
	if err != nil {
		return nil, err
	}
	order.Source = int32(atoi)

	atoi, err = strconv.Atoi(orderMsg.OrderType)
	if err != nil {
		return nil, err
	}
	order.OrderType = int32(atoi)
	// 白标改造，上游可能不传CompanyId
	// if order.CompanyId, err = strconv.ParseUint(orderMsg.CompanyId, 10, 64); err != nil {
	// 	return nil, err
	// }
	if order.DealVolume, err = decimal.NewFromString(orderMsg.DealVolume); err != nil {
		return nil, err
	}
	if order.DealMoney, err = decimal.NewFromString(orderMsg.DealMoney); err != nil {
		return nil, err
	}
	if order.AvgPrice, err = decimal.NewFromString(orderMsg.AvgPrice); err != nil {
		return nil, err
	}
	order.Symbol = symbol

	return order, nil
}

func FormatApplyRequests(offsetorders *OffsetOrders) ([]*state.ApplyRequest, error) {
	var applyRequests []*state.ApplyRequest
	var err error
	for _, order := range offsetorders.Orders {
		if order.IsRebuild && order.Type == models.ORDER_MARKET {
			// 从数据库加载的市价单直接取消
			applyRequest := &state.ApplyRequest{Type: string(state.ApplyTypeCancel), Order: order.Order2Pd()}
			applyRequests = append(applyRequests, applyRequest)
		} else {
			if order.Status == models.STATUS_INIT || order.Status == models.STATUS_NEW || order.Status == models.STATUS_PART_FILLED {

				applyRequest := &state.ApplyRequest{Type: string(state.ApplyTypePlace), Order: order.Order2Pd()}
				applyRequests = append(applyRequests, applyRequest)
			} else if order.Status == models.STATUS_PENDING_CANCEL || order.Status == models.STATUS_EXPIRED {

				applyRequest := &state.ApplyRequest{Type: string(state.ApplyTypeCancel), Order: order.Order2Pd()}
				applyRequests = append(applyRequests, applyRequest)
			} else {
				err = errors.New("order status illegal")
				log.Errorf("order status illegal, order:%+v", *order)
				debug.PrintStack()
			}
		}
	}
	if len(applyRequests) > 0 {
		return applyRequests, nil
	}
	return nil, err
}

func Retry(attempts int, sleep time.Duration, fn func() error) error {
	if err := fn(); err != nil {
		if s, ok := err.(stop); ok {
			return s.error
		}

		if attempts--; attempts > 0 {
			log.Warnf("retry func error: %s. attemps #%d after %s.", err.Error(), attempts, sleep)
			time.Sleep(sleep)
			return Retry(attempts, 2*sleep, fn)
		}
		return err
	}
	return nil
}

type stop struct {
	error
}

func NoRetryError(err error) stop {
	return stop{err}
}

// 查询结算消费位置，只有结算没有消息积压时才能从数据库重启撮合
func QueryLiquidationConsumerOffset(symbol, mqConsoleAddr string) (err error) {
	//http://39.106.93.235:8081/consumer/queryTopicByConsumer.query?consumerGroup=Liquidation-BCHUSDT
	defer func() {
		if errR := recover(); errR != nil {
			err = errors.New(fmt.Sprintf("QueryLiquidationConsumerOffset recover err: %v", errR))
		}
	}()

	cSymbol := models.CompactSymbol(symbol)
	consumerGroup := fmt.Sprintf("Liquidation-%s", cSymbol)
	consumerTopic := fmt.Sprintf("EXCHANGE_MATCHING_RESULTS_%s", cSymbol)
	url := fmt.Sprintf("%s/consumer/queryTopicByConsumer.query?consumerGroup=%s", mqConsoleAddr, consumerGroup)
	client := http.Client{Timeout: 5 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	respBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if resp.StatusCode != 200 {
		return errors.New(fmt.Sprintf("queryTopicByConsumer status code not 200, url:%s", url))
	}
	log.Infof("queryTopicByConsumer url:%s, respBody:%s", url, string(respBody))
	mqMap := make(map[string]interface{})
	if err := json.Unmarshal(respBody, &mqMap); err != nil {
		return err
	}
	mqData, ok := mqMap["data"]
	if !ok {
		log.Warnf("queryTopicByConsumer fail respBody:%s", string(respBody))
		return errors.New("queryTopicByConsumer resp fail")
	}
	_mqData, ok := mqData.([]interface{})
	if !ok {
		log.Warnf("queryTopicByConsumer fail. symbol:%+v, data:%+v", symbol, mqMap)
		return errors.New("queryTopicByConsumer resp fail")
	}
	for _, v := range _mqData {
		if v.(map[string]interface{})["topic"].(string) == consumerTopic {
			diffTotal := v.(map[string]interface{})["diffTotal"].(float64)
			if diffTotal <= 0 {
				return nil
			}
		}
	}
	log.Debugf("queryTopicByConsumer diffTotal not less than or equal to 0. symbol:%+v, data:%+v", symbol, mqMap)
	return errors.New("queryTopicByConsumer diffTotal not less than or equal to 0")
}
