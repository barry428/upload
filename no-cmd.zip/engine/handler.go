package engine

import (
	log "chainup.com/chainup/chmatch/common/logger"
	metrics2 "chainup.com/chainup/chmatch/common/metrics"
	"chainup.com/chainup/chmatch/conf"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/protocol"
	"chainup.com/chainup/chmatch/state"
	"encoding/json"
	"fmt"
	"github.com/VictoriaMetrics/metrics"
	"github.com/golang/protobuf/proto"
	"io/ioutil"
	"net/http"
	"net/url"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Response represents a response from the HTTP service.
type Response struct {
	Results interface{} `json:"results,omitempty"`
	Error   string      `json:"error,omitempty"`
	Time    float64     `json:"time,omitempty"`

	start time.Time
	end   time.Time
}

// SetTime sets the Time attribute of the response. This way it will be present
// in the serialized JSON version.
func (r *Response) SetTime() {
	r.Time = r.end.Sub(r.start).Seconds()
}

type ApiService struct {
	service Service
	start   time.Time // Start up time.

	Pprof        bool
	BuildInfo    map[string]interface{}
	pprofHandler http.Handler
}

// New returns an uninitialized HTTP service.
func newApiService(service Service) *ApiService {
	return &ApiService{
		service: service,
		start:   time.Now(),
		Pprof:   true,
	}
}

// 实现Handle 方法
func (s *ApiService) Handle(w http.ResponseWriter, r *http.Request) {
	defer func() {
		err := recover()
		if err != nil {
			log.Infof("ServeHTTP catch a panic, err:%v", err)
			debug.PrintStack()
		}
	}()
	log.Infof("ServeHTTP, path=%v", r.URL.Path)

	switch {
	case strings.HasPrefix(r.URL.Path, "/queryDepth"):
		s.handleQueryDepth(w, r)
	case strings.HasPrefix(r.URL.Path, "/execOrders"):
		s.handleExecOrders(w, r)
	case strings.HasPrefix(r.URL.Path, "/cancelUserOrders"):
		s.handleCancelUserOrders(w, r)
	case strings.HasPrefix(r.URL.Path, "/queryUserOrders"):
		s.handleQueryUserOrders(w, r)
	case strings.HasPrefix(r.URL.Path, "/queryUsers"):
		s.handleQueryUsers(w, r)
	case strings.HasPrefix(r.URL.Path, "/queryUserOrderIds"):
		s.handleQueryUserOrderIds(w, r)
	case strings.HasPrefix(r.URL.Path, "/queryOrder"):
		s.handleQueryOrder(w, r)
	case strings.HasPrefix(r.URL.Path, "/resetSymbol"):
		s.handleResetSymbol(w, r)
	case strings.HasPrefix(r.URL.Path, "/closeSymbol"):
		s.handleCloseSymbol(w, r)
	case strings.HasPrefix(r.URL.Path, "/openSymbol"):
		s.handleOpenSymbol(w, r)
	case strings.HasPrefix(r.URL.Path, "/ctlSymbol"):
		s.handleCtlSymbol(w, r)
	case strings.HasPrefix(r.URL.Path, "/addSymbol"):
		s.handleAddSymbol(w, r)
	case strings.HasPrefix(r.URL.Path, "/status"):
		s.handleStatus(w, r)
	case strings.HasPrefix(r.URL.Path, "/metrics"):
		s.handleMetrics(w, r)
	default:
		w.WriteHeader(http.StatusNotFound)
	}
}

// metric监控
func (s *ApiService) handleMetrics(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")

	if r.Method != "GET" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	metrics.WritePrometheus(w, true)
	// 采集其他指标
	engine, ok := s.service.(*Engine)
	if !ok {
		return
	}
	symbols := 0
	engine.markets.Range(func(_, _ interface{}) bool {
		symbols++
		return true
	})

	_, _ = fmt.Fprintf(w, `match_symbol_count %d`+"\n", symbols)
	_, _ = fmt.Fprintf(w, `match_start_time_seconds %d`+"\n", s.start.Unix())
	_, _ = fmt.Fprintf(w, `match_received_order_count %d`+"\n", metrics2.GetReceivedOrders())
	_, _ = fmt.Fprintf(w, `match_trade_count %d`+"\n", metrics2.GetTradeOrder())
	_, _ = fmt.Fprintf(w, `match_send_log_count %d`+"\n", metrics2.GetSendLogs())
	// dragonboat.WriteHealthMetrics(w, true)
}

// 查询进程状态
func (s *ApiService) handleStatus(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")

	if r.Method != "GET" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	rt := map[string]interface{}{
		"GOARCH":        runtime.GOARCH,
		"GOOS":          runtime.GOOS,
		"GOMAXPROCS":    runtime.GOMAXPROCS(0),
		"num_cpu":       runtime.NumCPU(),
		"num_goroutine": runtime.NumGoroutine(),
		"version":       runtime.Version(),
	}

	nodeStatus := s.service.Status()

	// Build the status response.
	status := map[string]interface{}{
		"runtime":   rt,
		"nodeinfo":  nodeStatus,
		"starttime": s.start,
	}

	if s.BuildInfo != nil {
		status["build"] = s.BuildInfo
	}

	resp := &Response{start: time.Now()}
	resp.Results = status
	writeResponse(w, r, resp)
}

func (s *ApiService) handleExecuteTest(w http.ResponseWriter, r *http.Request) {
	log.Infof("handleExecuteTest...")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")

	//if r.Method != "POST" {
	//	w.WriteHeader(http.StatusMethodNotAllowed)
	//	return
	//}

	resp := &Response{start: time.Now()}

	//b, err := ioutil.ReadAll(r.Body)
	//if err != nil {
	//	http.Error(w, err.Error(), http.StatusBadRequest)
	//	return
	//}
	//r.Body.Close()

	params, _ := url.ParseQuery(r.URL.RawQuery)

	var m, n int
	m = 5
	n = 10
	if mStr := strings.TrimSpace(params.Get("m")); mStr != "" {
		m, _ = strconv.Atoi(mStr)
	}
	if nStr := strings.TrimSpace(params.Get("n")); nStr != "" {
		n, _ = strconv.Atoi(nStr)
	}

	req := &state.QueryRequest{
		Type: state.ApplyTypeQueryDepth,
	}

	symbol := "BTC1-USDT"

	log.Infof("params %v m %d, n %d", params, m, n)
	begin := time.Now()
	market, _ := s.service.GetMarket(symbol)
	beginRet, _ := s.service.SyncRead(market.id, req)
	log.Infof("begin time: %v, results: %v", begin, beginRet)

	cs, _ := s.service.GetSession(symbol)
	wg := sync.WaitGroup{}
	for i := 0; i < m; i++ {
		wg.Add(1)
		go func(w *sync.WaitGroup, i int) {
			for j := 0; j < n; j++ {
				//log.Infof("i=%d, j=%d", i, j)
				_, err := s.service.SyncPropose(cs, []byte(""))
				if err != nil {
					log.Errorf("Place fail, %s", err.Error())
				}
			}
			w.Done()
		}(&wg, i)
	}
	wg.Wait()

	end := time.Now()
	endRet, _ := s.service.SyncRead(market.id, req)
	log.Infof("end time: %v, results: %v", end, endRet)

	spend := end.Sub(begin)
	log.Infof("handleExecuteTest spend: %v", spend.Seconds())

	writeResponse(w, r, resp)
}

// 通用读取
func (s *ApiService) read(params url.Values, symbol string, req *state.QueryRequest) (results []byte, err error) {
	isSync := false
	if qStr := strings.TrimSpace(params.Get("sync")); qStr == "true" {
		isSync = true
	}
	market, _ := s.service.GetMarket(symbol)
	if market == nil {
		return nil, fmt.Errorf("symbol match not run")
	}
	if isSync {
		results, err = s.service.SyncRead(market.id, req)
	} else {
		results, err = s.service.StaleRead(market.id, req)
	}
	return results, err
}

// 查询深度
func (s *ApiService) handleQueryDepth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" && r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	resp := &Response{start: time.Now()}

	var symbol string
	params := r.URL.Query()
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}

	var err error
	req := &state.QueryRequest{Type: state.ApplyTypeQueryDepth}

	var results []byte
	if results, err = s.read(params, symbol, req); err != nil {
		resp.Error = err.Error()
	} else {
		matchLogs := &protocol.MatchLogs{}
		if err = proto.Unmarshal(results, matchLogs); err != nil {
			resp.Error = err.Error()
		} else {
			resp.Results = matchLogs
		}
	}

	resp.end = time.Now()
	writeResponse(w, r, resp)
}

// 查询用户订单数量
func (s *ApiService) handleQueryUsers(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" && r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	resp := &Response{start: time.Now()}

	var symbol string
	params := r.URL.Query()
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}

	var err error
	var results []byte
	req := &state.QueryRequest{Type: state.ApplyTypeQueryUsers}
	if results, err = s.read(params, symbol, req); err != nil {
		resp.Error = err.Error()
	} else {
		matchLogs := models.UserOrderCount{}
		if err = json.Unmarshal(results, &matchLogs); err != nil {
			resp.Error = err.Error()
		} else {
			resp.Results = matchLogs
		}
	}
	resp.end = time.Now()
	writeResponse(w, r, resp)
}

// 查询用户订单
func (s *ApiService) handleQueryUserOrders(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" && r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	var symbol string
	var userId uint64
	params := r.URL.Query()
	log.Infof("handleQueryUserOrders params %+v", params)
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	if qStr := strings.TrimSpace(params.Get("uid")); qStr != "" {
		userId, _ = strconv.ParseUint(qStr, 10, 64)
	}

	var err error
	var results []byte
	req := &state.QueryRequest{Type: state.ApplyTypeQueryUserOrders, UserId: userId}
	if results, err = s.read(params, symbol, req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	} else {
		if len(results) <= 0 {
			writeResponse(w, r, &([]interface{}{}))
			return
		}
		userOrders := &protocol.UserOrders{}
		if err = proto.Unmarshal(results, userOrders); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		} else {
			log.Infof("userOrders: %+v", userOrders)
			writeResponse(w, r, &(userOrders.Orders))
		}
	}
}

// 查询用户订单IDs
func (s *ApiService) handleQueryUserOrderIds(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" && r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	var symbol string
	var userId uint64
	params := r.URL.Query()
	log.Infof("handleQueryUserOrders params %+v", params)
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	if qStr := strings.TrimSpace(params.Get("uid")); qStr != "" {
		userId, _ = strconv.ParseUint(qStr, 10, 64)
	}

	var err error
	var results []byte
	req := &state.QueryRequest{Type: state.ApplyTypeQueryUserOrderIds, UserId: userId}
	if results, err = s.read(params, symbol, req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	} else {
		if len(results) <= 0 {
			ret := make(map[string]string)
			writeResponse(w, r, &ret)
			return
		}
		userOrderIds := &protocol.UserOrderIds{}
		if err = proto.Unmarshal(results, userOrderIds); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		} else {
			log.Infof("userOrderIds: %+v", userOrderIds)
			writeResponse(w, r, &(userOrderIds))
		}
	}
}

// 查询单个订单
func (s *ApiService) handleQueryOrder(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" && r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	var symbol string
	var orderId uint64
	params := r.URL.Query()
	log.Infof("handleQueryUserOrders params %+v", params)
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	if qStr := strings.TrimSpace(params.Get("oid")); qStr != "" {
		orderId, _ = strconv.ParseUint(qStr, 10, 64)
	}

	var err error
	var results []byte
	req := &state.QueryRequest{Type: state.ApplyTypeQueryOrder, OrderId: orderId}
	if results, err = s.read(params, symbol, req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	} else {
		if len(results) <= 0 {
			writeResponse(w, r, &([]interface{}{}))
			return
		}
		userOrders := &protocol.UserOrders{}
		if err = proto.Unmarshal(results, userOrders); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		} else {
			log.Infof("userOrders: %+v", userOrders)
			writeResponse(w, r, &(userOrders.Orders))
		}
	}

}

// 执行订单，place或者cancel
func (s *ApiService) handleExecOrders(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" && r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	var symbol string
	params := r.URL.Query()
	log.Infof("handleExecOrder params %+v", params)
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, fmt.Sprintf("read body err, %v\n", err), http.StatusBadRequest)
		return
	}

	var pbOrders []*protocol.Order
	if err = json.Unmarshal(body, &pbOrders); err != nil {
		http.Error(w, fmt.Sprintf("Unmarshal err, %v\n", err), http.StatusBadRequest)
		return
	}

	resp := &Response{start: time.Now()}
	market, _ := s.service.GetMarket(symbol)
	if market != nil {
		cs, err := s.service.GetSession(symbol)
		if err != nil {
			http.Error(w, fmt.Sprintf("exec order fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}
		if len(pbOrders) <= 0 {
			http.Error(w, "exec order fail.(order size = 0)", http.StatusInternalServerError)
			return
		}
		offsetOrders := &OffsetOrders{
			BeginOffset: -2,
			EndOffset:   -2,
		}
		for _, pbOrder := range pbOrders {
			order, err := PbOrderToOrder(pbOrder, symbol)
			if err != nil {
				log.Warnf("exec order fail. pbOrder: %+v, err: %s", pbOrder, err.Error())
				continue
			}
			if order.Offset >= 0 {
				order.IsRebuild = false
			} else {
				order.IsRebuild = true
			}
			offsetOrders.Orders = append(offsetOrders.Orders, order)
		}

		applyRequests, err := FormatApplyRequests(offsetOrders)
		if err != nil {
			http.Error(w, fmt.Sprintf("exec order fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}
		if len(applyRequests) <= 0 {
			http.Error(w, fmt.Sprintf("exec order fail. nothing need exec."), http.StatusInternalServerError)
			return
		}
		reqByte, err := state.EncodeApplyRequests(applyRequests)
		if err != nil {
			http.Error(w, fmt.Sprintf("exec order fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}

		matchLogs, err := s.service.SyncPropose(cs, reqByte)
		if err != nil {
			http.Error(w, fmt.Sprintf("exec order fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}

		logsPb := &protocol.MatchLogs{}
		if err := proto.Unmarshal(matchLogs, logsPb); err != nil {
			http.Error(w, fmt.Sprintf("exec order fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}
		log.Infof("handleExecOrder symbol: %s, matchLogs: %v", symbol, logsPb)

		resp.Results = logsPb
		writeResponse(w, r, resp)
	} else {
		http.Error(w, "symbol match not run.", http.StatusBadRequest)
		return
	}
}

// 批量取消用户订单
func (s *ApiService) handleCancelUserOrders(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" && r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	var symbol string
	var userId uint64
	params := r.URL.Query()
	log.Infof("handleCancelUserOrders params %+v", params)
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	if qStr := strings.TrimSpace(params.Get("uid")); qStr != "" {
		userId, _ = strconv.ParseUint(qStr, 10, 64)
	}

	market, _ := s.service.GetMarket(symbol)
	if market != nil {
		cs, err := s.service.GetSession(symbol)
		if err != nil {
			http.Error(w, fmt.Sprintf("cancel fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}

		applyRequests := []*state.ApplyRequest{
			{Type: string(state.ApplyTypeCancelUserOrders), UserId: userId},
		}
		reqByte, err := state.EncodeApplyRequests(applyRequests)
		if err != nil {
			http.Error(w, fmt.Sprintf("cancel fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}

		matchLogs, err := s.service.SyncPropose(cs, reqByte)
		if err != nil {
			http.Error(w, fmt.Sprintf("cancel fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}
		logsPb := &protocol.MatchLogs{}
		if err := proto.Unmarshal(matchLogs, logsPb); err != nil {
			http.Error(w, fmt.Sprintf("cancel fail.(%s)", err.Error()), http.StatusInternalServerError)
			return
		}
		log.Infof("handleCancelUserOrders symbol: %s, matchLogs: %v", symbol, logsPb)
		var userOrders []*protocol.Order
		for _, _log := range logsPb.Logs {
			if _log.Type == "done" {
				userOrders = append(userOrders, _log.Done.Order)
			}
		}
		log.Infof("userOrders: %+v", userOrders)
		if len(userOrders) <= 0 {
			writeResponse(w, r, &([]interface{}{}))
			return
		}
		writeResponse(w, r, &userOrders)
	} else {
		http.Error(w, "symbol match not run.", http.StatusBadRequest)
		return
	}
}

// 新加币对
func (s *ApiService) handleAddSymbol(w http.ResponseWriter, r *http.Request) {
	//log.Println("handleQuery...")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	resp := &Response{start: time.Now()}

	var symbol string
	params := r.URL.Query()
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = qStr
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}

	clusterName := conf.GetConfig().ClusterName
	p := models.GetPersist()
	configSymbol, err := p.GetConfigSymbolMatching(clusterName, symbol)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if configSymbol != nil {
		if err := s.service.AddSymbol(configSymbol); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		time.Sleep(time.Second)
		req := &state.QueryRequest{
			Type: state.ApplyTypeQueryDepth,
		}
		symbolId := configSymbol.Id
		results, err := s.service.SyncRead(symbolId, req)
		if err != nil {
			resp.Error = err.Error()
		} else {
			matchLogs := &protocol.MatchLogs{}
			proto.Unmarshal(results, matchLogs)
			resp.Results = matchLogs
		}
		resp.end = time.Now()
	} else {
		resp.Error = "symbol not exist"
	}

	writeResponse(w, r, resp)
}

// 1、将orderbook的offset设置为mq的maxoffset
// 2、（可选）清空orderbook
func (s *ApiService) handleResetSymbol(w http.ResponseWriter, r *http.Request) {
	//log.Println("handleQuery...")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	resp := &Response{start: time.Now()}

	var symbol string
	params := r.URL.Query()
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = strings.ToUpper(qStr)
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	log.Infof("handleResetSymbol params %+v", params)
	market, err := s.service.GetMarket(symbol)
	if err != nil {
		http.Error(w, "币对不存在.", http.StatusBadRequest)
		return
	}

	market.consumeCmdChan <- ConsumeCmdReset
	resp.end = time.Now()
	resp.Results = "ok"
	writeResponse(w, r, resp)
}

// 手动关闭币对
func (s *ApiService) handleCloseSymbol(w http.ResponseWriter, r *http.Request) {
	//log.Println("handleQuery...")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	resp := &Response{start: time.Now()}

	var symbol string
	params := r.URL.Query()
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = strings.ToUpper(qStr)
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	log.Infof("handleCloseSymbol params %+v", params)

	market, err := s.service.GetMarket(symbol)
	if err != nil {
		http.Error(w, "币对不存在.", http.StatusBadRequest)
		return
	}

	resp.Results = "ok"
	if err := s.service.RemoveGroup(market); err != nil {
		log.Errorf("RemoveGroup fail, err:%v", err.Error())
		resp.Results = err.Error()
	}
	resp.end = time.Now()
	writeResponse(w, r, resp)
}

// 手动开启币对
func (s *ApiService) handleOpenSymbol(w http.ResponseWriter, r *http.Request) {
	//log.Println("handleQuery...")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	resp := &Response{start: time.Now()}

	var symbol string
	params := r.URL.Query()
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = strings.ToUpper(qStr)
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	log.Infof("handleOpenSymbol params %+v", params)

	resp.Results = "ok"
	p := models.GetPersist()
	clusterName := conf.GetConfig().ClusterName
	configSymbolMatching, err := p.GetConfigSymbolMatching(clusterName, symbol)
	if err != nil || configSymbolMatching == nil {
		http.Error(w, "币对不存在.", http.StatusBadRequest)
		return
	}
	if err := s.service.AddGroup(configSymbolMatching); err != nil {
		log.Errorf("addGroup failed to add cluster, %+v %v", configSymbolMatching, err)
		resp.Results = err.Error()
	}
	resp.end = time.Now()
	writeResponse(w, r, resp)
}

// 币对order消费控制
func (s *ApiService) handleCtlSymbol(w http.ResponseWriter, r *http.Request) {
	//log.Println("handleQuery...")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != "GET" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	resp := &Response{start: time.Now()}

	var symbol string
	var cmd string
	params := r.URL.Query()
	if qStr := strings.TrimSpace(params.Get("symbol")); qStr != "" {
		symbol = strings.ToUpper(qStr)
	} else {
		http.Error(w, "symbol required.", http.StatusBadRequest)
		return
	}
	if qStr := strings.TrimSpace(params.Get("cmd")); qStr != "" {
		cmd = strings.ToUpper(qStr)
	}
	log.Infof("handleCtlSymbol params %+v", params)

	market, err := s.service.GetMarket(symbol)
	if err != nil {
		http.Error(w, "币对不存在.", http.StatusBadRequest)
		return
	}

	if cmd == "STARTCONSUME" {
		market.isRunning = true
	} else if cmd == "STOPCONSUME" {
		market.isRunning = false
	}
	log.Infof("handleCtlSymbol market:%+v", *market)

	resp.Results = "ok"
	resp.end = time.Now()
	writeResponse(w, r, resp)
}

func writeResponse(w http.ResponseWriter, r *http.Request, j interface{}) {
	var b []byte
	var err error
	pretty, _ := isPretty(r)

	if pretty {
		b, err = json.MarshalIndent(j, "", "    ")
	} else {
		b, err = json.Marshal(j)
	}

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	_, err = w.Write(b)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}
