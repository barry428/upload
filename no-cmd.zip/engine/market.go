package engine

import (
	"chainup.com/chainup/chmatch/models"
	"context"
	"fmt"
	"sync"
)

type ConsumeCmd string

const (
	//订单消费控制类型
	ConsumeCmdReset = ConsumeCmd("reset")

	// OffsetOrdersSize 单次批量撮合订单数 理论最优测试值为20
	OffsetOrdersSize = 20
)

type OffsetOrders struct {
	BeginOffset int64
	EndOffset   int64
	Symbol      string
	Orders      []*models.Order
}

// 币对状态管理
type Market struct {
	id     uint64 //集群id，一个集群对应一个币对
	symbol string
	// 读取的order会写入chan，写入order的同时需要携带该order的offset
	orderCh chan *OffsetOrders

	// log写入队列，所有待写入的log需要进入该chan等待
	logCh chan []byte

	//是否停止mq订单消息:true 正常拉取 false 停止
	isPullMQ bool
	// 从mq拉取订单消息消息的位置：下一个开始拉的offset
	offset int64
	//币对的撮合暂停开关：true 持续撮合， false 停止撮合
	isRunning bool

	// 控制该币对的所有协程退出：集群关闭、订单消费、撮合结果发送
	cancel context.CancelFunc
	//ctx context.Context

	// 是否准备好消费：第一次需要判断消费位置, 更新读取需要加锁，多个地方更新
	ready bool

	//更新market状态的时候需要加锁
	mu sync.Mutex

	//控制订单消费指令：reset从数据库重建
	consumeCmdChan chan ConsumeCmd

	a map[int]int
}

func (m *Market) SetReady(ready bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.ready = ready
}

func (m *Market) IsReady() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.ready
}

func (m *Market) String() string {
	return fmt.Sprintf(" {id: %d, symbol: %s, isPullMQ: %v, offset: %v, isRunning: %v, ready: %v} ",
		m.id, m.symbol, m.isPullMQ, m.offset, m.isRunning, m.ready)
}

func NewMarket(symbol string, symbolId uint64) *Market {
	return &Market{
		id:             symbolId,
		symbol:         symbol,
		orderCh:        make(chan *OffsetOrders, ORDER_CHAN_SIZE),
		logCh:          make(chan []byte, 128),
		isPullMQ:       false,
		offset:         -2, //刚开始给一个不合法的offset
		isRunning:      true,
		ready:          false,
		consumeCmdChan: make(chan ConsumeCmd, 1),
	}
}
