package engine

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/state"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/apache/rocketmq-client-go/core"
	"io/ioutil"
	"net/http"
	"os"
	"runtime/debug"
	"strconv"
	"strings"
	"time"
)

const ERRSLEEP time.Duration = time.Second * 3

type rocketMQProvider struct {
	// 是否可写入： true 允许消费， false 禁止消费
	service    Service
	consumer   rocketmq.PullConsumer
	consoleUrl string
	noMsgSleep int64
}

func NewRocketMQProvider(nameServerAddr, consoleUrl string, noMsgSleep int64, service Service) *rocketMQProvider {
	pConfig := &rocketmq.PullConsumerConfig{
		ClientConfig: rocketmq.ClientConfig{
			GroupID:    "chmatch_provider",
			NameServer: nameServerAddr,
		},
	}
	consumer, err := rocketmq.NewPullConsumer(pConfig)
	if err != nil {
		log.Errorf("new pull consumer error: %v", err)
		os.Exit(1)
	}

	err = consumer.Start()
	if err != nil {
		log.Errorf("start consumer error: %v", err)
		os.Exit(1)
	}

	return &rocketMQProvider{consumer: consumer, service: service, consoleUrl: consoleUrl, noMsgSleep: noMsgSleep}
}

func (p *rocketMQProvider) StartConsume(market *Market, ctx context.Context) error {
	log.Warnf("StartConsume before, market: %+v", market)
	defer func() {
		if err := recover(); err != nil {
			debug.PrintStack()
			log.Errorf("StartConsume recover, market: %v, err: %v", market, err)
		}
	}()

	symbol := market.symbol
	marketId := market.id
	persist := models.GetPersist()

	// 从数据库重建的最大订单id
	maxOrderDbId := uint64(0)
	//从数据库加载的分页起始订单id
	beginLoadOrderId := uint64(0)
	// 是否需要从从状态机同步offset
	needUpdateOffset := true
Loop:
	for {
		select {
		case <-ctx.Done():
			log.Warnf("StartConsume close, symbol:%s, market: %+v", symbol, market)
			break Loop
		case consumeCmd := <-market.consumeCmdChan:
			log.Infof("consumeCmdChan before symbol: %s， consumeCmd： %v", symbol, consumeCmd)
			if consumeCmd == ConsumeCmdReset {
				market.SetReady(false)
				market.isPullMQ = false

				// 重置FMS为从数据库重建
				if p.service.IsLeader(marketId) {
					//设置状态机开始从数据库重建，停止mq消费
					if err := p.setFSMStatusRebuild(symbol, marketId, 0); err != nil {
						log.Errorf("StartConsume ConsumeCmdReset setFSMStatusRebuild err, symbol: %s, err: %v", symbol, err)
						time.Sleep(ERRSLEEP)
						continue
					}
					log.Infof("ConsumeCmdReset succ symbol: %s", symbol)
				}
			}
		default:
			if !market.isRunning {
				log.Warnf("StartConsume ready isRunningOff, symbol: %s, market: %+v", symbol, market)
				needUpdateOffset = true
				time.Sleep(ERRSLEEP)
				continue
			}
			if !p.service.IsLeader(marketId) {
				// leader发生变化时下次拉取需要从状态机同步offset
				needUpdateOffset = true
				time.Sleep(ERRSLEEP)
				continue
			}

			// 如果是第一次执行消费，需要判断其实位置
			if !market.IsReady() {
				needUpdateOffset = true
				//从状态机获取最后一次消费位置
				offsetFSM, statusFSM, err := p.getOffsetFSM(market.id)
				if err != nil {
					log.Errorf("StartConsume ready getOffsetFSM, symbol: %s, err: %v", symbol, err)
					time.Sleep(ERRSLEEP)
					continue
				}
				log.Infof("StartConsume ready getOffsetFSM, symbol: %s, market: %+v, offsetFSM: %+v, statusFSM: %+v", symbol, market, offsetFSM, statusFSM)

				if offsetFSM >= -1 && statusFSM == models.FSM_STATUS_MQ {
					//状态机offset>0有效时，且消费状态是从mq消费
					market.offset = offsetFSM + 1
					market.isPullMQ = true
					log.Infof("StartConsume ready offsetFSM>-1, symbol: %s, market: %+v", symbol, market)
				} else {
					log.Infof("StartConsume ready rebuild before , symbol: %s", symbol)
					//从数据库启动逻辑

					if len(p.consoleUrl) > 8 {
						// 查询mq控制台确保结算积压消息消费完
						err := QueryLiquidationConsumerOffset(symbol, p.consoleUrl)
						if err != nil {
							log.Errorf("StartConsume ready rebuild QueryLiquidationConsumerOffset symbol:%s, err: %v, market: %+v", symbol, err, market)
							time.Sleep(ERRSLEEP)
							continue
						}
					}

					// 获取数据库最大订单id
					maxOrderId, err := persist.GetMaxOrderId(symbol)
					log.Infof("StartConsume ready rebuildDB GetMaxOrderId, symbol: %s, maxOrderId: %+v", symbol, maxOrderId)
					if err != nil {
						log.Errorf("StartConsume ready GetMaxOrderId err, symbol: %s, err: %v", symbol, err)
						time.Sleep(ERRSLEEP)
						continue
					}

					// 记下此时的maxoffset
					maxOffset, err := p.maxOffset(symbol)
					log.Infof("StartConsume ready rebuildDB maxOffset, symbol: %s, maxOffset: %+v", symbol, maxOffset)
					if err != nil {
						log.Errorf("StartConsume ready first get maxOffset err, symbol: %s, err: %v, market:%+v", symbol, err, market)
						time.Sleep(ERRSLEEP)
						continue
					}

					//设置状态机开始从数据库重建，停止mq消费
					workId := time.Now().Unix()
					if err := p.setFSMStatusRebuild(symbol, marketId, workId); err != nil {
						log.Errorf("StartConsume ready setFSMStatusRebuild err, symbol: %s, err: %v", symbol, err)
						time.Sleep(ERRSLEEP)
						continue
					}

					market.offset = maxOffset
					maxOrderDbId = maxOrderId
					beginLoadOrderId = uint64(0)
				}
				market.SetReady(true)
				log.Infof("StartConsume ready ok, symbol: %s, maxOrderDbId: %v, market: %+v", symbol, maxOrderDbId, market)
				continue
			}

			if market.isPullMQ {
				if needUpdateOffset {
					offsetFSM2, statusFSM2, err := p.getOffsetFSM(market.id)
					log.Infof("StartConsume needUpdateOffset 1, symbol: %s, offsetFSM2: %v, statusFSM2: %v", symbol, offsetFSM2, statusFSM2)
					if err != nil {
						log.Errorf("StartConsume getOffsetFSM err: %v", err)
						time.Sleep(ERRSLEEP)
						continue
					}
					if offsetFSM2 < -1 {
						log.Errorf("StartConsume getOffsetFSM offset<=0, offsetFSM2: %v, statusFSM2: %v, symbol: %v", offsetFSM2, statusFSM2, symbol)
						time.Sleep(ERRSLEEP)
						continue
					}
					if statusFSM2 != models.FSM_STATUS_MQ {
						log.Errorf("StartConsume getOffsetFSM FSM_STATUS_MQ, offsetFSM2: %v, statusFSM2: %v, symbol: %v", offsetFSM2, statusFSM2, symbol)
						time.Sleep(ERRSLEEP)
						continue
					}
					market.offset = offsetFSM2 + 1
					log.Infof("StartConsume needUpdateOffset 2, symbol: %s, offsetFSM2: %d, offset: %d", symbol, offsetFSM2, market.offset)
				}
				err := p.pullMQ(market)
				if err != nil {
					log.Warnf("StartConsume pullMQ fail, symbol: %s, err: %v, market:%+v", symbol, err, market)
					time.Sleep(ERRSLEEP)
				}
				needUpdateOffset = false
			} else {
				log.Infof("StartConsume Leader build fromDB, symbol:%s, beginLoadOrderId:%v", symbol, beginLoadOrderId)
				// 从数据库拉取
				orders, err := persist.GetRebuildOrders(symbol, beginLoadOrderId, maxOrderDbId, 1000)
				if err != nil {
					log.Errorf("StartConsume GetRebuildOrders err: %v", err)
					time.Sleep(ERRSLEEP)
					continue
				}
				if len(orders) <= 0 {
					//数据库重建完成，更新状态机从mq消费
					log.Infof("StartConsume ready setFSMStatusMQ, symbol: %s,  market: %+v", symbol, market)
					if market.offset < 0 {
						log.Errorf("StartConsume ready setFSMStatusMQ before err, symbol:%s, market:%+v", symbol, market)
						time.Sleep(ERRSLEEP)
						continue
					}

					if err := p.setFSMStatusMQ(symbol, marketId, market.offset-1); err != nil {
						log.Errorf("StartConsume ready setFSMStatusMQ err, symbol: %s, err: %v", symbol, err)
						time.Sleep(ERRSLEEP)
						continue
					}
					market.isPullMQ = true
				}

				//BeginOffset,EndOffset表示从数据库加载的订单
				for _, order := range orders {
					offsetOrders := &OffsetOrders{
						BeginOffset: -2,
						EndOffset:   -2,
					}
					order.IsRebuild = true
					offsetOrders.Orders = append(offsetOrders.Orders, order)
					market.orderCh <- offsetOrders
					beginLoadOrderId = order.Id
				}
				log.Infof("StartConsume Leader fromDB, symbol: %s, orders: %v", symbol, len(orders))
			}
			log.Debugf("StartConsume Leader item, needUpdateOffset:%v, beginLoadOrderId:%v, market:%v", needUpdateOffset, beginLoadOrderId, market)
		} //select end
	}
	log.Warnf("StartConsume after, market: %v", market)
	return nil
}

func (p *rocketMQProvider) pullMQ(market *Market) error {
	symbol := market.symbol
	topic := TopicNameOrderProvider(symbol)
	mqs := p.consumer.FetchSubscriptionMessageQueues(topic)
	log.Debugf("StartConsume fetch subscription topic:%s, mqs:%v", topic, mqs)
	if len(mqs) != 1 {
		return errors.New(fmt.Sprintf("topic queue num error, topic:%s, num: %d", topic, len(mqs)))
	}

	mq := mqs[0]
	offset := market.offset
	pr := p.consumer.Pull(mq, "*", offset, 800)
	log.Debugf("Leader pull after, offset: %d, mq: %s, result: %+v", offset, mq.String(), pr)

	switch pr.Status {
	case rocketmq.PullNoNewMsg:
		log.Debugf("rocketmq pull nonewmasg, market:%+v", market)
		time.Sleep(time.Millisecond * time.Duration(p.noMsgSleep))
		return nil
	case rocketmq.PullFound:
		var offsetOrders *OffsetOrders
		isFirst := true
		for _, msg := range pr.Messages {
			order, err := PbToOrder(msg)
			if err != nil {
				log.Warnf("rocketmq formatOrder failed, offset:%d, err: %v", msg.QueueOffset, err)
				continue
			}
			if isFirst {
				offsetOrders = &OffsetOrders{}
				offsetOrders.BeginOffset = order.Offset
				isFirst = false
			}
			if len(offsetOrders.Orders) >= OffsetOrdersSize {
				market.orderCh <- offsetOrders
				//crete new group
				offsetOrders = &OffsetOrders{}
				offsetOrders.BeginOffset = order.Offset
			}
			offsetOrders.Orders = append(offsetOrders.Orders, order)
			offsetOrders.EndOffset = order.Offset
			log.Debugf("provider send orderCh item offsetOrders:%+v, order:%+v", *offsetOrders, *order)
		}

		if offsetOrders != nil && len(offsetOrders.Orders) > 0 {
			market.orderCh <- offsetOrders
		}
	case rocketmq.PullNoMatchedMsg:
		market.offset = pr.NextBeginOffset
		log.Errorf("broker PullNoMatchedMsg, offset:%d, pr:%+v", offset, pr)
		return errors.New("broker PullNoMatchedMsg")
	case rocketmq.PullOffsetIllegal:
		market.offset = pr.NextBeginOffset
		log.Errorf("broker PullOffsetIllegal, offset:%d, pr:%+v", offset, pr)
		return errors.New("broker PullOffsetIllegal")
	case rocketmq.PullBrokerTimeout:
		return errors.New("broker timeout occur")
	}
	market.offset = pr.NextBeginOffset
	maxOffset := pr.MaxOffset
	if (maxOffset - market.offset) > 1000 {
		log.Warnf("MatchMessageBlocked, symbol:%s, blockNum:%d, maxOffset:%d, offset:%d", market.symbol, maxOffset-offset, maxOffset, offset)
	}

	return nil
}

func (p *rocketMQProvider) maxOffset(symbol string) (int64, error) {
	topic := TopicNameOrderProvider(symbol)
	mqs := p.consumer.FetchSubscriptionMessageQueues(topic)
	log.Infof("maxOffset StartConsume fetch subscription topic:%s, mqs:%v", topic, mqs)
	if len(mqs) != 1 {
		return -1, errors.New(fmt.Sprintf("topic queue num error, topic:%s, num: %d", topic, len(mqs)))
	}

	mq := mqs[0]
	offset := int64(0)
	pr := p.consumer.Pull(mq, "*", offset, 1)
	log.Infof("maxOffset Leader pull after, offset: %d, mq: %s, result: %+v", offset, mq.String(), pr)

	return pr.MaxOffset, nil
}

// 从撮合状态机获取上次消费的offset
func (p *rocketMQProvider) getOffsetFSM(marketId uint64) (int64, int64, error) {
	req := &state.QueryRequest{
		Type: state.ApplyTypeQueryOffset,
	}
	data, err := p.service.SyncRead(marketId, req)
	if err != nil {
		return -1, -1, err
	}

	tmp := strings.Split(string(data), ",")
	offset, err := strconv.ParseInt(tmp[0], 10, 64)
	if err != nil {
		return -1, -1, err
	}
	mqConsumeStatus, err := strconv.ParseInt(tmp[1], 10, 64)
	if err != nil {
		return -1, -1, err
	}
	return offset, mqConsumeStatus, nil
}

// 重置状态机为从数据库恢复状态, 记下此时的maxoffset，从数据库重建前调用
func (p *rocketMQProvider) setFSMStatusRebuild(symbol string, marketId uint64, workId int64) error {
	//设置为一个不可用的offset
	err := p.service.ResetOffsetFSM(symbol, -2, models.FSM_STATUS_REBUILD, true, workId)
	if err != nil {
		log.Errorf("setFSMStatusRebuild ResetOffsetFSM err, symbol: %s, err: %v", symbol, err)
		return err
	}
	offsetFSM2, statusFSM2, err := p.getOffsetFSM(marketId)
	log.Infof("setFSMStatusRebuild ready rebuildDB getOffsetFSM, symbol: %s, offsetFSM2: %+v, statusFSM2: %v", symbol, offsetFSM2, statusFSM2)
	if err != nil || statusFSM2 != models.FSM_STATUS_REBUILD {
		log.Errorf("setFSMStatusRebuild ready getOffsetFSM err, offsetFSM2:%d, statusFSM2:%d, symbol: %s, err: %v", offsetFSM2, statusFSM2, symbol, err)
		return errors.New("setFSMStatusRebuild fail")
	}

	return nil
}

// 重置状态机为从mq消费状态，数据库重建完成调用，之后开始从mq消费
func (p *rocketMQProvider) setFSMStatusMQ(symbol string, marketId uint64, offset int64) error {
	err := p.service.ResetOffsetFSM(symbol, offset, models.FSM_STATUS_MQ, false, 0)
	if err != nil {
		log.Errorf("setFSMStatusMQ ready ResetOffsetFSM err, symbol: %s, err: %v", symbol, err)
		return err
	}
	offsetFSM2, statusFSM2, err := p.getOffsetFSM(marketId)
	log.Infof("setFSMStatusMQ ready setFSMStatusMQ getOffsetFSM, symbol: %s, offsetFSM2: %+v, statusFSM2: %v", symbol, offsetFSM2, statusFSM2)
	if err != nil || statusFSM2 != models.FSM_STATUS_MQ || offset < -1 {
		log.Errorf("setFSMStatusMQ ready getOffsetFSM err, offsetFSM2:%d, statusFSM2:%d, symbol: %s, err: %v", offsetFSM2, statusFSM2, symbol, err)
		return errors.New("setFSMStatusMQ fail")
	}
	return nil
}

func (p *rocketMQProvider) resetLiquidation(symbol string) error {
	cSymbol := models.CompactSymbol(symbol)

	persist := models.GetPersist()
	configSymbol, err := persist.GetConfigSymbolMatchingBySymbol(symbol)
	if err != nil {
		return err
	}
	ip := configSymbol.LiquidationServer
	url := fmt.Sprintf("http://%s:8080/match_hook", ip)
	data := fmt.Sprintf(`{"symbol":"%s"}`, cSymbol)
	request, _ := http.NewRequest("POST", url, strings.NewReader(data))

	resp, err := http.DefaultClient.Do(request)
	if err != nil {
		fmt.Printf("post data error:%v\n", err)
		return err
	}
	respBody, _ := ioutil.ReadAll(resp.Body)
	log.Infof("resetLiquidation respBody:%s", string(respBody))
	liqMap := make(map[string]interface{})
	json.Unmarshal(respBody, &liqMap)
	_, ok := liqMap["status"]
	if ok {
		return nil
	} else {
		return errors.New(fmt.Sprintf("Liquidation response error, %s", string(respBody)))
	}
}
