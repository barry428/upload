package engine

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/common/mock"
	"chainup.com/chainup/chmatch/models"
	"context"
	"time"
)

type mockProvider struct {
	service Service
}

func NewMockProvider(service Service) OrderProvider {
	return &mockProvider{service: service}
}

func (p *mockProvider) StartConsume(market *Market, ctx context.Context) error {
	log.Infof("StartConsume before %v \n", market)
	marketId := market.id
	symbol := market.symbol

LOOP:
	for {
		select {
		case <-ctx.Done():
			log.Warnf("StartConsume close, market:%+v", market)
			break LOOP
		default:
			if !market.isRunning {
				time.Sleep(ERRSLEEP)
				continue
			}
			if !p.service.IsLeader(marketId) {
				time.Sleep(ERRSLEEP)
				continue
			}
			//orders := MockSelfTradeOrder(symbol)
			//orders := MockOneOrder(symbol)
			var orders []*models.Order
			for i := 0; i < OffsetOrdersSize; i++ {
				order := mock.MockOneOrder(symbol)
				orders = append(orders, order...)
			}

			// orders := mock.MockSomeOrders(symbol)
			//for _, order := range orders {
			//	order.Offset = int64(order.Id)
			//}

			offsetOrders := &OffsetOrders{
				BeginOffset: orders[0].Offset,
				EndOffset:   orders[len(orders)-1].Offset,
			}
			offsetOrders.Orders = append(offsetOrders.Orders, orders...)
			market.orderCh <- offsetOrders

			time.Sleep(time.Millisecond * 100)
		}
	}

	return nil
}
