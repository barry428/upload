package engine

import (
	"bytes"
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/state"
	"encoding/gob"
	"encoding/json"
	"fmt"
	"time"

	"testing"
)

//gob vs json, 耗时一样，gob大小是json的1/3
func TestFormatApplyRequests(t *testing.T) {
	//fmt.Printf("orders %+v \n", orders)
	//for _, o := range orders {
	//	fmt.Printf("%+v \n", *o)
	//}

	var orders []*models.Order
	for i := 0; i <= 10000; i++ {
		o := MockSelfTradeOrder("ETH-USDT")
		orders = append(orders, o...)
	}

	offsetOrders := &OffsetOrders{
		BeginOffset: 1,
		EndOffset:   10,
		Orders:      orders,
	}
	applyRequests, err := FormatApplyRequests(offsetOrders)
	if err != nil {
		fmt.Println(err)
	}
	//fmt.Printf("applyRequests %+v \n", applyRequests)

	//for _, r := range applyRequests {
	//	fmt.Printf("r %+v \n", r.Order)
	//}

	if msg, err := json.Marshal(applyRequests); err == nil {
		fmt.Printf("Marshal msg %d \n", len(msg))

		var reqs []state.ApplyRequest
		if err := json.Unmarshal(msg, &reqs); err != nil {
			log.Errorf("from StateMachine.Update() error %v", err)
			panic(fmt.Sprintf("failed to unmarshal cluster command: %s", err.Error()))
		}
		//fmt.Printf("reqs %+v \n", reqs)
		//for _, r := range applyRequests {
		//	fmt.Printf("r %+v \n", r.Order)
		//}
	}

}

func TestFormatApplyRequests2(t *testing.T) {
	var orders []*models.Order
	for i := 0; i <= 1; i++ {
		o := MockSelfTradeOrder("ETH-USDT")
		orders = append(orders, o...)
	}

	offsetOrders := &OffsetOrders{
		BeginOffset: 1,
		EndOffset:   10,
		Orders:      orders,
	}
	applyRequests, err := FormatApplyRequests(offsetOrders)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Printf("applyRequests %+v \n", applyRequests)

	for _, r := range applyRequests {
		fmt.Printf("r %+v \n", r.Order)
	}

	buf := new(bytes.Buffer)
	enc := gob.NewEncoder(buf)
	if err := enc.Encode(applyRequests); err != nil {
		fmt.Println(err)
		return
	}
	fmt.Printf("Marshal msg %d \n", len(buf.Bytes()))
	//fmt.Printf("Marshal msg %+v \n", buf)

	var reqs []state.ApplyRequest
	dec := gob.NewDecoder(bytes.NewBuffer(buf.Bytes()))
	if err := dec.Decode(&reqs); err != nil {
		fmt.Println(err)
		return
	}
	fmt.Printf("reqs %+v \n", reqs)
	for _, r := range applyRequests {
		fmt.Printf("r %+v \n", r.Order)
	}
	//197311 1.38s
}

func TestRetry(t *testing.T) {
	market := NewMarket("ETH-USDT", 1)
	market.a = map[int]int{}

	go readMarket(market)
	go readMarket(market)
	go readMarket(market)
	for {
		fmt.Printf("isRunning: %v\n", market.isRunning)
		time.Sleep(time.Millisecond)
	}

}

func readMarket(market *Market) {
	for {
		if market.isRunning {
			fmt.Printf("readMarket: %v\n", market.isRunning)
		}
		time.Sleep(time.Millisecond)

	}
}

func TestQueryLiquidationConsumerOffset(t *testing.T) {
	symbol := "BCH-USDT"
	base := "http://39.106.93.235:8081"
	err := QueryLiquidationConsumerOffset(symbol, base)
	if err != nil {
		fmt.Println(err)
	}
}
