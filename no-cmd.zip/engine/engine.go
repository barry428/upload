package engine

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/common/metrics"
	"chainup.com/chainup/chmatch/conf"
	"chainup.com/chainup/chmatch/match"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/protocol"
	"chainup.com/chainup/chmatch/state"
	"context"
	"errors"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/lni/dragonboat/v3"
	"github.com/lni/dragonboat/v3/client"
	"github.com/lni/dragonboat/v3/config"
	"github.com/lni/dragonboat/v3/statemachine"
	"github.com/robfig/cron"
	"net/http"
	_ "net/http/pprof"
	"os"
	"runtime/debug"
	"sync"
	"time"
)

// 撮合服务的入口
type Engine struct {
	cfg *conf.Config

	nodeID         uint64
	initialMembers map[uint64]string
	nh             *dragonboat.NodeHost

	ApiServer ApiServer

	// 用于读取order
	orderProvider OrderProvider

	//consumer 撮合结果
	logSender LogSender

	markets sync.Map

	//新加币对的chan
	groupCh chan *models.ConfigSymbolMatching

	orderBookSync OrderBookSync  // 订单簿同步服务
	syncMetrics   *syncMetrics   // 同步指标
}

// syncMetrics 同步指标
type syncMetrics struct {
	syncLatency    int64  // 同步延迟（毫秒）
	syncCount      int64  // 同步次数
	errorCount     int64  // 错误次数
	lastSyncTime   int64  // 上次同步时间
	compressRatio  float64 // 压缩率
}

func NewEngine(cfg *conf.Config, datadir string, initialMembers map[uint64]string) *Engine {
	var err error
	var nh *dragonboat.NodeHost

	nodeAddr := initialMembers[cfg.NodeId]
	//加载配置，开启的币对
	nhc := config.NodeHostConfig{
		WALDir:         datadir,
		NodeHostDir:    datadir,
		RTTMillisecond: 200,
		RaftAddress:    nodeAddr,
		// 采用中等内存水平
		Expert:        config.ExpertConfig{LogDB: config.GetMediumMemLogDBConfig()},
		EnableMetrics: cfg.Raft.EnableMetrics,
		// RaftRPCFactory: rpc.NewRaftGRPC,
		//LogDBFactory: rocksdb.NewBatchedLogDB, //当前使用no batched
	}

	// create a NodeHost instance. it is a facade interface allowing access to
	// all functionalities provided by dragonboat.
	nh, err = dragonboat.NewNodeHost(nhc)
	if err != nil {
		log.Errorf("NewNodeHost err: %v", err)
		panic(err)
	}

	engine := &Engine{
		cfg:            cfg,
		nodeID:         cfg.NodeId,
		initialMembers: initialMembers,
		nh:             nh,
		//logSender:      NewMockLogSender(),
		logSender: NewRocketMQLogSender(cfg.RabbitMQ.Url, cfg.SendAttempts),
		groupCh:   make(chan *models.ConfigSymbolMatching),
		syncMetrics: &syncMetrics{},
	}
	//engine.orderProvider = NewMockProvider(engine)
	engine.orderProvider = NewRocketMQProvider(cfg.RabbitMQ.Url, cfg.RabbitMQ.ConsoleUrl, cfg.RabbitMQ.NoMsgSleep, engine)
	engine.ApiServer = newApiService(engine)

	// 初始化订单簿同步服务
	if cfg.OrderBookSync.Enabled {
		engine.orderBookSync = NewOrderBookSync(engine, cfg)
		if engine.orderBookSync != nil {
			log.Infof("订单簿同步服务初始化成功")
		} else {
			log.Errorf("订单簿同步服务初始化失败")
		}
	}

	return engine
}

func (e *Engine) Start() {
	log.Infof("正在启动引擎...")

	//启动api
	go e.runApi()

	//运行集群
	e.runCluster()

	//监听新开启的币对
	go e.monitor()

	//启动定时任务
	go e.runCron()

	//启动订单簿同步服务
	if e.orderBookSync != nil {
		log.Infof("正在启动订单簿同步服务...")
		ctx := context.Background()
		if err := e.orderBookSync.Start(ctx); err != nil {
			log.Errorf("启动订单簿同步服务失败: %v", err)
			return
		}
		log.Infof("订单簿同步服务已启动")
	} else {
		log.Warnf("订单簿同步服务未初始化")
	}
}

func (e *Engine) Close() error {
	log.Warnf("Engine close")
	
	// 停止订单簿同步服务
	if e.orderBookSync != nil {
		if err := e.orderBookSync.Stop(); err != nil {
			log.Errorf("停止订单簿同步服务失败: %v", err)
		}
		log.Infof("订单簿同步服务已停止")
	}
	
	e.nh.Stop()
	return nil
}

func (e *Engine) runCluster() {
	log.Infof("runCluster before")

	// mock测试
	//configSymbol := &models.ConfigSymbolMatching{Id: uint64(1), Base: "ETH", Quote: "USDT",}
	//if err := e.AddGroup(configSymbol); err != nil {
	//	log.Errorf("addGroup failed to add cluster, %+v %v", configSymbol, err)
	//}

	// 检查开启数据库中的币对
	p := models.GetPersist()
	clusterName := conf.GetConfig().ClusterName
	groupSymbols, err := p.GetConfigSymbolMatchings(clusterName, []int{1})

	if err == nil {
	for _, groupSymbol := range groupSymbols {
			log.Infof("runCluster addGroup groupSymbol: %v", *groupSymbol)
		go func(symbolArg *models.ConfigSymbolMatching) {
			if err := e.AddGroup(symbolArg); err != nil {
					log.Errorf("addGroup failed to add cluster, %+v %v", groupSymbol, err)
				return
			}
			log.Infof("[runCluster] 币对添加成功: %s-%s", symbolArg.Base, symbolArg.Quote)
		}(groupSymbol)
		time.Sleep(time.Millisecond * 100)
		}
	} else {
		log.Errorf("runCluster GetConfigSymbolMatchings err: %v", err)
	}

	// 监听新加入的raft group
	go func() {
		defer func() {
			if err := recover(); err != nil {
				debug.PrintStack()
				log.Errorf("runCluster addGroup listen goroutine crash err:%v", err)
			}
		}()
		for {
			select {
			case groupSymbol := <-e.groupCh:
				if err := e.AddGroup(groupSymbol); err != nil {
					log.Errorf("failed to add cluster from groupCh, %v %v\n", groupSymbol, err)
				}
			}
		}
	}()

	log.Infof("runCluster after")
}

func (e *Engine) runLogSender(ctx context.Context, market *Market) {
	log.Debugf("runLogSender before %s", market.symbol)
	symbol := market.symbol

	defer func() {
		log.Warnf("runLogSender finish, market: %+v", market)
		if err := recover(); err != nil {
			debug.PrintStack()
			log.Errorf("runLogSender goroutine crash, symbol:%s, err:%v", symbol, err)
		}
	}()

	//延迟退出
	delayedCnt := 0
Loop:
	for {
		select {
		case <-ctx.Done():
			if delayedCnt < 5 {
				log.Warnf("runLogSender closing, symbol:%s, delayedCnt:%d, market: %v", symbol, delayedCnt, market)
				delayedCnt++
				time.Sleep(time.Second)
				break
			}
			log.Warnf("runLogSender close, symbol:%s, market: %v", symbol, market)
			break Loop
		case matchLogs := <-market.logCh:
			log.Debugf("runLogSender from logCh matchLogs: %v", len(matchLogs))
			if err := e.logSender.Send(symbol, matchLogs); err != nil {
				log.Errorf("logSender err %v, market:%+v", err, market)
			}
		}
	}
}

// 执行订单到raft集群
func (e *Engine) runOrderApply(ctx context.Context, market *Market) {
	log.Debugf("runOrderApply before %s", market.symbol)
	symbol := market.symbol
	defer func() {
		log.Warnf("runOrderApply finish, market: %v", market)
		if err := recover(); err != nil {
			debug.PrintStack()
			log.Errorf("runOrderApply goroutine crash, symbol:%s, err:%v", symbol, err)
		}
	}()
	// 定时器每30s定时请求orderbook快照
	ticker := time.NewTicker(30 * time.Second)

	groupId := market.id
	cs := e.nh.GetNoOPSession(groupId)
Loop:
	for {
		select {
		case <-ctx.Done():
			log.Warnf("runOrderApply close, symbol:%s, market: %v", symbol, market)
			break Loop
		case offsetOrders := <-market.orderCh:
			metrics.AddReceivedOrder()
			log.Debugf("runOrderApply item before offsetOrders:%+v", *offsetOrders)
			applyRequests, err := FormatApplyRequests(offsetOrders)
			if err != nil {
				log.Errorf("syncPropose Marshal offsetOrders %+v err %v", offsetOrders, err)
			} else {
				// gob转成的二进制大小是json 1/3
				data, err := state.EncodeApplyRequests(applyRequests)
				if err == nil {
					//res, err := e.Propose(cs, msg)
					err := e.retrySyncPropose(cs, data, market)
					if err != nil {
						log.Errorf("retrySyncPropose error, symbol:%s, err:%v", symbol, err)
						if err := e.RemoveGroup(market); err != nil {
							log.Errorf("retrySyncPropose removeGroup fail, market: %+v, err: %v", market, err)
						}
						break Loop
					}
					log.Debugf("Propose, applyRequest:%v", applyRequests)
				} else {
					log.Errorf("syncPropose Marshal applyRequest %v err %v", applyRequests, err)
				}
			}
		// 定时向mq发送盘口深度数据
		case <-ticker.C:
			if e.IsLeader(groupId) {
				req := &state.QueryRequest{
					Type: state.ApplyTypePushDepth,
				}
				_, err := e.SyncRead(groupId, req)
				if err != nil {
					log.Errorf("syncPropose error, symbol:%s, err:%v", symbol, err)
				}
			}
		}
	}
}

// 订单提供者
func (e *Engine) runProvider(ctx context.Context, market *Market) {
	symbol := market.symbol
	defer func() {
		log.Warnf("runProvider finish, market: %v", market)
		if err := recover(); err != nil {
			debug.PrintStack()
			log.Errorf("runProvider goroutine crash, symbol:%s, err:%v", symbol, err)
			// todo 关闭这个币对
		}
	}()
	if err := e.orderProvider.StartConsume(market, ctx); err != nil {
		log.Errorf("StartConsume err %s", err)
	}
}

func (e *Engine) runApi() {
	defer func() {
		if err := recover(); err != nil {
			debug.PrintStack()
			log.Errorf("runApi goroutine crash err:%v", err)
		}
	}()

	httpAddr := e.cfg.HttpAddr
	http.HandleFunc("/", e.ApiServer.Handle)
	if err := http.ListenAndServe(httpAddr, nil); err != nil {
		log.Errorf("runApi service listening on %s err:%v", httpAddr, err)
		os.Exit(1)
	}
	log.Infof("runApi service listening on %s", httpAddr)
}

// 定时任务
func (e *Engine) runCron() {
	defer func() {
		if err := recover(); err != nil {
			log.Errorf("runCron error, err=%+v", err)
		}
	}()

	c := cron.New()

	// 定时清理内存
	clearMemoryFunc := func(engine *Engine) func() {
		return func() {
			// 清理orderBook 内存
			clearOrderBook(engine)
		}
	}
	// 默认执行周期为每周二03点24分00秒
	clearMemoryCron := e.cfg.ClearMemoryCron
	if len(clearMemoryCron) <= 0 {
		clearMemoryCron = "0 24 3 ? * 3"
	}

	if err := c.AddFunc(clearMemoryCron, clearMemoryFunc(e)); err != nil {
		log.Errorf("runCron failed, err=%+v", err)
	}

	c.Start()
	fmt.Printf("runCron success, [clearMemory: %+v] \n", clearMemoryCron)
}

// 清除orderBook缓存，只有leader可以发起提案
func clearOrderBook(engine *Engine) {
	defer func() {
		if err := recover(); err != nil {
			log.Errorf("clearOrderBook error, err=%+v", err)
		}
	}()

	var result []string
	engine.markets.Range(func(key, value interface{}) bool {
		result = append(result, key.(string))
		return true
	})
	if result == nil || len(result) <= 0 {
		return
	}

	// 构造提案
	data, err := state.EncodeApplyRequests([]*state.ApplyRequest{{Type: string(state.ApplyTypeClearOrderBook)}})
	if err != nil {
		log.Errorf("clearOrderBook EncodeApplyRequests err: %+v", err)
		return
	}

	var succ = 0
	for _, symbol := range result {
		// 只有leader可以发提案
		if m, err1 := engine.GetMarket(symbol); err1 != nil || !engine.IsLeader(m.id) {
			log.Warnf("clearOrderBook exec failed, not leader")
			continue
		}
		session, err2 := engine.GetSession(symbol)
		if err2 != nil {
			log.Errorf("clearOrderBook symbols: %+v, err: %+v", symbol, err2)
			continue
		}

		// 发起提案
		if _, err4 := engine.SyncPropose(session, data); err4 != nil {
			log.Errorf("retrySyncPropose error, symbol:%s, err:%v", symbol, err4)
		}
		succ++
	}
	log.Warnf("clearOrderBook symbols: size: %+v, succ: %+v", len(result), succ)
}

// AddGroup 启动新的raft group， 一个币对对应一个group
func (e *Engine) AddGroup(configSymbol *models.ConfigSymbolMatching) error {
	symbol := fmt.Sprintf("%s-%s", configSymbol.Base, configSymbol.Quote)
	log.Infof("addGroup before symbol:%s", symbol)

	if _, found := e.markets.Load(symbol); found {
		return errors.New(fmt.Sprintf("%s cluster already exist", symbol))
	}

	// 生成raft相关配置数据
	market := NewMarket(symbol, configSymbol.Id)
	e.markets.Store(symbol, market)
	rc := config.Config{
		NodeID:                 e.nodeID,
		ElectionRTT:            e.cfg.Raft.ElectionRTT,
		HeartbeatRTT:           e.cfg.Raft.HeartbeatRTT,
		CheckQuorum:            true,
		SnapshotEntries:        e.cfg.Raft.SnapshotEntries,    //1000条请求执行一次快照
		CompactionOverhead:     e.cfg.Raft.CompactionOverhead, //压缩快照之前保留50条记录
		DisableAutoCompactions: true,                          //禁用自动压缩
	}
	rc.ClusterID = uint64(configSymbol.Id)

	// 创建状态机的方法
	createStateMachine := func(clusterID uint64, nodeID uint64) statemachine.IStateMachine {
		return &state.StateMachine{
			ClusterID: clusterID,
			NodeID:    nodeID,
			OrderBook: match.NewOrderBook(symbol),
			ApplyAfterFunc: func(matchLogs []byte) error {
				// 执行撮合产生的log写入chan发送下游
				isLeader := e.IsLeader(clusterID)
				if isLeader && matchLogs != nil {
					log.Debugf("ApplyAfterFunc symbol: %s, isLeader: %v, len: %d", symbol, isLeader, len(matchLogs))
					metrics.AddSendLogs()
					market.logCh <- matchLogs
				}
				return nil
			},
		}
	}

	// 启动raft
	if err := e.nh.StartCluster(e.initialMembers, false, createStateMachine, rc); err != nil {
		log.Errorf("StartCluster fail, symbol:%s, err:%s", symbol, err.Error())
		e.markets.Delete(symbol)
		return err
	}

	//等待撮合启动之后执行后续逻辑
	time.Sleep(time.Second * 5)

	// 开始启动币对撮合消费逻辑
	ctx, cancel := context.WithCancel(context.Background())
	market.cancel = cancel
	//发送撮合结果到mq
	go e.runLogSender(ctx, market)
	//发送订单到撮合状态机
	go e.runOrderApply(ctx, market)
	//从mq获取订单
	go e.runProvider(ctx, market)
	log.Infof("addGroup after symbol:%s, market:%+v", symbol, market)

	return nil
}

func (e *Engine) RemoveGroup(market *Market) error {
	log.Infof("removeGroup before, market: %+v", market)
	market.cancel()
	time.Sleep(time.Second * 2)
	e.markets.Delete(market.symbol)
	if err := e.nh.StopCluster(market.id); err != nil {
		return err
	}
	log.Infof("removeGroup finish, market: %+v", market)
	return nil
}

func (e *Engine) GetSession(symbol string) (*client.Session, error) {
	v, ok := e.markets.Load(symbol)
	if !ok {
		return nil, errors.New("币对不存在")
	}
	market := v.(*Market)
	cs := e.nh.GetNoOPSession(market.id)
	return cs, nil
}

func (e *Engine) Propose(cs *client.Session, cmd []byte) (*dragonboat.RequestState, error) {
	result, err := e.nh.Propose(cs, cmd, 3*time.Second)
	if err != nil {
		//fmt.Fprintf(os.Stderr, "SyncPropose returned error %v\n", err)
	}

	return result, err
}

func (e *Engine) SyncPropose(cs *client.Session, cmd []byte) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	result, err := e.nh.SyncPropose(ctx, cs, cmd)
	cancel()
	if err != nil {
		//fmt.Fprintf(os.Stderr, "SyncPropose returned error %v\n", err)
	}

	return result.Data, err
}

// 同步的线性读取
func (e *Engine) SyncRead(groupId uint64, req *state.QueryRequest) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	result, err := e.nh.SyncRead(ctx, groupId, req)
	cancel()
	if err != nil {
		return nil, err
	}
	result2 := result.(statemachine.Result)
	return result2.Data, nil
}

// 非线性读
func (e *Engine) StaleRead(groupId uint64, req *state.QueryRequest) ([]byte, error) {
	result, err := e.nh.StaleRead(groupId, req)
	if err != nil {
		return nil, err
	}
	result2 := result.(statemachine.Result)
	return result2.Data, nil
}

func (e *Engine) GetMarket(symbol string) (*Market, error) {
	v, ok := e.markets.Load(symbol)
	if !ok {
		return nil, errors.New("币对不存在")
	}
	return v.(*Market), nil
}

func (e *Engine) IsLeader(groupId uint64) bool {
	leaderID, hasLeader, _ := e.nh.GetLeaderID(groupId)
	if hasLeader && e.nodeID == leaderID {
		return true
	}
	return false
}

func (e *Engine) Status() map[string]interface{} {
	res := make(map[string]interface{})
	nodeInfo := e.nh.GetNodeHostInfo(dragonboat.DefaultNodeHostInfoOption)
	markets := make(map[string]interface{})
	e.markets.Range(func(key, value interface{}) bool {
		symbol := key.(string)
		market := value.(*Market)
		marketInfo := make(map[string]interface{})
		marketInfo["id"] = market.id
		marketInfo["ready"] = market.IsReady()
		marketInfo["isPullMQ"] = market.isPullMQ
		marketInfo["offset"] = market.offset

		leaderInfo := make(map[string]interface{})
		leaderId, available, err := e.nh.GetLeaderID(market.id)
		if err != nil {
			leaderInfo["msg"] = err.Error()
		}
		leaderInfo["nodeid"] = leaderId
		leaderInfo["available"] = available
		marketInfo["leader"] = leaderInfo
		for _, clusterInfo := range nodeInfo.ClusterInfoList {
			if market.id == clusterInfo.ClusterID {
				marketInfo["clusterInfo"] = clusterInfo
			}
		}
		markets[symbol] = marketInfo
		return true
	})
	res["appName"] = conf.GetConfig().ClusterName
	res["raftAddress"] = nodeInfo.RaftAddress
	res["markets"] = markets
	res["logInfo"] = nodeInfo.LogInfo
	return res
}

func (e *Engine) AddSymbol(groupSymbol *models.ConfigSymbolMatching) error {
	log.Infof("AddSymbol groupSymbol:%v", groupSymbol)
	e.groupCh <- groupSymbol
	return nil
}

// 更新状态机offset
func (e *Engine) ResetOffsetFSM(symbol string, offset, MqConsumeStatus int64, isEmptyOrderBook bool, workId int64) error {
	// 封装数据结构
	reqs := []*state.ApplyRequest{{
		Type: string(state.ApplyTypeReset),
		ApplyRequestReset: &state.ApplyRequestReset{
			Symbol:          symbol,
			Offset:          offset,
			MqConsumeStatus: MqConsumeStatus,
			EmptyOrderBook:  isEmptyOrderBook,
			WorkId:          workId,
		},
	}}

	reqByte, err := state.EncodeApplyRequests(reqs)
	if err != nil {
		return err
	}

	cs, err := e.GetSession(symbol)
	if err != nil {
		return err
	}

	matchLogs, err := e.SyncPropose(cs, reqByte)
	if err != nil {
		return err
	}

	// todo not use
	logsPb := &protocol.MatchLogs{}
	if err := proto.Unmarshal(matchLogs, logsPb); err != nil {
		return err
	}

	log.Infof("ResetCmd reqs: %+v, result: %+v", reqs, logsPb)
	return nil
}

// 监控是否有新开启的币对
func (e *Engine) monitor() {
	// 60s后开始检测
	time.Sleep(time.Second * 60)
	for {
		e.startSymbols()
		time.Sleep(time.Second * 10)
	}
}

func (e *Engine) startSymbols() {
	var symbols []string
	p := models.GetPersist()
	clusterName := conf.GetConfig().ClusterName
	configSymbols, err := p.GetConfigSymbolMatchings(clusterName, []int{0, 1})
	dbConfigSymbolsMap := make(map[string]bool)
	if err == nil {
		for _, configSymbol := range configSymbols {
			symbol := fmt.Sprintf("%s-%s", configSymbol.Base, configSymbol.Quote)
			dbConfigSymbolsMap[symbol] = true

			if configSymbol.RunStatus == int64(0) {
				log.Warnf("monitor check LiquidationCloseSymbolFound, symbol: %v", symbol)
				continue
			}
			_, err := e.GetMarket(symbol)
			if err != nil {
				//币对不存在，启动
				if err := e.AddGroup(configSymbol); err != nil {
					log.Errorf("monitor addGroup failed to add cluster, %+v %v", configSymbol, err)
				} else {
					log.Infof("monitor addNew configSymbol ok, configSymbol: %+v", configSymbol)
				}
			}
		}

		if len(dbConfigSymbolsMap) > 0 {
			// 反向检查是否关闭
			e.markets.Range(func(key, value interface{}) bool {
				symbol := key.(string)
				market := value.(*Market)
				if _, found := dbConfigSymbolsMap[symbol]; !found {
					if err := e.RemoveGroup(market); err != nil {
						log.Errorf("removeGroup fail, market: %+v, err: %v", market, err)
					}
				}

				symbols = append(symbols, symbol)
				return true
			})
		}
	}
	log.Warnf("startSymbols, count:%d, symbols: %v", len(symbols), symbols)
}

func (e *Engine) retrySyncPropose(cs *client.Session, cmd []byte, market *Market) error {
	timeout := e.cfg.Raft.ProposeTimeout
	times := 1
	for {
		ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
		_, err := e.nh.SyncPropose(ctx, cs, cmd)
		cancel()
		if err != nil {
			if err == dragonboat.ErrTimeout {
				log.Warnf("retrySyncPropose ErrTimeout..., err:%+v, times:%d, market:%+v ", err, times, market)
				continue
			}
			log.Errorf("retrySyncPropose err:%s, symbol:%s, times:%d, market:%+v", err.Error(), market.symbol, times, market)
		}
		times++

		if times > 10 {
			return errors.New("retrySyncPropose failed")
		}
		return err
	}

}

// updateSyncMetrics 更新同步指标
func (e *Engine) updateSyncMetrics(latency int64, compressRatio float64, err error) {
	if e.syncMetrics == nil {
		return
	}

	e.syncMetrics.syncLatency = latency
	e.syncMetrics.syncCount++
	e.syncMetrics.lastSyncTime = time.Now().UnixMilli()
	e.syncMetrics.compressRatio = compressRatio

	if err != nil {
		e.syncMetrics.errorCount++
	}
}
