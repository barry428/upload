package engine

import (
	"chainup.com/chainup/chmatch/conf"
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/state"
	"chainup.com/chainup/chmatch/protocol"
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"github.com/golang/protobuf/proto"
)

// OrderBookSync 订单簿同步服务接口
type OrderBookSync interface {
	Start(ctx context.Context) error
	Stop() error
	Sync() error
}

// syncService 订单簿同步服务实现
type syncService struct {
	redisManager *RedisManager
	engine       *Engine
	config       *conf.OrderBookSyncConfig
	ctx          context.Context
	cancel       context.CancelFunc
	mu           sync.RWMutex
}

// NewOrderBookSync 创建订单簿同步服务
func NewOrderBookSync(engine *Engine, cfg *conf.Config) OrderBookSync {
	log.Infof("正在初始化订单簿同步服务，配置: enabled=%v, sync_interval=%v", 
		cfg.OrderBookSync.Enabled, cfg.OrderBookSync.SyncInterval)
	
	if !cfg.OrderBookSync.Enabled {
		log.Warnf("订单簿同步服务未启用")
		return nil
	}

	service := &syncService{
		engine: engine,
		config: &cfg.OrderBookSync,
	}
	service.ctx, service.cancel = context.WithCancel(context.Background())

	// 初始化 Redis 管理器
	service.redisManager = NewRedisManager(engine, cfg)
	if service.redisManager == nil {
		log.Errorf("初始化 Redis 管理器失败")
		return nil
	}

	log.Infof("订单簿同步服务初始化成功")
	return service
}

// Start 启动同步服务
func (s *syncService) Start(ctx context.Context) error {
	log.Infof("正在启动订单簿同步服务...")
	
	if s.redisManager == nil {
		log.Errorf("Redis 管理器未初始化，无法启动同步服务")
		return fmt.Errorf("Redis 管理器未初始化")
	}

	// 启动同步协程
	go s.syncLoop()
	log.Infof("订单簿同步服务已启动，同步间隔: %v", s.config.SyncInterval)
	return nil
}

// Stop 停止同步服务
func (s *syncService) Stop() error {
	if s.cancel != nil {
		s.cancel()
	}
	log.Infof("订单簿同步服务已停止")
	return nil
}

// Sync 执行一次同步
func (s *syncService) Sync() error {
	startTime := time.Now()
	orderBooks := make(map[string][]byte)
	totalSize := 0
	compressedSize := 0
	symbolCount := 0
	leaderCount := 0

	// 遍历所有交易对
	s.engine.markets.Range(func(key, value interface{}) bool {
		symbol, ok := key.(string)
		if !ok {
			log.Errorf("无效的 symbol 类型: %T", key)
			return true
		}

		market := value.(*Market)
		if market == nil {
			log.Errorf("无效的 market 对象 [symbol: %s]", symbol)
			return true
		}

		// 检查当前节点是否是 Leader
		if !s.engine.IsLeader(market.id) {
			return true
		}
		leaderCount++

		// 通过状态机获取实时深度数据
		req := &state.QueryRequest{
			Type: state.ApplyTypePushDepth,
		}
		results, err := s.engine.SyncRead(market.id, req)
		if err != nil {
			log.Errorf("获取实时深度数据失败 [symbol: %s]: %v", symbol, err)
			return true
		}

		matchLogs := &protocol.MatchLogs{}
		if err := proto.Unmarshal(results, matchLogs); err != nil {
			log.Errorf("解析实时深度数据失败 [symbol: %s]: %v", symbol, err)
			return true
		}

		// 移除对 matchLogs.Logs 长度的检查，确保空盘口也能写入 Redis
		var depth *protocol.Depth
		if len(matchLogs.Logs) > 0 {
			depth = matchLogs.Logs[0].Depth
			// log.Infof("[深度数据] symbol=%s, asks=%d, bids=%d, 第一档价格: ask=%s, bid=%s", 
			// 	symbol, len(depth.Asks), len(depth.Bids),
			// 	depth.Asks[0].Price, depth.Bids[0].Price)
		} else {
			// 当盘口为空时，创建一个空的深度数据
			depth = &protocol.Depth{
				Asks: []*protocol.Tick{{Price: "0", Volume: "0"}},
				Bids: []*protocol.Tick{{Price: "0", Volume: "0"}},
			}
			log.Infof("[空盘口] symbol=%s", symbol)
		}

		if depth == nil {
			log.Errorf("深度数据为空 [symbol: %s]", symbol)
			return true
		}

		// 限制深度
		if len(depth.Asks) > s.config.MaxDepth {
			depth.Asks = depth.Asks[:s.config.MaxDepth]
		}
		if len(depth.Bids) > s.config.MaxDepth {
			depth.Bids = depth.Bids[:s.config.MaxDepth]
		}

		// 序列化数据
		data, err := json.Marshal(depth)
		if err != nil {
			log.Errorf("序列化订单簿失败 [symbol: %s]: %v", symbol, err)
			return true
		}

		totalSize += len(data)
		orderBooks[symbol] = data
		symbolCount++
		return true
	})

	var syncErr error
	// 批量写入 Redis
	if len(orderBooks) > 0 {
		if err := s.redisManager.BatchSetOrderBook(orderBooks); err != nil {
			log.Errorf("批量同步订单簿失败: %v", err)
			syncErr = err
		} else {
			// 计算压缩后的总大小
			for _, data := range orderBooks {
				compressedSize += len(data)
			}
			//log.Infof("[同步统计] 总交易对=%d, Leader交易对=%d, 数据大小=%d字节, 压缩后=%d字节", 
			//	symbolCount, leaderCount, totalSize, compressedSize)
		}
	}

	// 计算压缩率
	compressRatio := 0.0
	if totalSize > 0 {
		compressRatio = float64(compressedSize) / float64(totalSize)
	}

	// 更新指标
	latency := time.Since(startTime).Milliseconds()
	s.engine.updateSyncMetrics(latency, compressRatio, syncErr)

	//log.Infof("[同步完成] 耗时=%dms, 压缩率=%.2f", latency, compressRatio)

	return syncErr
}

// syncLoop 同步循环
func (s *syncService) syncLoop() {
	ticker := time.NewTicker(s.config.SyncInterval)
	defer ticker.Stop()

	for {
		select {
		case <-s.ctx.Done():
			log.Infof("同步循环已停止")
			return
		case <-ticker.C:
			if err := s.Sync(); err != nil {
				log.Errorf("同步订单簿失败: %v", err)
			}
		}
	}
} 