package engine

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/protocol"
	"github.com/golang/protobuf/proto"
)

type MockLogSender struct {
}

func NewMockLogSender() *MockLogSender {
	return &MockLogSender{}
}

func (sender *MockLogSender) Send(symbol string, matchLogs []byte) error {
	logsPb := &protocol.MatchLogs{}
	proto.Unmarshal(matchLogs, logsPb)
	log.Debugf("NewMockLogSender symbol: %s, matchLogs: %v", symbol, logsPb)
	var seqs []uint64
	for _, log := range logsPb.Logs {
		seqs = append(seqs, log.Sequence)
	}
	log.Debugf("NewMockLogSender symbol: %s, matchLogs size: %v, seqs: %v", symbol, len(logsPb.Logs), seqs)

	return nil
}

func (sender *MockLogSender) Close() {
	log.Infof("MockLogSender Close")
}
