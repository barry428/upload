package engine

import (
	"chainup.com/chainup/chmatch/protocol"
	"fmt"
	"github.com/apache/rocketmq-client-go/core"
	"github.com/golang/protobuf/proto"
	"time"

	log "chainup.com/chainup/chmatch/common/logger"
	"os"
)

type RocketMQLogSender struct {
	producer rocketmq.Producer
	attempts int
}

func NewRocketMQLogSender(nameServerAddr string, attempts int) *RocketMQLogSender {
	pConfig := &rocketmq.ProducerConfig{
		ClientConfig: rocketmq.ClientConfig{
			GroupID:    "chmatch_logs",
			NameServer: nameServerAddr,
		},
		//Set to Common Producer as default.
		ProducerModel: rocketmq.OrderlyProducer,
	}
	producer, err := rocketmq.NewProducer(pConfig)

	if err != nil {
		fmt.Println("create common producer failed, error:", err)
		os.Exit(1)
	}

	err = producer.Start()
	if err != nil {
		fmt.Println("start common producer error", err)
		os.Exit(1)
	}

	return &RocketMQLogSender{
		producer: producer,
		attempts: attempts,
	}
}

func (sender *RocketMQLogSender) Send(symbol string, matchLogs []byte) error {
	if log.IsDebug() {
		logsPb := &protocol.MatchLogs{}
		proto.Unmarshal(matchLogs, logsPb)
		log.Debugf("RocketMQLogSender symbol: %s, matchLogs: %v", symbol, logsPb)
	}

	topic := TopicNameMatchResult(symbol)
	msg := &rocketmq.Message{Topic: topic, Body: string(matchLogs)}

	errFn := Retry(sender.attempts, time.Second, func() error {
		res, err := sender.producer.SendMessageSync(msg)
		if err != nil {
			log.Warnf("RocketMQLogSender message failed, symbol:%s, err:%v", symbol, err)
		} else {
			log.Debugf("RocketMQLogSender message success, symbol:%s, result=%s", symbol, res.String())
		}
		return err
	})
	if errFn != nil {
		logsPb := &protocol.MatchLogs{}
		proto.Unmarshal(matchLogs, logsPb)
		log.Errorf("RocketMQLogSender message failed finally, symbol:%s, err:%v, matchLogs: %v", symbol, errFn, logsPb)
	}

	return errFn
}

func (sender *RocketMQLogSender) Close() {
	err := sender.producer.Shutdown()
	if err != nil {
		log.Warnf("shutdown producer error: %s", err.Error())
	}
}
