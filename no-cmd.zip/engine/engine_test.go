package engine

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/common/mock"
	"chainup.com/chainup/chmatch/conf"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/state"
	"fmt"
	"path/filepath"
	"sync"
	"testing"
	"time"
)

var once sync.Once
var count = 0
var market *Market
var en *Engine
var symbol = "BTC-USDT"

func TestMain(m *testing.M) {
	fmt.Println("begin")

	//var configFile = "/Users/pingzhihao/workspace/chmatch/conf/cluster1-node1.yml"
	var configFile = "/data/chmatch/conf/cluster1-node1.yml"
	cfg := conf.InitConfig(configFile)
	log.Infof("config: %v", cfg)
	log.Init(log.Config{Level: cfg.LogLevel})
	nodeID := cfg.NodeId
	initialMembers := make(map[uint64]string)
	for _, v := range cfg.Members {
		initialMembers[uint64(v.NodeId)] = v.Url
	}
	datadir := filepath.Join(
		cfg.DataDir,
		"multigroup-data",
		fmt.Sprintf("node%d", nodeID))
	en = NewEngine(cfg, datadir, initialMembers)
	en.Start()

	var err error
	market, err = en.GetMarket(symbol)
	if err != nil {
		panic(err)
	}

	fmt.Println("---------")
	time.Sleep(time.Second * 5)

	m.Run()
	fmt.Println("end")
}

//成交基准测试 BenchmarkTrade(b *testing.B)
func BenchmarkTrade(b *testing.B) {
	//data := []*OffsetOrders{}
	//for z := 0; z < 1; z++ {
	//	var orders []*models.Order
	//	for j := 0; j < 10; j++ {
	//		_order := mock.MockOneOrder(symbol)
	//		orders = append(orders, _order...)
	//	}
	//	offsetOrders := &OffsetOrders{
	//		BeginOffset: orders[0].Offset,
	//		EndOffset:   orders[len(orders)-1].Offset,
	//	}
	//	offsetOrders.Orders = append(offsetOrders.Orders, orders...)
	//	data = append(data, offsetOrders)
	//}
	//fmt.Println(len(byts))
	cs := en.nh.GetNoOPSession(1)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		data := []*OffsetOrders{}
		for z := 0; z < 1; z++ {
			var orders []*models.Order
			for j := 0; j < 15; j++ {
				_order := mock.MockOneOrder(symbol)
				orders = append(orders, _order...)
			}
			offsetOrders := &OffsetOrders{
				BeginOffset: orders[0].Offset,
				EndOffset:   orders[len(orders)-1].Offset,
			}
			offsetOrders.Orders = append(offsetOrders.Orders, orders...)
			data = append(data, offsetOrders)
			count++
		}

		applyRequests, _ := FormatApplyRequests(data[0])
		byts, _ := state.EncodeApplyRequests(applyRequests)
		_, _ = en.SyncPropose(cs, byts)
	}
}
