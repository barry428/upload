package engine

import (
	"chainup.com/chainup/chmatch/conf"
	log "chainup.com/chainup/chmatch/common/logger"
	"context"
	"fmt"
	"github.com/redis/go-redis/v9"
	"time"
	"bytes"
	"io/ioutil"
	"github.com/klauspost/compress/gzip"
	"encoding/json"
)

// RedisManager Redis 管理器
type RedisManager struct {
	client        *redis.ClusterClient
	syncEnabled   bool
	syncInterval  time.Duration
	compressLevel int
	ctx           context.Context
	cancel        context.CancelFunc
	engine        *Engine
}

// NewRedisManager 创建 Redis 管理器
func NewRedisManager(engine *Engine, cfg *conf.Config) *RedisManager {
	if !cfg.OrderBookSync.Enabled {
		return nil
	}

	manager := &RedisManager{
		engine: engine,
	}
	manager.ctx, manager.cancel = context.WithCancel(context.Background())
	
	// 启动连接
	go manager.initRedisClient()
	
	return manager
}

// initRedisClient 初始化 Redis 客户端，包含重连机制
func (m *RedisManager) initRedisClient() {
	for {
		select {
		case <-m.ctx.Done():
			return
		default:
			if err := m.connectRedis(); err != nil {
				log.Errorf("Redis 连接失败，将在 5 秒后重试: %v", err)
				time.Sleep(5 * time.Second)
				continue
			}
			
			// 启动健康检查
			go m.checkRedisHealth()
			return
		}
	}
}

// connectRedis 连接 Redis Cluster
func (m *RedisManager) connectRedis() error {
	cfg := m.engine.cfg.Redis
	readTimeout, _ := time.ParseDuration(cfg.ReadTimeout)
	writeTimeout, _ := time.ParseDuration(cfg.WriteTimeout)
	dialTimeout, _ := time.ParseDuration(cfg.DialTimeout)
	
	// 如果已有客户端，先关闭
	if m.client != nil {
		m.client.Close()
	}
	
	m.client = redis.NewClusterClient(&redis.ClusterOptions{
		Addrs:          cfg.Nodes,
		Password:       cfg.Password,
		PoolSize:       cfg.PoolSize,
		MinIdleConns:   cfg.MinIdleConns,
		ReadTimeout:    readTimeout,
		WriteTimeout:   writeTimeout,
		DialTimeout:    dialTimeout,
		RouteRandomly:  true,
		RouteByLatency: true,
	})
	
	// 测试连接
	ctx, cancel := context.WithTimeout(context.Background(), dialTimeout)
	defer cancel()
	
	if err := m.client.Ping(ctx).Err(); err != nil {
		return fmt.Errorf("Redis Cluster 连接测试失败: %v", err)
	}
	
	m.syncEnabled = true
	// 从 OrderBookSync 配置中读取同步参数
	syncCfg := m.engine.cfg.OrderBookSync
	m.syncInterval = syncCfg.SyncInterval
	m.compressLevel = syncCfg.CompressLevel
	
	log.Infof("Redis Cluster 连接成功，节点: %v", cfg.Nodes)
	return nil
}

// checkRedisHealth 定期检查 Redis 连接健康状态
func (m *RedisManager) checkRedisHealth() {
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-m.ctx.Done():
			return
		case <-ticker.C:
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			err := m.client.Ping(ctx).Err()
			cancel()
			
			if err != nil {
				log.Errorf("Redis 健康检查失败: %v，尝试重新连接", err)
				m.syncEnabled = false
				go m.initRedisClient()
				return
			}
		}
	}
}

// Close 关闭 Redis 管理器
func (m *RedisManager) Close() error {
	if m.cancel != nil {
		m.cancel()
	}
	
	if m.client != nil {
		if err := m.client.Close(); err != nil {
			log.Errorf("关闭 Redis 客户端失败: %v", err)
			return err
		}
	}
	return nil
}

// OrderBookData 订单簿数据结构
type OrderBookData struct {
	Symbol    string    `json:"symbol"`
	Timestamp int64     `json:"timestamp"`
	Asks      []PriceLevel `json:"asks"`
	Bids      []PriceLevel `json:"bids"`
}

type PriceLevel struct {
	Price  string `json:"price"`
	Volume string `json:"volume"`
}

// BatchSetOrderBook 批量设置订单簿数据
func (r *RedisManager) BatchSetOrderBook(orderBooks map[string][]byte) error {
	if r.client == nil {
		return fmt.Errorf("Redis 客户端未初始化")
	}

	ctx := context.Background()
	pipe := r.client.Pipeline()
	cmds := make([]*redis.StatusCmd, 0, len(orderBooks))

	for symbol, data := range orderBooks {
		// 解析原始数据
		var obData OrderBookData
		if err := json.Unmarshal(data, &obData); err != nil {
			log.Errorf("解析订单簿数据失败 [symbol: %s]: %v", symbol, err)
			continue
		}

		// 确保数据包含完整信息
		obData.Symbol = symbol
		obData.Timestamp = time.Now().UnixMilli()

		// 重新序列化数据
		newData, err := json.Marshal(obData)
		if err != nil {
			log.Errorf("序列化订单簿数据失败 [symbol: %s]: %v", symbol, err)
			continue
		}

		// 生成 Redis key
		key := fmt.Sprintf("orderbook:spot:%s", symbol)

		// 压缩数据
		if r.compressLevel > 0 {
			compressed, err := compress(newData, r.compressLevel)
			if err != nil {
				log.Errorf("压缩订单簿数据失败 [symbol: %s]: %v", symbol, err)
				continue
			}
			newData = compressed
		}

		// 设置数据，使用 Pipeline
		cmd := pipe.Set(ctx, key, newData, time.Hour*24)
		cmds = append(cmds, cmd)
	}

	// 执行 Pipeline
	if _, err := pipe.Exec(ctx); err != nil {
		return fmt.Errorf("执行 Pipeline 失败: %v", err)
	}

	// 检查每个命令的执行结果
	for _, cmd := range cmds {
		if err := cmd.Err(); err != nil {
			symbol := ""
			for s := range orderBooks {
				symbol = s
				break
			}
			return fmt.Errorf("设置订单簿数据失败 [symbol: %s]: %v", symbol, err)
		}
	}

	return nil
}

// GetOrderBook 获取订单簿数据
func (r *RedisManager) GetOrderBook(symbol string) (*OrderBookData, error) {
	if r.client == nil {
		return nil, fmt.Errorf("Redis 客户端未初始化")
	}

	key := fmt.Sprintf("orderbook:spot:%s", symbol)
	data, err := r.client.Get(context.Background(), key).Bytes()
	if err != nil {
		return nil, fmt.Errorf("获取订单簿数据失败 [symbol: %s]: %v", symbol, err)
	}

	// 解压数据
	if r.compressLevel > 0 {
		decompressed, err := decompress(data)
		if err != nil {
			return nil, fmt.Errorf("解压订单簿数据失败 [symbol: %s]: %v", symbol, err)
		}
		data = decompressed
	}

	// 解析数据
	var obData OrderBookData
	if err := json.Unmarshal(data, &obData); err != nil {
		return nil, fmt.Errorf("解析订单簿数据失败 [symbol: %s]: %v", symbol, err)
	}

	return &obData, nil
}

// compress 压缩数据
func compress(data []byte, level int) ([]byte, error) {
	var buf bytes.Buffer
	writer, err := gzip.NewWriterLevel(&buf, level)
	if err != nil {
		return nil, err
	}

	if _, err := writer.Write(data); err != nil {
		return nil, err
	}

	if err := writer.Close(); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

// decompress 解压数据
func decompress(data []byte) ([]byte, error) {
	reader, err := gzip.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer reader.Close()

	return ioutil.ReadAll(reader)
} 