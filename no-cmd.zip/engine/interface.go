package engine

import (
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/state"
	"context"
	"github.com/lni/dragonboat/v3/client"
	"net/http"
)

const (
	ORDER_CHAN_SIZE = 100

	ENABLE_WRITE_TRUE  = int32(1)
	ENABLE_WRITE_FALSE = int32(0)
)

type Service interface {
	// 新增币对
	AddSymbol(groupSymbol *models.ConfigSymbolMatching) error
	//重置状态机offset, 清空orderbook
	ResetOffsetFSM(symbol string, offset, MqConsumeStatus int64, isEmptyOrderBook bool, workId int64) error
	//向集群发送同步消息
	SyncPropose(cs *client.Session, msg []byte) (matchLogs []byte, err error)
	//同步线性读取
	SyncRead(groupId uint64, req *state.QueryRequest) (matchLogs []byte, err error)
	//非线性读取
	StaleRead(groupId uint64, req *state.QueryRequest) (matchLogs []byte, err error)
	GetSession(symbol string) (*client.Session, error)
	GetMarket(symbol string) (*Market, error)
	AddGroup(configSymbol *models.ConfigSymbolMatching) error
	RemoveGroup(market *Market) error
	IsLeader(groupId uint64) bool
	Status() map[string]interface{}
}

//订单提供者： 用于撮合引擎读取order，需要支持设置offset，从指定的offset开始读取
type OrderProvider interface {
	// 启动消费
	StartConsume(market *Market, ctx context.Context) error
}

type ApiServer interface {
	Handle(w http.ResponseWriter, r *http.Request)
}

//发送撮合结果
type LogSender interface {
	Send(symbol string, matchLogs []byte) error
}
