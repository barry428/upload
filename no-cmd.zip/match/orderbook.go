package match

import (
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/common/utils"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/protocol"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/emirpasic/gods/maps/treemap"
	"github.com/emirpasic/gods/sets/hashset"
	"github.com/emirpasic/gods/sets/treeset"
	"github.com/shopspring/decimal"
	"runtime/debug"
	"sync"
)

const (
	orderIdWindowCap  = 100000
	DEFAULT_PRECISION = 16
)

type OrderBook struct {
	// 唯一币对, 统一格式：BTC-USDT
	symbol string

	asks *depth
	bids *depth

	//连续自增的序号，用于写入撮合日志
	logSeq uint64

	//offset和mqConsumeStatus用来帮助order_provider判断当前从哪里（db or mq）消费
	//最后一个订单offset位置：-2 初始化, >=-1 下次从offset+1位置开始消费
	offset int64
	//是否开始从mq消费：0 数据库重建阶段 1 正常从mq消费订单
	mqConsumeStatus int64
	//实现订单判重
	orderIdBitmap utils.BitmapCircularBuffer

	//清空orderbook后设置一个workId
	workId int64
	sync.RWMutex
}

func NewOrderBook(symbol string) *OrderBook {
	orderBook := &OrderBook{
		symbol: symbol,
		bids: &depth{
			orders:  map[uint64]*models.Order{},
			queue:   treemap.NewWith(priceOffsetDescComparator),
			uorders: map[uint64]*hashset.Set{},
		},
		asks: &depth{
			orders:  map[uint64]*models.Order{},
			queue:   treemap.NewWith(priceOffsetAscComparator),
			uorders: map[uint64]*hashset.Set{},
		},
		orderIdBitmap:   utils.NewBitmapCircularBuffer(symbol),
		logSeq:          uint64(0),
		offset:          int64(-2), //新建为一个不可用的offset，需要调用reset接口后才正常从mq开始消费
		mqConsumeStatus: 0,         //默认为从数据库重建阶段
		workId:          0,
	}
	return orderBook
}

// 重置orderbook
// emptyOrderBook=true 清空orderbook
// offset>0 更新offset
// mqConsumeStatus 0 从数据库重建， 1 从mq消费
func (ob *OrderBook) ResetOrderBook(symbol string, emptyOrderBook bool, offset int64, mqConsumeStatus int64, workId int64) (*protocol.Log, error) {
	log.Infof("ResetOrderBook symbol:%v, emptyOrderBook:%v, offset:%v, mqConsumeStatus:%v", symbol, emptyOrderBook, offset, mqConsumeStatus)
	ob.Lock()
	defer func() {
		ob.Unlock()
	}()

	if ob.symbol != symbol {
		return nil, errors.New("symbol error")
	}
	if mqConsumeStatus != models.FSM_STATUS_REBUILD && mqConsumeStatus != models.FSM_STATUS_MQ {
		return nil, errors.New("mqConsumeStatus error")
	}
	if emptyOrderBook {
		ob.bids = &depth{
			orders:  map[uint64]*models.Order{},
			queue:   treemap.NewWith(priceOffsetDescComparator),
			uorders: map[uint64]*hashset.Set{},
		}
		ob.asks = &depth{
			orders:  map[uint64]*models.Order{},
			queue:   treemap.NewWith(priceOffsetAscComparator),
			uorders: map[uint64]*hashset.Set{},
		}
		ob.orderIdBitmap = utils.NewBitmapCircularBuffer(symbol)
	}
	if offset >= -1 {
		ob.updateOffset(offset)
	}
	if workId > 0 {
		ob.workId = workId
	}
	ob.mqConsumeStatus = mqConsumeStatus

	resetLog := newResetLogPb(ob.nextLogSeq(), ob.symbol)
	snap := make(map[string]interface{})
	snap["symbol"] = ob.symbol
	snap["logSeq"] = ob.logSeq
	snap["offset"] = ob.offset
	snap["workId"] = ob.workId
	snap["mqConsumeStatus"] = ob.mqConsumeStatus
	snap["asks"] = ob.asks.simpleDepth(10)
	snap["bids"] = ob.bids.simpleDepth(10)
	log.Infof("ResetOrderBook end resetLog:%+v, snap:%+v", resetLog, snap)
	return resetLog, nil
}

func (ob *OrderBook) ExecuteOrder(order *models.Order) (logs []*protocol.Log) {
	log.Infof("ExecuteOrder order:%+v", order)
	ob.Lock()
	defer func() {
		ob.Unlock()
	}()

	// 不是从数据库加载的订单需要判断offset大于当前
	if !order.IsRebuild && order.Offset < ob.offset {
		log.Warnf("order Offset < orderbook offset ob.offset: %d order: %+v", ob.offset, order)
		return logs
	}

	if isFirst := ob.orderIdBitmap.CheckedAdd(order.Id); !isFirst {
		log.Errorf("order repeat symbol:%s, orderId: %v", ob.symbol, order.Id)
		return logs
	}

	takerOrder := order
	makerOrderCnt := 0
	// 被动单深度
	var makerDepth = ob.getCounterDepth(order.Side)

	// post only 订单判断是否能成为maker
	isMaker := false
	if takerOrder.Type == models.ORDER_POST_ONLY {
		isMaker = ob.checkIsMaker(takerOrder)
	}

	// FOK 订单判断一下是否能全部成交
	var isAllFilled = false
	if takerOrder.Type == models.ORDER_FOK {
		isAllFilled = ob.checkIsAllFilled(takerOrder)
	}

	for itr := makerDepth.queue.Iterator(); itr.Next(); {
		if takerOrder.IsFilled() {
			break
		}

		if takerOrder.Type == models.ORDER_POST_ONLY && !isMaker {
			break
		}

		if takerOrder.Type == models.ORDER_FOK && !isAllFilled {
			break
		}

		makerOrder := makerDepth.orders[itr.Value().(uint64)]
		// 检查taker和maker是否价格交叉
		if takerOrder.Type != models.ORDER_MARKET {
			if (takerOrder.Side == models.BUY && takerOrder.Price.LessThan(makerOrder.Price)) ||
				(takerOrder.Side == models.SELL && takerOrder.Price.GreaterThan(makerOrder.Price)) {
				break
			}
		}

		// 本次成交价格，成交数量
		var price = makerOrder.Price
		var tradeVol decimal.Decimal
		var tradeMoney decimal.Decimal
		makerVolume := makerOrder.RemainVol()

		// 如果taker为限价单且taker和marker都是机器人（ order.source = 5）, 自动取消maker
		if takerOrder.Type == models.ORDER_LIMIT && takerOrder.Source == 5 && makerOrder.Source == 5 {
			// 执行取消maker的逻辑
			err := makerDepth.remove(makerOrder.Id)
			if err != nil {
				log.Errorf("makerDepth remove fail, err: %v", err)
				debug.PrintStack()
				panic(err)
			}
			// 发送取消的消息
			doneLog := newDoneLogPb(ob.nextLogSeq(), ob.symbol, makerOrder, makerOrder.RemainVol(), DoneReasonCancelled)
			logs = append(logs, doneLog)

			continue
		}

		if takerOrder.Type == models.ORDER_LIMIT || takerOrder.Type == models.ORDER_STOPLIMIT ||
			(takerOrder.Type == models.ORDER_MARKET && takerOrder.Side == models.SELL) ||
			takerOrder.Type == models.ORDER_IOC || takerOrder.Type == models.ORDER_FOK || takerOrder.Type == models.ORDER_POST_ONLY {

			takerVol := takerOrder.Volume.Sub(takerOrder.DealVolume)

			// 实际成交量等于taker和maker最小值，更新taker
			tradeVol = decimal.Min(takerVol, makerVolume)
			tradeMoney = tradeVol.Mul(price)
			takerOrder.DealVolume = takerOrder.DealVolume.Add(tradeVol)
			takerOrder.DealMoney = takerOrder.DealMoney.Add(tradeMoney)
		} else if takerOrder.Type == models.ORDER_MARKET && takerOrder.Side == models.BUY {

			// 计算可购买的数量
			remainMoney := takerOrder.Volume.Sub(takerOrder.DealMoney)
			takerVolume := remainMoney.Div(price).Truncate(models.MIN_TRADE_VOL_PRECISION)
			if takerVolume.IsZero() {
				break
			}
			// 实际成交量等于taker和maker最小值，更新taker
			tradeVol = decimal.Min(takerVolume, makerVolume)
			tradeMoney = tradeVol.Mul(price)
			takerOrder.DealVolume = takerOrder.DealVolume.Add(tradeVol)
			takerOrder.DealMoney = takerOrder.DealMoney.Add(tradeMoney)
		} else {
			log.Errorf("unknown orderType and side combination， takerOrder: %+v", takerOrder)
		}

		// 更新被动单成交数量
		err := makerDepth.update(makerOrder.Id, tradeVol, tradeMoney)
		if err != nil {
			log.Errorf("makerDepth update fail, err: %v", err)
			debug.PrintStack()
			panic(err)
		}

		// matched,write a log
		matchLog := newTradeLogPb(ob.nextLogSeq(), ob.symbol, takerOrder, makerOrder, price, tradeVol)
		logs = append(logs, matchLog)

		// 被动单完全成交
		if makerOrder.IsFilled() {
			err := makerDepth.remove(makerOrder.Id)
			if err != nil {
				log.Errorf("makerDepth remove fail, err: %v", err)
				debug.PrintStack()
				panic(err)
			}
			doneLog := newDoneLogPb(ob.nextLogSeq(), ob.symbol, makerOrder, makerOrder.RemainVol(), DoneReasonFilled)
			logs = append(logs, doneLog)
		}
		makerOrderCnt++

		// 记录吃单的个数，市价单吃单不能超过50单
		if takerOrder.Type == models.ORDER_MARKET && makerOrderCnt >= 50 {
			break
		}
	}

	//开始处理taker
	isFilled := takerOrder.IsFilled()
	if (takerOrder.Type == models.ORDER_LIMIT && !isFilled) ||
		(takerOrder.Type == models.ORDER_STOPLIMIT && !isFilled) ||
		(takerOrder.Type == models.ORDER_POST_ONLY && isMaker) {
		//如果taker未完全成交，放到orderbook中
		ob.getDepth(takerOrder.Side).add(*takerOrder)
		openLog := newOpenLogPb(ob.nextLogSeq(), ob.symbol, takerOrder)
		logs = append(logs, openLog)
	} else {
		var remainingSize = takerOrder.RemainVol()
		var reason = DoneReasonFilled
		if takerOrder.Type == models.ORDER_MARKET {
			takerOrder.Price = decimal.Zero
			remainingSize = decimal.Zero
			if (takerOrder.Side == models.SELL && takerOrder.RemainVol().GreaterThan(decimal.Zero)) ||
				(takerOrder.Side == models.BUY && takerOrder.RemainMoney().GreaterThan(decimal.Zero)) {
				reason = DoneReasonCancelled
			}
		} else if takerOrder.Type == models.ORDER_IOC ||
			(takerOrder.Type == models.ORDER_POST_ONLY && !isMaker) ||
			(takerOrder.Type == models.ORDER_FOK && !isAllFilled) {
			// 没成交的立即取消
			if (takerOrder.Side == models.SELL && takerOrder.RemainVol().GreaterThan(decimal.Zero)) ||
				(takerOrder.Side == models.BUY && takerOrder.RemainVol().GreaterThan(decimal.Zero)) {
				reason = DoneReasonCancelled
			}
		}

		doneLog := newDoneLogPb(ob.nextLogSeq(), ob.symbol, takerOrder, remainingSize, reason)
		logs = append(logs, doneLog)

	}

	if !order.IsRebuild {
		ob.updateOffset(order.Offset)
	}
	return logs
}

func (ob *OrderBook) CancelOrder(order *models.Order) (logs []*protocol.Log) {
	ob.Lock()
	defer func() {
		if !order.IsRebuild {
			ob.updateOffset(order.Offset)
		}
		ob.Unlock()
	}()

	//_ = ob.orderIdWindow.put(order.Id)

	bookOrder, sameDepth, found := ob.findCancelOrder(order)
	if !found {
		// 重建订单orderbook中不存在也发消息：DoneReasonRebuildCancelled结算处理，行情不处理
		if order.IsRebuild {
			remainingSize := order.RemainVol()
			doneLog := newDoneLogPb(ob.nextLogSeq(), ob.symbol, order, remainingSize, DoneReasonCancelled)
			logs = append(logs, doneLog)
		} else {
			log.Warnf("CancelOrder not found, symbol: %s, order: %+v", ob.symbol, order)
		}
		return logs
	}
	// 将order的size全部decr，等于remove操作
	remainingSize := bookOrder.RemainVol()
	err := sameDepth.remove(order.Id)
	if err != nil {
		panic(err)
	}
	doneLog := newDoneLogPb(ob.nextLogSeq(), ob.symbol, bookOrder, remainingSize, DoneReasonCancelled)
	log.Infof("CancelOrder success order:%+v", order)
	return append(logs, doneLog)
}

func (ob *OrderBook) CancelUserOrders(userId uint64) (logs []*protocol.Log) {
	log.Infof("CancelUserOrders userId:%+v", userId)
	ob.Lock()
	defer func() {
		ob.Unlock()
	}()

	orderIds := treeset.NewWith(func(a, b interface{}) int {
		// 从小到大
		aAsserted := a.(uint64)
		bAsserted := b.(uint64)
		if aAsserted > bAsserted {
			return 1
		} else if aAsserted < bAsserted {
			return -1
		} else {
			return 0
		}
	})
	if _, found := ob.asks.uorders[userId]; found {
		for _, orderId := range ob.asks.uorders[userId].Values() {
			orderIds.Add(orderId.(uint64))
		}
	}
	if _, found := ob.bids.uorders[userId]; found {
		for _, orderId := range ob.bids.uorders[userId].Values() {
			orderIds.Add(orderId.(uint64))
		}
	}

	for index, v := range orderIds.Values() {
		orderId := v.(uint64)
		if index > 100 {
			break
		}
		log.Infof("CancelUserOrders userId: %d, orderId: %d", userId, orderId)
		bookOrder, sameDepth, found := ob.findCancelOrderById(orderId)
		if found {
			// 将order的size全部decr，等于remove操作
			remainingSize := bookOrder.RemainVol()
			err := sameDepth.remove(orderId)
			if err != nil {
				log.Errorf("CancelUserOrders depth remove fail, orderId:%v, err:%v", orderId, err)
				panic(err)
			}
			doneLog := newDoneLogPb(ob.nextLogSeq(), ob.symbol, bookOrder, remainingSize, DoneReasonCancelled)
			logs = append(logs, doneLog)
		}
	}

	return logs
}

func (ob *OrderBook) findCancelOrder(order *models.Order) (bookOrder *models.Order, sameDepth *depth, found bool) {
	found = false
	if order.Side == models.BUY || order.Side == models.SELL {
		sameDepth = ob.getDepth(order.Side)
		bookOrder, found = sameDepth.orders[order.Id]
	} else {
		sameDepth = ob.getDepth(models.BUY)
		bookOrder, found = sameDepth.orders[order.Id]
		if found {
			return
		}
		sameDepth = ob.getDepth(models.SELL)
		bookOrder, found = sameDepth.orders[order.Id]
		if found {
			return
		}
	}
	return
}

func (ob *OrderBook) findCancelOrderById(orderId uint64) (bookOrder *models.Order, sameDepth *depth, found bool) {
	found = false
	sameDepth = ob.getDepth(models.BUY)
	bookOrder, found = sameDepth.orders[orderId]
	if found {
		return
	}
	sameDepth = ob.getDepth(models.SELL)
	bookOrder, found = sameDepth.orders[orderId]
	if found {
		return
	}
	return
}

// 获取orderbook快照，给行情使用
func (ob *OrderBook) OrderBookSnapshot() (logs []*protocol.Log) {
	ob.RLock()
	defer ob.RUnlock()
	asks := ob.asks.mergePriceDepth(priceAscComparator, 300)
	bids := ob.bids.mergePriceDepth(priceDescComparator, 300)
	depthLog := newDepthLogPb(ob.logSeq, ob.symbol, asks, bids)
	return append(logs, depthLog)
}

// 查询指定用户的当前委托
func (ob *OrderBook) UserOrders(userId uint64) (pbOrders []*protocol.Order) {
	ob.RLock()
	defer ob.RUnlock()

	askOrders := ob.asks.getUserOrderLogs(userId, 500)
	bidOrders := ob.bids.getUserOrderLogs(userId, 500)
	if len(askOrders) > 0 {
		pbOrders = append(pbOrders, askOrders...)
	}
	if len(bidOrders) > 0 {
		pbOrders = append(pbOrders, bidOrders...)
	}
	return pbOrders
}

// 查询指定用户的当前委托ID
func (ob *OrderBook) UserOrderIds(userId uint64) *protocol.UserOrderIds {
	ob.RLock()
	defer ob.RUnlock()

	return &protocol.UserOrderIds{
		Ask: ob.asks.getUserOrderIds(userId, 1500),
		Bid: ob.bids.getUserOrderIds(userId, 1500),
	}
}

// 查询指定用户的当前委托
func (ob *OrderBook) OrderDetail(orderId uint64) (pbOrders []*protocol.Order) {
	ob.RLock()
	defer ob.RUnlock()

	askOrder := ob.asks.getOrderDetail(orderId)
	bidOrder := ob.bids.getOrderDetail(orderId)
	if askOrder != nil {
		pbOrder := newOrderPb(askOrder)
		pbOrders = append(pbOrders, pbOrder)
	}
	if bidOrder != nil {
		pbOrder := newOrderPb(bidOrder)
		pbOrders = append(pbOrders, pbOrder)
	}

	return pbOrders
}

// 获取orderbook快照状态，给监控程序使用
func (ob *OrderBook) OrderBookStatus() (logs []*protocol.Log) {
	ob.RLock()
	defer ob.RUnlock()
	asks := ob.asks.simpleDepth(100)
	bids := ob.bids.simpleDepth(100)
	//depthLog := newDepthLogPbSimple(ob.logSeq, ob.symbol, asks, bids)
	orderIdWindow := fmt.Sprintf("%+v", ob.orderIdBitmap.Stats())
	buySize := int64(ob.bids.queue.Size())
	sellSize := int64(ob.asks.queue.Size())
	buyUidSize := int64(len(ob.bids.uorders))
	sellUidSize := int64(len(ob.asks.uorders))
	snapshotLog := newSnapshotLogPb(ob.logSeq, ob.symbol, asks, bids, ob.offset, ob.mqConsumeStatus, ob.workId, orderIdWindow, buySize, sellSize, buyUidSize, sellUidSize)
	return append(logs, snapshotLog)
}

func (ob *OrderBook) QueryOrdersByUser(limit int) models.UserOrderCount {
	ob.RLock()
	defer ob.RUnlock()
	if limit <= 0 {
		limit = 10
	}
	return map[string]map[uint64]int{
		"asks": ob.asks.getUserOrderCount(),
		"bids": ob.bids.getUserOrderCount(),
	}
}

func (ob *OrderBook) OrderBookClear() (logs []*protocol.Log) {
	ob.Lock()
	defer func() {
		ob.Unlock()
	}()

	pb1 := newClearOrderBookLogPb(ob.logSeq, ob.symbol, fmt.Sprintf("%+v", ob.orderIdBitmap.Stats()))
	logs = append(logs, pb1)

	// ob.orderIdBitmap.Clear()

	pb2 := newClearOrderBookLogPb(ob.nextLogSeq(), ob.symbol, fmt.Sprintf("%+v", ob.orderIdBitmap.Stats()))
	logs = append(logs, pb2)
	return logs
}

func (ob *OrderBook) GetConsumeState() (int64, int64) {
	ob.RLock()
	defer ob.RUnlock()
	return ob.offset, ob.mqConsumeStatus
}

func (ob *OrderBook) nextLogSeq() uint64 {
	ob.logSeq++
	return ob.logSeq
}

func (ob *OrderBook) updateOffset(offset int64) int64 {
	ob.offset = offset
	return ob.offset
}

// 获取相同盘
func (ob *OrderBook) getDepth(side models.Side) *depth {
	if side == models.SELL {
		return ob.asks
	} else {
		return ob.bids
	}
}

// 获取对手盘
func (ob *OrderBook) getCounterDepth(side models.Side) *depth {
	if side == models.SELL {
		return ob.bids
	} else {
		return ob.asks
	}
}

// raft快照使用
func (ob *OrderBook) Snapshot() ([]byte, error) {
	ob.RLock()
	defer ob.RUnlock()

	// 避免内存持续增长，bitmap不再写日志
	//bitmapByte, err := ob.orderIdBitmap.MarshalBinary()
	//if err != nil {
	//	log.Errorf("orderIdBitmap.MarshalBinary err: %v", err)
	//	return nil, err
	//}
	snapshot := orderBookSnapshot{
		Orders:          make([]models.Order, len(ob.asks.orders)+len(ob.bids.orders)),
		LogSeq:          ob.logSeq,
		Offset:          ob.offset,
		MqConsumeStatus: ob.mqConsumeStatus,
		//OrderIdBitmap:   bitmapByte,
		WorkId: ob.workId,
	}

	i := 0
	for _, order := range ob.asks.orders {
		snapshot.Orders[i] = *order
		i++
	}
	for _, order := range ob.bids.orders {
		snapshot.Orders[i] = *order
		i++
	}

	b, err2 := json.Marshal(snapshot)
	if err2 != nil {
		return nil, err2
	}
	return b, nil
}

// raft快照恢复
func (ob *OrderBook) Restore(data []byte) error {
	ob.Lock()
	defer ob.Unlock()

	var snapshot orderBookSnapshot
	if err := json.Unmarshal(data, &snapshot); err != nil {
		return err
	}

	log.Warnf("Restore snapshot, symbol:%v, LogSeq:%v, Offset:%v, MqConsumeStatus:%v, WorkId:%v, Orders:%d",
		ob.symbol, snapshot.LogSeq, snapshot.Offset, snapshot.MqConsumeStatus, snapshot.WorkId, len(snapshot.Orders))
	ob.logSeq = snapshot.LogSeq
	ob.offset = snapshot.Offset
	ob.mqConsumeStatus = snapshot.MqConsumeStatus
	ob.orderIdBitmap = utils.NewBitmapCircularBuffer(ob.symbol)
	ob.workId = snapshot.WorkId
	// 避免内存持续增长，bitmap不再写日志
	//if len(snapshot.OrderIdBitmap) > 0 {
	//	buf := bytes.NewBuffer(snapshot.OrderIdBitmap)
	//	if _, err := ob.orderIdBitmap.ReadFrom(buf); err != nil {
	//		log.Errorf("orderIdBitmap.UnmarshalBinary err: %v", err)
	//		return err
	//	}
	//}
	for _, order := range snapshot.Orders {
		if order.Side == models.SELL {
			ob.asks.add(order)
		} else if order.Side == models.BUY {
			ob.bids.add(order)
		}
	}

	return nil
}

// for test
func (ob *OrderBook) SimpleOrderBook() map[string]interface{} {
	ob.RLock()
	defer ob.RUnlock()

	simple := make(map[string]interface{}, 2)
	simple["asks"] = ob.asks.simpleDepth(10)
	simple["bids"] = ob.bids.simpleDepth(10)
	simple["seq"] = ob.logSeq
	simple["offset"] = ob.offset
	return simple
}

func (ob *OrderBook) PrintOrderBook() {
	simple := ob.SimpleOrderBook()

	sellSize := len(simple["asks"].([][]decimal.Decimal))
	buySize := len(simple["bids"].([][]decimal.Decimal))

	for i := sellSize - 1; i >= 0; i-- {
		fmt.Println("sell", simple["asks"].([][]decimal.Decimal)[i])
	}
	fmt.Println("===============================")
	//fmt.Println("=============buy===================")
	for j := 0; j < buySize; j++ {
		fmt.Println("buy", simple["bids"].([][]decimal.Decimal)[j])
	}
}

func (ob *OrderBook) GetSymbol() string {
	return ob.symbol
}

func (ob *OrderBook) GetSeq() uint64 {
	return ob.logSeq
}

// 判断订单能否成为maker
func (ob *OrderBook) checkIsMaker(order *models.Order) bool {
	// 被动单深度
	var makerDepth = ob.getCounterDepth(order.Side)
	isMaker := false
	if makerDepth.queue.Size() > 0 {
		if order.Side == models.BUY {
			// 若用户的委托买入价格＜卖一价, 则用户是Maker.
			// 获取对手盘的最小价格 卖家按照价格升序排队（逻辑最小值就是价格最小值）
			key, _ := makerDepth.queue.Min()
			if key == nil {
				return isMaker
			}
			// makerOrder := makerDepth.orders[value.(uint64)]
			isMaker = order.Price.LessThan(key.(*priceTimeSortKey).price)
		} else if order.Side == models.SELL {
			// 若用户的委托卖出价格＞买一价，则用户是Maker
			// 获取对手盘的最大价格 买价按照价格倒序排队（逻辑最小值就是价格最大值) priceOffsetDescComparator
			key, _ := makerDepth.queue.Min()
			if key == nil {
				return isMaker
			}
			// makerOrder := makerDepth.orders[value.(uint64)]
			isMaker = order.Price.GreaterThan(key.(*priceTimeSortKey).price)
		}
	} else {
		// 对手盘为空 无法立即成交，能成为maker
		return true
	}
	return isMaker
}

// 判断订单能否全部成交
func (ob *OrderBook) checkIsAllFilled(order *models.Order) bool {
	var makerDepth = ob.getCounterDepth(order.Side)

	var tempVal = decimal.Zero

	// todo 优化是否无需遍历到结束
	for itr := makerDepth.queue.Iterator(); itr.Next(); {
		makerOrder := makerDepth.orders[itr.Value().(uint64)]
		if (order.Side == models.BUY && order.Price.LessThan(makerOrder.Price)) ||
			(order.Side == models.SELL && order.Price.GreaterThan(makerOrder.Price)) {
			break
		}

		tempVal = tempVal.Add(makerOrder.Volume.Sub(makerOrder.DealVolume))
	}

	if tempVal.Cmp(order.Volume) < 0 {
		return false
	}
	return true
}
