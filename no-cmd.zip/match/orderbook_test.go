package match

import (
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/protocol"
	"fmt"
	"github.com/emirpasic/gods/maps/treemap"
	"github.com/emirpasic/gods/sets/hashset"
	"github.com/golang/protobuf/proto"
	"github.com/shopspring/decimal"
	"io/ioutil"
	"testing"
)

func check(e error) {
	if e != nil {
		panic(e)
	}
}

func TestNewOrderBook(t *testing.T) {

	offset := uint64(143946481765889411)
	offset2 := int64(1844674407370955161)

	offset2 = int64(offset)
	println(offset)
	println(offset2)

	bids := &depth{
		orders:  map[uint64]*models.Order{},
		queue:   treemap.NewWith(priceOffsetDescComparator),
		uorders: map[uint64]*hashset.Set{},
	}
	asks := &depth{
		orders:  map[uint64]*models.Order{},
		queue:   treemap.NewWith(priceOffsetAscComparator),
		uorders: map[uint64]*hashset.Set{},
	}

	//bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(1.11), -1, 111}, 111)
	//bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(1.11), -1, 222}, 222)
	//bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(1.11), -1, 333}, 222)
	//bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(1.11), -1, 333}, 333)

	//
	bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(101), 1}, 1)
	bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(101), 2}, 2)
	bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(101), 3}, 3)
	bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(101), 4}, 4)
	bids.queue.Put(&priceTimeSortKey{decimal.NewFromFloat(101), 5}, 5)

	fmt.Printf("buy sizee: %v, %v\n", bids.queue.Size(), bids.queue.String())

	asks.queue.Each(func(key interface{}, value interface{}) {
		fmt.Printf("sell price: %v\n", key)
	})
	fmt.Println()
	fmt.Println()
	fmt.Println()
	bids.queue.Each(func(key interface{}, value interface{}) {
		fmt.Printf("buy price: %v\n", key)
	})
}

func TestBitmap_Set(t *testing.T) {

	bidsDepth := &depth{
		orders:  map[uint64]*models.Order{},
		queue:   treemap.NewWith(priceOffsetDescComparator),
		uorders: map[uint64]*hashset.Set{},
	}
	asksDepth := &depth{
		orders:  map[uint64]*models.Order{},
		queue:   treemap.NewWith(priceOffsetAscComparator),
		uorders: map[uint64]*hashset.Set{},
	}

	asks := asksDepth.mergePriceDepth(priceAscComparator, 100)
	bids := bidsDepth.mergePriceDepth(priceDescComparator, 100)

	depthLog := newDepthLogPb(1, "ETH-USDT", asks, bids)
	fmt.Printf("%+v \n", depthLog)

	matchLogs := &protocol.MatchLogs{}
	matchLogs.Logs = append(matchLogs.Logs, depthLog)
	data, err := proto.Marshal(matchLogs)
	if err != nil {

	}

	err2 := ioutil.WriteFile("./depthLog.txt", data, 0666) //写入文件(字节数组)
	check(err2)
}
