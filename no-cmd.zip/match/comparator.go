package match

import "github.com/shopspring/decimal"

//comparator utils.Comparator
// 按照价格优先、时间优先对订单排序的key
type priceTimeSortKey struct {
	price  decimal.Decimal
	offset int64
}

func priceOffsetAscComparator(a, b interface{}) int {
	aAsserted := a.(*priceTimeSortKey)
	bAsserted := b.(*priceTimeSortKey)

	x := aAsserted.price.Cmp(bAsserted.price)
	if x != 0 {
		return x
	}

	y := aAsserted.offset - bAsserted.offset
	if y == 0 {
		return 0
	} else if y > 0 {
		return 1
	} else {
		return -1
	}
}

func priceOffsetDescComparator(a, b interface{}) int {
	aAsserted := a.(*priceTimeSortKey)
	bAsserted := b.(*priceTimeSortKey)

	x := aAsserted.price.Cmp(bAsserted.price)
	if x != 0 {
		return -x
	}

	y := aAsserted.offset - bAsserted.offset
	if y == 0 {
		return 0
	} else if y > 0 {
		return 1
	} else {
		return -1
	}
}

// 只有价格的比较器：卖盘从小到大
func priceAscComparator(a, b interface{}) int {
	aAsserted := a.(decimal.Decimal)
	bAsserted := b.(decimal.Decimal)

	x := aAsserted.Cmp(bAsserted)
	return x
}

// 只有价格的比较器：买盘从大到小
func priceDescComparator(a, b interface{}) int {
	aAsserted := a.(decimal.Decimal)
	bAsserted := b.(decimal.Decimal)

	x := aAsserted.Cmp(bAsserted)
	return -x
}
