package match

import (
	"bytes"
	log "chainup.com/chainup/chmatch/common/logger"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/protocol"
	"errors"
	"fmt"
	"github.com/emirpasic/gods/maps/treemap"
	"github.com/emirpasic/gods/sets/hashset"
	"github.com/emirpasic/gods/utils"
	"github.com/shopspring/decimal"
	"strconv"
)

type depth struct {
	//all orders
	orders map[uint64]*models.Order

	queue *treemap.Map

	// 用户维度订单，方便查询某个用户的当前订单
	uorders map[uint64]*hashset.Set
}

func (d *depth) add(order models.Order) {
	d.orders[order.Id] = &order
	offset := order.Offset
	if order.Offset < 0 {
		offset = int64(order.Id)
	}
	d.queue.Put(&priceTimeSortKey{order.Price, offset}, order.Id)

	uid := order.UserId
	if _, found := d.uorders[uid]; found {
		d.uorders[uid].Add(order.Id)
	} else {
		d.uorders[uid] = hashset.New()
		d.uorders[uid].Add(order.Id)
	}
}

// 从订单簿的限价单中移除当前订单
func (d *depth) remove(orderId uint64) error {
	order, found := d.orders[orderId]
	if !found {
		return errors.New(fmt.Sprintf("order %v not found on book", orderId))
	}

	delete(d.orders, orderId)
	offset := order.Offset
	if order.Offset < 0 {
		offset = int64(order.Id)
	}
	d.queue.Remove(&priceTimeSortKey{order.Price, offset})

	uid := order.UserId
	if _, found := d.uorders[uid]; found {
		d.uorders[uid].Remove(orderId)
	}
	return nil
}

// 从订单簿的限价单中更新本次成交量
func (d *depth) update(orderId uint64, tradeVolume, tradeMoney decimal.Decimal) error {
	order, found := d.orders[orderId]
	if !found {
		return errors.New(fmt.Sprintf("order %v not found on book", orderId))
	}

	if order.RemainVol().LessThan(tradeVolume) {
		return errors.New(fmt.Sprintf("order %v Size %v less than %v", orderId, order.RemainVol(), tradeVolume))
	}

	order.DealVolume = order.DealVolume.Add(tradeVolume)
	order.DealMoney = order.DealMoney.Add(tradeMoney)

	return nil
}

//获取指定uid的当前委托，只返回订单数量
func (d *depth) getUserOrderCount() map[uint64]int {
	// key 为uid， values为订单数
	data := map[uint64]int{}
	// 1. 通过用户查询订单
	for uid, _ := range d.uorders {

		var count = 0
		if _, found := d.uorders[uid]; found {
			for _, orderId := range d.uorders[uid].Values() {
				if _, ok := d.orders[orderId.(uint64)]; ok {
					count++
				} else {
					d.uorders[uid].Remove(orderId)
				}
			}
		}

		if count > 0 {
			data[uid] = count
		}
	}

	// 2. 通过订单查询用户，防止存在遗漏
	for _, order := range d.orders {
		if _, ok := data[order.UserId]; !ok {
			data[order.UserId] = 1
		}
	}
	return data
}

//获取指定uid的当前委托
func (d *depth) getUserOrderLogs(userId uint64, limit int) []*protocol.Order {
	var orderLogs []*protocol.Order
	if _, found := d.uorders[userId]; found {
		for _, orderId := range d.uorders[userId].Values() {
			if order, ok := d.orders[orderId.(uint64)]; ok {
				orderLog := newOrderPb(order)
				orderLogs = append(orderLogs, orderLog)
			} else {
				d.uorders[userId].Remove(orderId)
			}
			if len(orderLogs) >= limit {
				break
			}
		}
	}
	return orderLogs
}

//获取指定uid的当前委托ID
func (d *depth) getUserOrderIds(userId uint64, limit int) string {
	var buffer bytes.Buffer
	if _, found := d.uorders[userId]; found {
		for i, orderId := range d.uorders[userId].Values() {
			if buffer.Len() > 0 {
				buffer.WriteString(",")
			}
			buffer.WriteString(strconv.FormatUint(orderId.(uint64), 10))
			if i >= limit {
				break
			}
		}
	}
	return buffer.String()
}

//获取指定订单id详情
func (d *depth) getOrderDetail(orderId uint64) *models.Order {
	if order, ok := d.orders[orderId]; ok {
		_, orderIdTmp := d.queue.Find(func(key interface{}, value interface{}) bool {
			if value.(uint64) == orderId {
				return true
			}
			return false
		})
		if orderIdTmp == nil {
			log.Warnf("getOrderDetail not found by queue, orderId:%d", orderId)
		}
		return order
	}
	return nil
}

// 合并相同价格的订单，返回（price，volume）数组
func (d *depth) mergePriceDepth(comparator utils.Comparator, limit int) *treemap.Map {
	depthMap := treemap.NewWith(comparator)
	for itr := d.queue.Iterator(); itr.Next(); {
		order := d.orders[itr.Value().(uint64)]
		if order == nil {
			log.Errorf("mergePriceDepth %+v", order)
			continue
		}
		price := order.Price
		volume := order.RemainVol()
		existVolume, found := depthMap.Get(price)
		if found {
			volume = volume.Add(existVolume.(decimal.Decimal))
		}
		depthMap.Put(price, volume)
		if depthMap.Size() > limit {
			break
		}
	}
	return depthMap
}

// 返回方便打印的简化版
func (d *depth) simpleDepth(limit int) [][]decimal.Decimal {
	var simple [][]decimal.Decimal
	for itr := d.queue.Iterator(); itr.Next(); {
		order := d.orders[itr.Value().(uint64)]
		if order == nil {
			log.Errorf("simpleDepth %+v", order)
			continue
		}
		simple = append(simple, []decimal.Decimal{order.Price, order.RemainVol()})
		if len(simple) >= limit {
			break
		}
	}
	if simple == nil {
		simple = make([][]decimal.Decimal, 0)
	}
	return simple
}
