package match

type Result struct {
	Value interface{}
}


// 用于表示一条fill完成的原因
type DoneReason string

const (
	DoneReasonFilled    = DoneReason("filled")
	DoneReasonCancelled = DoneReason("cancelled")
	// 数据库加载的订单取消，这类订单不在orderbook中也需要发消息， 也使用了canceled类型
	//DoneReasonRebuildCancelled = DoneReason("rebuildCancelled")
)