package match

import (
	"chainup.com/chainup/chmatch/common/metrics"
	"chainup.com/chainup/chmatch/models"
	"chainup.com/chainup/chmatch/protocol"
	"github.com/emirpasic/gods/maps/treemap"
	"github.com/shopspring/decimal"
	"strconv"
	"time"
)

// reset: 从数据库重建时发送
// trade: 产生成交记录
// open: 新单进入orderbook成为被动单
// done: 订单转为最终态：已取消，完全成交，退残渣
// depth: orderbook快照
// clearOrderBook: 清除orderBook中bitmap空间
func newResetLogPb(logSeq uint64, symbol string) *protocol.Log {
	return &protocol.Log{
		Type:     "reset",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
	}
}

func newTradeLogPb(logSeq uint64, symbol string, takerOrder, makerOrder *models.Order, price, volume decimal.Decimal) *protocol.Log {
	takerOrderPb := newOrderPb(takerOrder)
	makerOrderPb := newOrderPb(makerOrder)
	metrics.AddTradeOrder()
	return &protocol.Log{
		Type:     "trade",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
		Trade: &protocol.Trade{
			TakerOid:   takerOrder.Id,
			MakerOid:   makerOrder.Id,
			Price:      price.String(),
			Volume:     volume.String(),
			TakerSide:  string(takerOrder.Side),
			TakerOrder: takerOrderPb,
			MakerOrder: makerOrderPb,
		},
	}
}

func newDoneLogPb(logSeq uint64, symbol string, order *models.Order, remainingSize decimal.Decimal, reason DoneReason) *protocol.Log {
	// 提升变量层级减少一次 decimal.Decimal.String
	pb := newOrderPb(order)
	return &protocol.Log{
		Type:     "done",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
		Done: &protocol.Done{
			OrderId:       order.Id,
			Price:         pb.Price,
			RemainingSize: remainingSize.String(),
			Side:          string(order.Side),
			Reason:        string(reason),
			Order:         pb,
		},
	}
}

func newOpenLogPb(logSeq uint64, symbol string, order *models.Order) *protocol.Log {
	// 提升变量层级减少一次 decimal.Decimal.String
	pb := newOrderPb(order)
	return &protocol.Log{
		Type:     "open",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
		Open: &protocol.Open{
			OrderId:       order.Id,
			Price:         pb.Price,
			RemainingSize: order.RemainVol().String(),
			Side:          string(order.Side),
			Order:         pb,
		},
	}
}

//价格相同的会合并
func newDepthLogPb(logSeq uint64, symbol string, asks, bids *treemap.Map) *protocol.Log {
	var asksPb []*protocol.Tick
	var bidsPb []*protocol.Tick

	asks.Each(func(key interface{}, value interface{}) {
		price := key.(decimal.Decimal)
		volume := value.(decimal.Decimal)
		ticker := &protocol.Tick{
			Price:  price.String(),
			Volume: volume.String(),
		}
		asksPb = append(asksPb, ticker)
	})
	bids.Each(func(key interface{}, value interface{}) {
		price := key.(decimal.Decimal)
		volume := value.(decimal.Decimal)
		ticker := &protocol.Tick{
			Price:  price.String(),
			Volume: volume.String(),
		}
		bidsPb = append(bidsPb, ticker)
	})

	// 空的时候，gorocketmq中string(matchLogs)会导致结算java解析失败，暂时传个0
	if asksPb == nil {
		asksPb = []*protocol.Tick{
			{Price: "0", Volume: "0"},
		}
	}
	if bidsPb == nil {
		bidsPb = []*protocol.Tick{
			{Price: "0", Volume: "0"},
		}
	}
	return &protocol.Log{
		Type:     "depth",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
		Depth: &protocol.Depth{
			Asks: asksPb,
			Bids: bidsPb,
		},
	}
}

//相同价格的不合并
func newDepthLogPbSimple(logSeq uint64, symbol string, asks, bids [][]decimal.Decimal) *protocol.Log {
	var asksPb []*protocol.Tick
	var bidsPb []*protocol.Tick
	for _, v := range asks {
		ticker := &protocol.Tick{
			Price:  v[0].String(),
			Volume: v[1].String(),
		}
		asksPb = append(asksPb, ticker)
	}
	for _, v := range bids {
		ticker := &protocol.Tick{
			Price:  v[0].String(),
			Volume: v[1].String(),
		}
		bidsPb = append(bidsPb, ticker)
	}
	return &protocol.Log{
		Type:     "depth",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
		Depth: &protocol.Depth{
			Asks: asksPb,
			Bids: bidsPb,
		},
	}
}

//相同价格的不合并
func newSnapshotLogPb(logSeq uint64, symbol string, asks, bids [][]decimal.Decimal, offset, mqConsumeStatus, workId int64, orderIdWindow string, buySize, sellSize, buyUidSize, sellUidSize int64) *protocol.Log {
	var asksPb []*protocol.Tick
	var bidsPb []*protocol.Tick
	for _, v := range asks {
		ticker := &protocol.Tick{
			Price:  v[0].String(),
			Volume: v[1].String(),
		}
		asksPb = append(asksPb, ticker)
	}
	for _, v := range bids {
		ticker := &protocol.Tick{
			Price:  v[0].String(),
			Volume: v[1].String(),
		}
		bidsPb = append(bidsPb, ticker)
	}
	return &protocol.Log{
		Type:     "snapshot",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
		Depth: &protocol.Depth{
			Asks: asksPb,
			Bids: bidsPb,
		},
		Snapshot: &protocol.Snapshot{
			Offset:          offset,
			MqConsumeStatus: mqConsumeStatus,
			WorkId:          workId,
			OrderIdWindow:   orderIdWindow,
			BuySize:         buySize,
			SellSize:        sellSize,
			BuyUidSize:      buyUidSize,
			SellUidSize:     sellUidSize,
		},
	}
}

func newOrderPb(order *models.Order) *protocol.Order {
	return &protocol.Order{
		Id:           strconv.FormatUint(order.Id, 10),
		UserId:       strconv.FormatUint(order.UserId, 10),
		Side:         string(order.Side),
		Price:        order.Price.String(),
		Volume:       order.Volume.String(),
		FeeRateMaker: strconv.FormatFloat(order.FeeRateMaker, 'f', -1, 64),
		FeeRateTaker: strconv.FormatFloat(order.FeeRateTaker, 'f', -1, 64),
		FeeCoinRate:  strconv.FormatFloat(order.FeeCoinRate, 'f', -1, 64),
		DealVolume:   order.DealVolume.String(),
		DealMoney:    order.DealMoney.String(),
		AvgPrice:     order.AvgPrice.String(),
		Status:       strconv.Itoa(int(order.Status)),
		Type:         strconv.Itoa(int(order.Type)),
		Source:       strconv.Itoa(int(order.Source)),
		CompanyId:    strconv.FormatUint(order.CompanyId, 10),
		OrderType:    strconv.Itoa(int(order.OrderType)),
		Ctime:        strconv.FormatInt(order.Ctime.UnixNano()/1e6, 10),
		Offset:       strconv.FormatInt(order.Offset, 10),
		ClientOrderId: order.ClientOrderId,
	}
}

func newClearOrderBookLogPb(logSeq uint64, symbol string, orderIdWindow string) *protocol.Log {
	return &protocol.Log{
		Type:     "clearOrderBook",
		Sequence: logSeq,
		Symbol:   symbol,
		Time:     time.Now().UnixNano() / 1e6,
		Snapshot: &protocol.Snapshot{
			OrderIdWindow: orderIdWindow,
		},
	}
}
