package match

import "chainup.com/chainup/chmatch/models"

type orderBookSnapshot struct {
	Symbol          string
	Orders          []models.Order
	LogSeq          uint64
	Offset          int64
	MqConsumeStatus int64
	OrderIdBitmap   []byte
	WorkId          int64
}
