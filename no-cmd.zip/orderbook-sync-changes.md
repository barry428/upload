# OrderBook 同步到 Redis 功能说明

## 一、需求说明

### 1.1 开发信息
- 开发分支：`feature/orderbook-sync`（新分支）
- 基准标签：`btag_feature_futures_market_actualLeverage_202408051726`
- 开发时间：2024-05-30

### 1.2 功能需求

1. **订单簿数据同步**
   - 将订单簿深度数据实时同步到 Redis
   - 支持期货和现货交易对
   - 仅在 Leader 节点执行同步
   - 同步频率可配置
   - 订单簿深度档位数可配置
   - 支持动态增加交易对

2. **数据格式要求**
   ```json
   {
       "symbol": "E-BTCUSDT",  // 期货：E-BTCUSDT，现货：BTC-USDT
       "time": 1717123456789,  // 毫秒时间戳
       "asks": [           // 卖单，价格从低到高
           {
               "price": "50000.00",
               "volume": "1.5"
           }
       ],
       "bids": [           // 买单，价格从高到低
           {
               "price": "49999.00",
               "volume": "1.2"
           }
       ]
   }
   ```

3. **性能要求**
   - 同步延迟：< 100ms
   - 数据压缩率：> 80%
   - CPU 使用率：< 10%
   - 内存使用：< 100MB
   - Redis 写入：< 1000 QPS

4. **日志要求**
   - 记录同步状态日志
   - 记录错误日志
   - 记录性能指标日志
   - 日志格式统一，便于监控系统采集

### 1.3 非功能需求

1. **可用性要求**
   - Redis 集群模式部署
   - 支持密码认证
   - 支持动态配置 Redis 节点
   - 保证数据一致性

2. **运维要求**
   - 支持配置热更新（特别是新增交易对时）
   - 提供标准日志输出
   - 便于问题诊断

### 补充说明：币对动态管理

- 币对（交易对）的增删由撮合引擎（engine）统一管理。
- orderbook-sync 模块每次同步时会自动从 engine 获取当前所有活跃币对列表，并同步这些币对的订单簿快照到 Redis。
- 因此，无需在同步模块单独配置或管理币对，新增币对只需在 engine 层完成，orderbook-sync 会自动感知并处理。

## 二、技术方案

### 2.1 系统架构
```
+----------------+     +----------------+     +----------------+
|   撮合引擎      |     |   订单簿同步    |     |   Redis集群    |
|  (主服务)      | --> |   (新增模块)    | --> |  (存储层)      |
+----------------+     +----------------+     +----------------+
```

### 2.2 技术选型

1. **数据存储**
   - Redis Cluster 模式
   - 支持密码认证
   - 使用 Pipeline 批量写入
   - 支持数据压缩（gzip）
   - 支持连接池管理
   - 支持健康检查

2. **核心组件**
   - 同步服务：`engine/sync.go`
   - Redis 管理器：`engine/redis.go`
   - 配置管理：`conf/config.go`

### 2.3 详细设计

1. **配置定义**
   ```yaml
   orderbook_sync:
     enabled: true                # 是否启用同步
     sync_interval: "100ms"       # 同步频率
     max_depth: 20               # 订单簿深度档位数
     compress_level: 6           # 压缩级别 (0-9)
   
   redis:
     nodes:                      # Redis 节点列表
       - "127.0.0.1:7001"
       - "127.0.0.1:7002"
       - "127.0.0.1:7003"
     password: "******"          # Redis 密码
     pool_size: 10              # 连接池大小
     min_idle_conns: 5          # 最小空闲连接数
     read_timeout: "3s"         # 读取超时
     write_timeout: "3s"        # 写入超时
     dial_timeout: "5s"         # 连接超时
   ```

2. **核心接口**
   ```go
   // engine/sync.go
   type OrderBookSync interface {
       Start(ctx context.Context) error  // 启动同步服务
       Stop() error                     // 停止同步服务
       Sync() error                     // 执行一次同步
   }

   // engine/redis.go
   type RedisManager struct {
       // Redis 管理器，负责与 Redis Cluster 的交互
       // 包含以下主要功能：
       // 1. 连接管理：初始化、健康检查、自动重连
       // 2. 数据同步：批量写入、数据压缩
       // 3. 错误处理：连接异常、写入失败等
   }
   ```

3. **日志设计**
   ```go
   // 同步状态日志
   log.Infof("订单簿同步状态: symbol=%s, depth=%d, latency=%dms", 
       symbol, depth, latency)

   // 错误日志
   log.Errorf("订单簿同步错误: symbol=%s, error=%v", symbol, err)

   // 性能指标日志
   log.Infof("订单簿同步指标: batch_size=%d, compress_ratio=%.2f, cpu_usage=%.2f%%", 
       batchSize, compressRatio, cpuUsage)

   // Redis 连接状态日志
   log.Infof("Redis 连接状态: nodes=%v, status=%s", nodes, status)

   // 健康检查日志
   log.Infof("Redis 健康检查: ping_latency=%dms, error=%v", latency, err)
   ```

### 2.4 实现步骤

1. **第一阶段：基础框架**
   - 创建核心模块
   - 实现基础接口
   - 配置管理
   - 日志系统
   - Redis 连接管理

2. **第二阶段：核心功能**
   - 同步服务实现
   - 数据处理实现
   - Redis 管理器实现
   - 健康检查机制
   - 自动重连机制

3. **第三阶段：优化完善**
   - 性能优化
   - 内存优化
   - 日志完善
   - 错误处理
   - 连接池管理

4. **第四阶段：测试验证**
   - 功能测试
   - 性能测试
   - 稳定性测试
   - 压力测试

### 2.5 监控指标

1. **基础指标**
   - 同步延迟
   - 数据大小
   - 压缩率
   - 错误率
   - Redis 连接状态
   - 健康检查状态

2. **性能指标**
   - CPU 使用率
   - 内存使用
   - Redis 连接数
   - Redis 写入延迟
   - Pipeline 批量大小
   - 压缩耗时

### 2.6 可靠性设计

1. **连接管理**
   - 连接池管理
   - 健康检查机制
   - 自动重连机制
   - 超时控制

2. **错误处理**
   - 连接异常处理
   - 写入失败重试
   - 数据压缩异常处理
   - 配置错误处理

3. **数据一致性**
   - 批量写入原子性
   - 数据压缩可靠性
   - 状态机查询一致性

### 2.7 性能优化

1. **数据同步优化**
   - 使用 Pipeline 批量写入
   - 支持数据压缩
   - 优化内存使用
   - 及时释放临时对象

2. **连接优化**
   - 连接池管理
   - 最小空闲连接
   - 超时控制
   - 健康检查

3. **内存优化**
   - 对象复用
   - 及时释放
   - 控制深度档位
   - 压缩数据

### 2.8 后续规划

1. **性能监控**
   - 添加详细的性能指标收集
   - 完善监控告警机制
   - 优化指标展示

2. **配置管理**
   - 支持更多 Redis 配置项
   - 优化配置热更新机制
   - 完善配置验证

3. **测试用例**
   - 补充单元测试
   - 添加性能测试用例
   - 完善集成测试
   - 添加压力测试

## 三、最新改动说明（2024-03-26）

### 3.1 代码改动

1. **新增文件**
   - `engine/redis.go`: Redis 管理器实现，负责与 Redis Cluster 的交互
   - `engine/sync.go`: 订单簿同步服务实现，负责数据同步逻辑

2. **修改文件**
   - `conf/config.go`: 更新配置结构，添加 Redis 和 OrderBookSync 相关配置
   - `conf/cluster1-node1.yml`: 更新配置文件，添加 Redis 和 OrderBookSync 配置项
   - `engine/engine.go`: 集成订单簿同步服务
   - `go.mod` 和 `go.sum`: 更新依赖包版本

### 3.2 配置更新

1. **Redis 配置**
   ```yaml
   redis:
     nodes:
       - "127.0.0.1:7001"
       - "127.0.0.1:7002"
       - "127.0.0.1:7003"
     password: "WOJdJ4HLWCQx9K3E"
     pool_size: 10
     min_idle_conns: 5
     read_timeout: "3s"
     write_timeout: "3s"
     dial_timeout: "5s"
   ```

2. **订单簿同步配置**
   ```yaml
   orderbook_sync:
     enabled: true                # 是否启用同步
     sync_interval: "100ms"       # 同步频率
     max_depth: 20               # 订单簿深度档位数
     compress_level: 6           # 压缩级别 (0-9)
   ```

### 3.3 功能优化

1. **实时深度数据获取**
   - 使用 `ApplyTypePushDepth` 替代 `ApplyTypeQueryDepth`，获取完整的深度数据
   - 通过状态机查询获取实时订单簿状态
   - 支持动态调整深度档位数

2. **性能优化**
   - 使用 Pipeline 批量写入 Redis
   - 支持数据压缩，可配置压缩级别
   - 优化内存使用，及时释放临时对象

3. **可靠性提升**
   - 添加 Redis 连接健康检查
   - 支持自动重连机制
   - 完善的错误处理和日志记录

### 3.4 依赖更新

1. **主要依赖包**
   - `github.com/redis/go-redis/v9`: Redis 客户端
   - `google.golang.org/protobuf`: Protocol Buffers
   - `github.com/klauspost/compress/gzip`: 数据压缩

2. **版本兼容性**
   - 支持 Go 1.23.4
   - 更新了 `golang.org/x/net` 等依赖包版本

### 3.5 待优化项

1. **性能监控**
   - 添加详细的性能指标收集
   - 完善监控告警机制

2. **配置管理**
   - 支持更多 Redis 配置项
   - 优化配置热更新机制

3. **测试用例**
   - 补充单元测试
   - 添加性能测试用例
   - 完善集成测试 


git checkout -b branch_feature_bitbaby_v1.0.0 btag_feature_baibiao_v2.0.3 | cat
git stash pop | cat

./bin/chmatchd -config conf/cluster1-node1.yml > logs/chmatch.log  2>&1

gvm use go1.23.4 --default

gvm use go1.17 --default


go build -ldflags "-X chainup.com/chainup/chmatch/sys.macAddress="   main.go


18.183.72.71
用户：ec2-user
端口：22

ssh -i ~/.ssh/match-test.pem  ec2-user@18.183.72.71 -p 22
ssh -i ~/.ssh/new_match_id_rsa root@10.0.0.118
ssh -i ~/.ssh/new_match_id_rsa root@10.0.0.113



scp -i ~/.ssh/new_match_id_rsa rocketmq-client-cpp-2.1.0-bin-release.tar.gz  root@10.0.0.118:/tmp

scp -i ~/.ssh/new_match_id_rsa root@10.0.0.118:/tmp/chmatch-futures/bin/chmatchd-futures-prod ./
scp -i ~/.ssh/new_match_id_rsa root@10.0.0.118:/tmp/chmatch/bin/chmatchd-spot-prod ./


bc:24:11:8d:5f:ff
9ad10f7a966dd93a8114262df0333e88


go build -ldflags "-X chainup.com/chainup/chmatch/sys.macAddress=0a:ac:24:f0:4d:2f" -o bin/chmatchd-spot-prod cmd/chmatchd/main.go


redis-cli -h 10.0.0.117 -p 7000 -a LrhswUshvaVdOv1lEUBw