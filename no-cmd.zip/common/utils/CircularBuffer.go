package utils

import (
	"chainup.com/chainup/chmatch/common/logger"
	"fmt"
	"runtime/debug"
	"sync"
	"time"
)
import "github.com/RoaringBitmap/roaring/roaring64"

type BitmapCircularBuffer interface {
	CheckedAdd(data uint64) bool
	Stats() string
}

var globalIdx uint64 = 0
var timerOnce sync.Once

func init() {
	// 全局定时器， 用于更新循环数组的索引id
	timerOnce.Do(func() {
		// 初始化定时器，步长为30分钟
		ticker := time.NewTicker(30 * time.Minute)

		go func() {
			defer func() {
				ticker.Stop()
				if err := recover(); err != nil {
					debug.PrintStack()
					logger.Errorf("bitmapCircularBuffer hourTimer painc. err=%+v", err)
				}
			}()
			logger.Infof("bitmapCircularBuffer hourTimer init, beginIdx: %v", globalIdx)
			for {
				select {
				case <-ticker.C:
					globalIdx++
					logger.Infof("global ticker is running. globalIdx=%v", globalIdx)
				}
			}
		}()
	})
}

func NewBitmapCircularBuffer(name string) BitmapCircularBuffer {
	var buf [12]*roaring64.Bitmap
	for i := 0; i < len(buf); i++ {
		buf[i] = roaring64.New()
	}
	tmpIdx := globalIdx
	return &bitmapCircularBuffer{
		name:        name,
		buf:         buf,
		bufIdx:      tmpIdx % uint64(len(buf)),
		counter:     tmpIdx,
		numOfCycles: 0,
	}
}

// uint64CircularBuffer uint64循环缓冲区
type bitmapCircularBuffer struct {
	name string
	// 固定容量缓存 实现订单判重 大小选定为12（经bench测试）
	buf [12]*roaring64.Bitmap
	// 用于记录buf索引位置 必须用求模的方式运算，cb.counter % uint64(len(cb.buf))
	bufIdx uint64
	// 内部计数器
	counter uint64
	// 循环次数
	numOfCycles uint64
}

// bitmap用于快速查找数据。
// buf用于循环存储数据，写满后进行覆盖写，并从bitmap中移除被覆盖的值。
// 通过循环链表的形式限制内存的使用

// CheckedAdd 并发不安全， false 表示已经存在， true 表示添加成功
func (cb *bitmapCircularBuffer) CheckedAdd(data uint64) bool {
	for _, b := range cb.buf {
		if b.Contains(data) {
			return false
		}
	}
	// 放入bitmap
	if isFirst := cb.buf[cb.bufIdx].CheckedAdd(data); !isFirst {
		return false
	}

	//currentIdx 与cb.counter 的差值不一定为1，因此要用大于进行判断
	if globalIdx-cb.counter > 0 {
		cb.counter = globalIdx
		// modValue 范围 [0, len(cb.buf))
		modValue := cb.counter % uint64(len(cb.buf))
		// 重置下一个索引位置
		cb.buf[modValue] = roaring64.New()
		// 更新索引
		cb.bufIdx = modValue
		// modValue == 0 意味着已经循环过一圈
		if modValue == 0 {
			cb.numOfCycles++
		}
		logger.Infof("[%s] loop [%v] idx [%v] globalIdx [%v].", cb.name, cb.numOfCycles, cb.bufIdx, cb.counter)
	}
	return true
}

func (cb *bitmapCircularBuffer) Stats() string {
	return fmt.Sprintf("%+v", cb.buf[cb.bufIdx].Stats())
}
