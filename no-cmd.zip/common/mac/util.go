package mac

import (
	"chainup.com/chainup/chmatch/sys"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"time"
)

var client = &http.Client{
	Timeout: 5 * time.Second,
}

func doRequest(httpMethod string, url string, header map[string]string) ([]byte, error) {
	req, _ := http.NewRequest(httpMethod, url, nil)
	req.Header.Set("User-Agent", "curl/7.74.0")
	if header != nil {
		for k, v := range header {
			req.Header.Set(k, v)
		}
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, errors.New(fmt.Sprintf("HttpStatusCode:%d ,Desc:%s", resp.StatusCode, resp.Status))
	}
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	dataCopy := make([]byte, len(data))
	copy(dataCopy, data)
	return dataCopy, nil
}

// GetAwsMac 获取aws mac地址
// curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 600"
// curl -H "X-aws-ec2-metadata-token: " http://169.254.169.254/latest/meta-data/mac
// https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/configuring-instance-metadata-service.html
func getAwsMac() string {
	// 获取token
	token, err := doRequest(http.MethodPut, "http://169.254.169.254/latest/api/token", map[string]string{
		"X-aws-ec2-metadata-token-ttl-seconds": "600", // token 有效期 10分钟
	})
	if err != nil {
		fmt.Printf("[sys-aws] warn | Fail to get token, error=%+v\n", err)
		return ""
	}
	fmt.Printf("[sys-aws] data=%v\n", string(token))

	// 获取mac
	data, err := doRequest(http.MethodGet, "http://169.254.169.254/latest/meta-data/mac", map[string]string{
		"X-aws-ec2-metadata-token": string(token), // token
	})
	if err != nil {
		fmt.Printf("[sys-aws] warn | Fail to get mac, error=%+v\n", err)
		return ""
	}
	fmt.Printf("[sys-aws] mac=%v\n", string(data))
	return string(data)
}

type networkData struct {
	Links []struct {
		EthernetMacAddress string `json:"ethernet_mac_address"`
	} `json:"links"`
}

// GetHuaweiMac 获取华为云mac地址
// curl http://169.254.169.254/openstack/latest/network_data.json
// https://support.huaweicloud.com/usermanual-ecs/ecs_03_0166.html#section9
func getHuaweiMac() []string {
	result, err := doRequest(http.MethodGet, "http://169.254.169.254/openstack/latest/network_data.json", nil)
	if err != nil {
		fmt.Printf("[sys-huawei] warn | Fail to get data, error=%+v\n", err)
		return nil
	}
	fmt.Printf("[sys-huawei] result=%v\n", string(result))
	var data networkData
	err = json.Unmarshal(result, &data)
	if err != nil {
		fmt.Printf("[sys-huawei] warn | Fail to unmarshal data, error=%+v\n", err)
		return nil
	}
	if len(data.Links) <= 0 {
		fmt.Printf("[sys-huawei] warn | Fail to find mac, error=%+v\n", err)
		return nil
	}
	var macs []string
	for _, link := range data.Links {
		macs = append(macs, link.EthernetMacAddress)
	}
	fmt.Printf("[sys-huawei] macs=%v\n", macs)
	return macs
}

type macLookupData struct {
	Success bool `json:"success"`
	Found   bool `json:"found"`
}

// GetEth0Macs 获取本地的mac数据
func getEth0Macs() string {
	// 只获取本地的eth0网络接口，其他接口有可能是被虚拟出来的
	inter, err := net.InterfaceByName("eth0")
	if err != nil || inter.HardwareAddr == nil {
		fmt.Printf("[sys-local] warn | Fail to get net mac, error=%+v\n", err)
		return ""
	}
	mac := inter.HardwareAddr.String()
	// 远程验证 mac地址是否合法 ac:07:75:07:e8:70
	result, err := doRequest(http.MethodGet, "https://api.maclookup.app/v2/macs/"+mac, nil)
	if err != nil {
		fmt.Printf("[sys-local] warn | Fail to mac(%s), error=%+v\n", mac, err)
		return ""
	}
	fmt.Printf("[sys-local] result=%v\n", string(result))
	var data macLookupData
	err = json.Unmarshal(result, &data)
	if err != nil {
		fmt.Printf("[sys-local] warn | Fail to unmarshal data, error=%+v\n", err)
		return ""
	}
	if !data.Success || !data.Found {
		fmt.Printf("[sys-local] warn | Fail to find mac, error=%+v\n", err)
		return ""
	}
	fmt.Printf("[sys-local] mac=%v\n", mac)
	return mac
}

// CheckSysMac 检查系统mac地址是否匹配
func CheckSysMac() {
	address := sys.GetMacAddress()
	if len(address) <= 0 {
		fmt.Println("[sys] no mac address")
		return
	}

	// 如果是华为云mac 则直接返回
	macs := getHuaweiMac()
	for _, mac := range macs {
		if strings.ToLower(mac) == strings.ToLower(address) {
			fmt.Printf("[sys-huawei] mac(%s) success.\n", address)
			return
		}
	}
	// 如果是aws mac 则直接返回
	mac := getAwsMac()
	if strings.ToLower(mac) == strings.ToLower(address) {
		fmt.Printf("[sys-aws] mac(%s) success.\n", address)
		return
	}

	// 本地mac优先级最低，本地mac地址容易伪造
	// 只有从云环境获取的数据都失败后，才会检查本地mac
	if len(macs) <= 0 && len(mac) <= 0 {
		mac = getEth0Macs()
		if strings.ToLower(mac) == strings.ToLower(address) {
			fmt.Printf("[sys-local] eth0 mac(%s) success.\n", address)
			return
		}
	}
	fmt.Fprintf(os.Stderr, "[sys] mac(%s) invalid\n", address)
	fmt.Println("Mac不一致,程序无法启动,请联系相关人员")
	os.Exit(-1)
	return
}
