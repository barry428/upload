package mock

import (
	"chainup.com/chainup/chmatch/models"
	"github.com/shopspring/decimal"
	"math/rand"
	"sync"
	"sync/atomic"
	"time"
)

var gid uint64
var o int64

func init() {
	gid = 383870175369379853
}

var gidSync sync.Mutex

func getGID() uint64 {
	gidSync.Lock()
	defer gidSync.Unlock()
	return atomic.AddUint64(&gid, 1)
}

var goSync sync.Mutex

func getGO() int64 {
	goSync.Lock()
	defer goSync.Unlock()
	return atomic.AddInt64(&o, 1)
}
func defaultOrder() *models.Order {
	return &models.Order{
		Id:           uint64(time.Now().UnixNano() / 1e6),
		UserId:       uint64(22),
		FeeRateMaker: 0,
		FeeRateTaker: 0,
		FeeCoinRate:  0,
		Status:       models.STATUS_INIT,
		Type:         models.ORDER_LIMIT,
		Ctime:        time.Now(),
		Source:       2,
		OrderType:    1,
		CompanyId:    1024,
		DealVolume:   decimal.NewFromFloat(0),
		DealMoney:    decimal.NewFromFloat(0),
		AvgPrice:     decimal.NewFromFloat(0),
		IsRebuild:    false,
	}
}

// MockOneOrder 构造随机单
func MockOneOrder(symbol string) []*models.Order {
	var orders []*models.Order

	var side = models.SELL
	if rand.Float64() > 0.5 {
		side = models.BUY
	}
	o := &models.Order{
		Id:           getGID(),
		UserId:       uint64(22),
		Side:         side,
		Price:        decimal.NewFromFloat(rand.Float64()).Truncate(10),
		Volume:       decimal.NewFromFloat(rand.Float64() * 100000).Truncate(8),
		FeeRateMaker: 0,
		FeeRateTaker: 0,
		FeeCoinRate:  0,
		Status:       models.STATUS_INIT,
		Type:         models.ORDER_LIMIT,
		Ctime:        time.Now(),
		Source:       2,
		OrderType:    1,
		CompanyId:    1024,
		DealVolume:   decimal.NewFromFloat(0),
		DealMoney:    decimal.NewFromFloat(0),
		AvgPrice:     decimal.NewFromFloat(0),
		Symbol:       symbol,
		IsRebuild:    false,
		Offset:       getGO(),
	}

	orders = append(orders, o)

	return orders
}

//MockSomeOrders 构造范围价格单
func MockSomeOrders(symbol string) []*models.Order {
	var orders []*models.Order

	for i := 0; i <= 10000; i++ {
		price := decimal.NewFromFloat(100).Truncate(10)
		o := models.Order{
			Id:           getGID(),
			UserId:       uint64(22),
			Side:         models.BUY,
			Price:        price.Add(decimal.NewFromFloat(float64(i) / 10000)),
			Volume:       decimal.NewFromFloat(1).Truncate(8),
			FeeRateMaker: 0,
			FeeRateTaker: 0,
			FeeCoinRate:  0,
			Status:       models.STATUS_INIT,
			Type:         models.ORDER_LIMIT,
			Ctime:        time.Now(),
			Source:       2,
			OrderType:    1,
			CompanyId:    1024,
			DealVolume:   decimal.NewFromFloat(0),
			DealMoney:    decimal.NewFromFloat(0),
			AvgPrice:     decimal.NewFromFloat(0),
			Symbol:       symbol,
			IsRebuild:    false,
			Offset:       getGO(),
		}
		orders = append(orders, &o)

	}

	return orders
}

//MockFixedOrder 构造固定价格单
func MockFixedOrder(symbol string) *models.Order {
	//var side = models.SELL
	var side = models.BUY
	o := &models.Order{
		Id:           uint64(time.Now().UnixNano() / 1e6),
		UserId:       uint64(22),
		Side:         side,
		Price:        decimal.NewFromFloat(0.0198086703).Truncate(10),
		Volume:       decimal.NewFromFloat(27725.62447067).Truncate(8),
		FeeRateMaker: 0,
		FeeRateTaker: 0,
		FeeCoinRate:  0,
		Status:       models.STATUS_INIT,
		Type:         models.ORDER_LIMIT,
		Ctime:        time.Now(),
		Source:       2,
		OrderType:    1,
		CompanyId:    1024,
		DealVolume:   decimal.NewFromFloat(0),
		DealMoney:    decimal.NewFromFloat(0),
		AvgPrice:     decimal.NewFromFloat(0),
		Symbol:       symbol,
		IsRebuild:    false,
	}

	//time.Sleep(time.Second * 3)

	return o
}

//MockSelfTradeOrder 构造自成交单
func MockSelfTradeOrder(symbol string) []*models.Order {
	var orders []*models.Order
	o1 := defaultOrder()
	o1.Id = getGID()
	o1.Side = models.SELL
	o1.Price = decimal.NewFromFloat(0.0006).Truncate(10)
	o1.Volume = decimal.NewFromFloat(100.2345234).Truncate(8)
	o1.Symbol = symbol
	o1.Offset = int64(o1.Id)

	o2 := defaultOrder()
	o2.Id = getGID()
	o2.Side = models.BUY
	o2.Price = decimal.NewFromFloat(0.0006).Truncate(10)
	o2.Volume = decimal.NewFromFloat(100.2345234).Truncate(8)
	o2.Symbol = symbol
	o2.Offset = int64(o2.Id)

	orders = append(orders, o1, o2)
	//time.Sleep(time.Millisecond * 100000)

	return orders
}

func MockMultiOrder() []*models.Order {

	var orders []*models.Order

	o1 := &models.Order{
		Id:     getGID(),
		Side:   models.SELL,
		Type:   models.ORDER_LIMIT,
		Price:  decimal.NewFromFloat(0.0006).Truncate(10),
		Volume: decimal.NewFromFloat(100.2345234).Truncate(8),
		Symbol: "BTC-USDT",
		Status: models.STATUS_INIT,
	}
	o2 := &models.Order{
		Id:    uint64(time.Now().UnixNano()),
		Side:  models.BUY,
		Type:  models.ORDER_LIMIT,
		Price: decimal.NewFromFloat(0.0006).Truncate(10),

		Volume: decimal.NewFromFloat(100.2345234).Truncate(8),
		Symbol: "BTC-USDT",
		Status: models.STATUS_INIT,
	}
	orders = append(orders, o1, o2)
	return orders
}
