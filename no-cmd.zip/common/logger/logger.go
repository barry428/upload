package logger

import (
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"path/filepath"
	"strconv"
	"sync"
)

type Config struct {
	// 日志级别
	Level string
}

var configOnce sync.Once

func Init(conf Config) {
	configOnce.Do(func() {
		// 设置日志级别
		switch conf.Level {
		case "error":
			zerolog.SetGlobalLevel(zerolog.ErrorLevel)
		case "warn":
			zerolog.SetGlobalLevel(zerolog.WarnLevel)
		case "info":
			zerolog.SetGlobalLevel(zerolog.InfoLevel)
		case "debug":
			zerolog.SetGlobalLevel(zerolog.DebugLevel)
		default:
			zerolog.SetGlobalLevel(zerolog.InfoLevel)
		}
		zerolog.MessageFieldName = "msg"
		// 只打印文件名和行号
		zerolog.CallerMarshalFunc = func(pc uintptr, file string, line int) string {
			return filepath.Base(file) + ":" + strconv.Itoa(line)
		}
		log.Logger = log.With().Caller().Logger()
		log.Info().Msg("logger init success")
	})
}

func Errorf(format string, args ...interface{}) {
	log.Error().CallerSkipFrame(1).Msgf(format, args...)
}

func Error(msg string) {
	log.Error().CallerSkipFrame(1).Msg(msg)
}

func Warnf(format string, args ...interface{}) {
	log.Warn().CallerSkipFrame(1).Msgf(format, args...)
}

func Warn(msg string) {
	log.Warn().CallerSkipFrame(1).Msg(msg)
}

func Infof(format string, args ...interface{}) {
	log.Info().CallerSkipFrame(1).Msgf(format, args...)
}

func Info(msg string) {
	log.Info().CallerSkipFrame(1).Msg(msg)
}

func Debugf(format string, args ...interface{}) {
	log.Debug().CallerSkipFrame(1).Msgf(format, args...)
}

func Debug(msg string) {
	log.Debug().CallerSkipFrame(1).Msg(msg)
}

func GetLevel() string {
	return zerolog.GlobalLevel().String()
}

func IsDebug() bool {
	return zerolog.GlobalLevel() == zerolog.DebugLevel
}
