package metrics

var receivedOrders = 0
var tradeOrders = 0
var sendLogs = 0

func AddReceivedOrder() {
	receivedOrders++
}

func AddTradeOrder() {
	tradeOrders++
}

func AddSendLogs() {
	sendLogs++
}

func GetReceivedOrders() int {
	return receivedOrders
}

func GetTradeOrder() int {
	return tradeOrders
}

func GetSendLogs() int {
	return sendLogs
}
