#!/bin/bash

# 定义颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 定义日志和配置目录
LOG_DIR="logs"
CONF_DIR="conf"
BIN_DIR="bin"

# 检查必要的目录是否存在
check_dirs() {
    for dir in "$LOG_DIR" "$CONF_DIR" "$BIN_DIR"; do
        if [ ! -d "$dir" ]; then
            echo -e "${RED}错误: 目录 $dir 不存在${NC}"
            exit 1
        fi
    done
}

# 检查可执行文件是否存在
check_binary() {
    if [ ! -f "$BIN_DIR/chmatchd" ]; then
        echo -e "${RED}错误: $BIN_DIR/chmatchd 不存在${NC}"
        exit 1
    fi
}

# 启动节点
start_nodes() {
    local nodes=("$@")
    for node in "${nodes[@]}"; do
        if [ -f "$LOG_DIR/chmatch${node}.log" ]; then
            echo -e "${YELLOW}警告: chmatch${node}.log 已存在，将被覆盖${NC}"
        fi
        echo -e "${GREEN}启动节点 $node...${NC}"
        # 打印启动命令
        echo -e "${YELLOW}执行命令: nohup ./$BIN_DIR/chmatchd -config $CONF_DIR/cluster1-node${node}.yml > $LOG_DIR/chmatch${node}.log 2>&1 &${NC}"
        nohup ./$BIN_DIR/chmatchd -config $CONF_DIR/cluster1-node${node}.yml > $LOG_DIR/chmatch${node}.log 2>&1 &
        echo $! > "$LOG_DIR/chmatch${node}.pid"
        sleep 1
        if ps -p $(cat "$LOG_DIR/chmatch${node}.pid") > /dev/null; then
            echo -e "${GREEN}节点 $node 启动成功${NC}"
        else
            echo -e "${RED}节点 $node 启动失败，请检查日志${NC}"
        fi
    done
}

# 停止节点
stop_nodes() {
    local nodes=("$@")
    for node in "${nodes[@]}"; do
        if [ -f "$LOG_DIR/chmatch${node}.pid" ]; then
            local pid=$(cat "$LOG_DIR/chmatch${node}.pid")
            if ps -p $pid > /dev/null; then
                echo -e "${YELLOW}停止节点 $node (PID: $pid)...${NC}"
                kill $pid
                sleep 1
                if ! ps -p $pid > /dev/null; then
                    echo -e "${GREEN}节点 $node 已停止${NC}"
                    rm "$LOG_DIR/chmatch${node}.pid"
                else
                    echo -e "${RED}节点 $node 停止失败，尝试强制停止...${NC}"
                    kill -9 $pid
                    rm "$LOG_DIR/chmatch${node}.pid"
                fi
            else
                echo -e "${YELLOW}节点 $node 已经停止${NC}"
                rm "$LOG_DIR/chmatch${node}.pid"
            fi
        else
            echo -e "${YELLOW}节点 $node 的 PID 文件不存在${NC}"
        fi
    done
}

# 查看节点状态
status_nodes() {
    local nodes=("$@")
    for node in "${nodes[@]}"; do
        if [ -f "$LOG_DIR/chmatch${node}.pid" ]; then
            local pid=$(cat "$LOG_DIR/chmatch${node}.pid")
            if ps -p $pid > /dev/null; then
                echo -e "${GREEN}节点 $node 正在运行 (PID: $pid)${NC}"
            else
                echo -e "${RED}节点 $node 已停止 (PID 文件存在但进程不存在)${NC}"
            fi
        else
            echo -e "${YELLOW}节点 $node 未运行${NC}"
        fi
    done
}

# 显示帮助信息
show_help() {
    echo "使用方法: $0 [命令] [节点号...]"
    echo "命令:"
    echo "  start   启动指定的节点"
    echo "  stop    停止指定的节点"
    echo "  status  查看指定节点的状态"
    echo "  restart 重启指定的节点"
    echo "  all     启动所有节点 (1-3)"
    echo "示例:"
    echo "  $0 start 1 2     # 启动节点 1 和 2"
    echo "  $0 stop 1        # 停止节点 1"
    echo "  $0 status 1 2 3  # 查看节点 1、2、3 的状态"
    echo "  $0 restart 1     # 重启节点 1"
    echo "  $0 all          # 启动所有节点"
}

# 主程序
main() {
    check_dirs
    check_binary

    if [ $# -lt 1 ]; then
        show_help
        exit 1
    fi

    case "$1" in
        "start")
            shift
            if [ $# -eq 0 ]; then
                echo -e "${RED}错误: 请指定要启动的节点号${NC}"
                exit 1
            fi
            start_nodes "$@"
            ;;
        "stop")
            shift
            if [ $# -eq 0 ]; then
                echo -e "${RED}错误: 请指定要停止的节点号${NC}"
                exit 1
            fi
            stop_nodes "$@"
            ;;
        "status")
            shift
            if [ $# -eq 0 ]; then
                status_nodes 1 2 3
            else
                status_nodes "$@"
            fi
            ;;
        "restart")
            shift
            if [ $# -eq 0 ]; then
                echo -e "${RED}错误: 请指定要重启的节点号${NC}"
                exit 1
            fi
            stop_nodes "$@"
            sleep 2
            start_nodes "$@"
            ;;
        "all")
            start_nodes 1 2 3
            ;;
        *)
            show_help
            exit 1
            ;;
    esac
}

# 运行主程序
main "$@" 