package main

import (
	"flag"
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"time"

	"github.com/golang/protobuf/proto"
	"chainup.com/chainup/chmatch/protocol"
	"github.com/shopspring/decimal"
	"github.com/apache/rocketmq-client-go/core"
	//"encoding/base64"
)

var (
	symbol    string
	side      string
	price     float64
	volume    float64
	uid       string
	open      string
	output    string
	orderType string
	mode      string
	tag       string
	key       string

	// 新增参数
	minPrice    float64
	maxPrice    float64
	minVolume   float64
	maxVolume   float64
	orderCount  int
	pricePrec   int  // 价格精度
	volumePrec  int  // 数量精度
)

func init() {
	flag.StringVar(&symbol, "symbol", "", "交易对")
	flag.StringVar(&side, "side", "", "买卖方向(BUY/SELL)")
	flag.Float64Var(&price, "price", 0, "价格")
	flag.Float64Var(&volume, "volume", 0, "数量")
	flag.StringVar(&uid, "uid", "1001", "用户ID")
	flag.StringVar(&open, "open", "OPEN", "开平仓(OPEN/CLOSE)")
	flag.StringVar(&output, "output", "base64", "输出格式(json/base64/hex/bin/send)")
	flag.StringVar(&orderType, "type", "1", "订单类型(1:限价单)")
	flag.StringVar(&mode, "mode", "", "模式: send=直接发送到MQ")
	flag.StringVar(&tag, "tag", "", "MQ Tag，可选")
	flag.StringVar(&key, "key", "", "MQ Key，可选")

	// 新增参数
	flag.Float64Var(&minPrice, "minPrice", 0, "最低价格")
	flag.Float64Var(&maxPrice, "maxPrice", 0, "最高价格")
	flag.Float64Var(&minVolume, "minVolume", 0, "最小数量")
	flag.Float64Var(&maxVolume, "maxVolume", 0, "最大数量")
	flag.IntVar(&orderCount, "count", 0, "订单总数(买卖各50%)")
	flag.IntVar(&pricePrec, "pricePrec", 2, "价格精度(小数点后位数)")
	flag.IntVar(&volumePrec, "volumePrec", 4, "数量精度(小数点后位数)")
}

// 生成随机价格，并应用精度
func randomPrice(min, max float64, precision int) decimal.Decimal {
	price := min + rand.Float64()*(max-min)
	return decimal.NewFromFloat(price).Round(int32(precision))
}

// 生成随机数量，并应用精度
func randomVolume(min, max float64, precision int) decimal.Decimal {
	volume := min + rand.Float64()*(max-min)
	return decimal.NewFromFloat(volume).Round(int32(precision))
}

// 生成随机订单
func generateOrder(symbol string, side string, minPrice, maxPrice, minVolume, maxVolume float64, uid string) *protocol.PlaceOrderMessage {
	price := randomPrice(minPrice, maxPrice, pricePrec)
	volume := randomVolume(minVolume, maxVolume, volumePrec)
	orderId := uint64(time.Now().UnixNano())
	uidInt, _ := strconv.ParseUint(uid, 10, 64)

	return &protocol.PlaceOrderMessage{
		Header: &protocol.PlaceOrderMessage_Header{
			Version:   "1",
			TopicName: fmt.Sprintf("EXCHANGE_ORDER_TOPIC_%s", symbol),
		},
		Body: &protocol.PlaceOrderMessage_Body{
			Id:           strconv.FormatUint(orderId, 10),
			UserId:       strconv.FormatUint(uidInt, 10),
			Side:         side,
			Price:        price.String(),
			Volume:       volume.String(),
			FeeRateMaker: "0.001",  // 现货交易 maker 费率
			FeeRateTaker: "0.002",  // 现货交易 taker 费率
			FeeCoinRate:  "1",      // 现货交易费率币种比例
			Status:       "1",      // 1: 未成交
			Type:         "1",      // 1: 限价单
			Source:       "2",      // 2: API
			Ctime:        strconv.FormatInt(time.Now().UnixMilli(), 10),
			OrderType:    "1",      // 1: 限价单
			CompanyId:    "1",      // 默认公司ID
			DealVolume:   "0",      // 已成交数量
			DealMoney:    "0",      // 已成交金额
			AvgPrice:     "0",      // 平均成交价格
			Symbol:       symbol,
		},
	}
}

func main() {
	flag.Parse()

	// 检查必要参数
	if symbol == "" || minPrice <= 0 || maxPrice <= 0 || minVolume <= 0 || maxVolume <= 0 || orderCount <= 0 {
		fmt.Println("参数错误，需要指定：symbol, minPrice, maxPrice, minVolume, maxVolume, count")
		flag.Usage()
		os.Exit(1)
	}

	if minPrice >= maxPrice {
		fmt.Println("minPrice 必须小于 maxPrice")
		os.Exit(1)
	}

	if minVolume >= maxVolume {
		fmt.Println("minVolume 必须小于 maxVolume")
		os.Exit(1)
	}

	if pricePrec < 0 || volumePrec < 0 {
		fmt.Println("精度不能为负数")
		os.Exit(1)
	}

	// 初始化随机数种子
	rand.Seed(time.Now().UnixNano())

	// 连接 RocketMQ
	nameServer := "10.0.0.114:9876"
	topic := fmt.Sprintf("EXCHANGE_ORDER_TOPIC_%s", symbol)
	pConfig := &rocketmq.ProducerConfig{
		ClientConfig: rocketmq.ClientConfig{
			GroupID:    "mq_tool_group",
			NameServer: nameServer,
		},
		ProducerModel: rocketmq.CommonProducer,
	}
	producer, err := rocketmq.NewProducer(pConfig)
	if err != nil {
		fmt.Printf("创建 RocketMQ Producer 失败: %v\n", err)
		os.Exit(1)
	}
	err = producer.Start()
	if err != nil {
		fmt.Printf("启动 RocketMQ Producer 失败: %v\n", err)
		os.Exit(1)
	}
	defer producer.Shutdown()

	// 生成并发送订单
	buyCount := orderCount / 2
	sellCount := orderCount - buyCount

	fmt.Printf("开始生成订单，总计 %d 个（买单 %d 个，卖单 %d 个）\n", orderCount, buyCount, sellCount)

	// 发送买单
	for i := 0; i < buyCount; i++ {
		msg := generateOrder(symbol, "BUY", minPrice, maxPrice, minVolume, maxVolume, uid)
		data, err := proto.Marshal(msg)
		if err != nil {
			fmt.Printf("Protobuf 序列化失败: %v\n", err)
			continue
		}

		msgObj := &rocketmq.Message{
			Topic: topic,
			Body:  string(data),
		}
		if tag != "" {
			msgObj.Tags = tag
		}
		if key != "" {
			msgObj.Keys = key
		}

		// fmt.Printf("\nTopic: %s\n", topic)
		// fmt.Printf("Data (hex): %x\n", data)
		// fmt.Printf("Data (base64): %s\n", base64.StdEncoding.EncodeToString(data))

		res, err := producer.SendMessageSync(msgObj)
		if err != nil {
			fmt.Printf("发送买单失败: %v\n", err)
			continue
		}
		fmt.Printf("发送买单 #%d: 价格=%s, 数量=%s, 结果=%s\n", 
			i+1, msg.Body.Price, msg.Body.Volume, res.String())
		
		time.Sleep(100 * time.Millisecond)
	}

	// 发送卖单
	for i := 0; i < sellCount; i++ {
		msg := generateOrder(symbol, "SELL", minPrice, maxPrice, minVolume, maxVolume, uid)
		data, err := proto.Marshal(msg)
		if err != nil {
			fmt.Printf("Protobuf 序列化失败: %v\n", err)
			continue
		}

		msgObj := &rocketmq.Message{
			Topic: topic,
			Body:  string(data),
		}
		if tag != "" {
			msgObj.Tags = tag
		}
		if key != "" {
			msgObj.Keys = key
		}

		// fmt.Printf("\nTopic: %s\n", topic)
		// fmt.Printf("Data (hex): %x\n", data)
		// fmt.Printf("Data (base64): %s\n", base64.StdEncoding.EncodeToString(data))

		res, err := producer.SendMessageSync(msgObj)
		if err != nil {
			fmt.Printf("发送卖单失败: %v\n", err)
			continue
		}
		fmt.Printf("发送卖单 #%d: 价格=%s, 数量=%s, 结果=%s\n", 
			i+1, msg.Body.Price, msg.Body.Volume, res.String())
		
		time.Sleep(100 * time.Millisecond)
	}

	fmt.Println("所有订单发送完成！")
} 