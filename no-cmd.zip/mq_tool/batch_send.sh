#!/bin/bash

# 设置动态库路径
export DYLD_LIBRARY_PATH=/usr/local/lib

# 设置基础参数
SYMBOL="BTC8USDT"
DEPTH_SYMBOL="BTC8-USDT"
MinPrice=49000
MaxPrice=51000
MinVolume=0.1
MaxVolume=1.0
Count=20
UID="1001"
PricePrec=2    # 价格精度，保留2位小数
VolumePrec=2   # 数量精度，保留4位小数

# 检查命令参数
if [ $# -eq 0 ]; then
    echo "用法: $0 [push|get]"
    echo "  push: 推送订单数据"
    echo "  get:  查询 Redis 订单簿数据"
    exit 1
fi

case "$1" in
    "push")
        echo "开始发送订单..."
        ./mq_tool -symbol $SYMBOL \
            -minPrice $MinPrice \
            -maxPrice $MaxPrice \
            -minVolume $MinVolume \
            -maxVolume $MaxVolume \
            -count $Count \
            -uid $UID \
            -pricePrec $PricePrec \
            -volumePrec $VolumePrec
        echo "所有订单发送完成！"
        ;;
    "get")
        redis-cli -h 127.0.0.1 -p 7001 -a WOJdJ4HLWCQx9K3E get "orderbook:spot:$DEPTH_SYMBOL" | jq -r tostring
        ;;
    *)
        echo "无效的命令: $1"
        echo "用法: $0 [push|get]"
        echo "  push: 推送订单数据"
        echo "  get:  查询 Redis 订单簿数据"
        exit 1
        ;;
esac 